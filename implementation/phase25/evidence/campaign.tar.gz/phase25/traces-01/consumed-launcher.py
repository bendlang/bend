#!/usr/bin/env python3
"""Small diagnostic trace acquisition; no timings are used for comparison."""
from pathlib import Path
import json, subprocess, sys, collections
from campaign import SH, TOOLS, NODE, FLAGS, ENV, ident, save
diagnostics,out=[Path(p).resolve() for p in sys.argv[1:]]
out.mkdir(parents=True,exist_ok=False)
plan=json.loads((diagnostics/'plan.json').read_text());results=[]
for row in plan['rows']:
    if row['name'] not in ['scalar-arithmetic','pinned-u32-table','pinned-u32-wide','string-equality']:continue
    stem=row['name']+'-'+row['side'];config=out/(stem+'.json');save(config,row['config'])
    command=['taskset','-c','3',str(NODE),*FLAGS,'--trace-opt','--trace-deopt','--trace-gc',str(TOOLS/'trace.mjs'),str(config)]
    observation={'name':row['name'],'side':row['side'],'command':command,'tool':ident(TOOLS/'trace.mjs'),'module':ident(row['config']['module']),'timeoutSeconds':15}
    try:
        with (out/(stem+'.stdout')).open('w') as a,(out/(stem+'.stderr')).open('w') as b:
            p=subprocess.run(command,cwd=SH,env=ENV,stdout=a,stderr=b,timeout=15)
        observation['exitCode']=p.returncode
        text=(out/(stem+'.stdout')).read_text();steady=text.split('PHASE25_BEGIN_STEADY\n')[1].split('PHASE25_END_STEADY\n')[0]
        observation['steady']={'gcLines':[x for x in steady.splitlines() if 'Scavenge' in x or 'Mark-Compact' in x],
                               'deoptimizationLines':[x for x in steady.splitlines() if 'bailout' in x],
                               'optimizationLines':[x for x in steady.splitlines() if 'optimizing' in x or 'compilation' in x]}
        observation['gcEvents']=len(observation['steady']['gcLines']);observation['deoptimizations']=len(observation['steady']['deoptimizationLines'])
        observation['observation']=json.loads(text.strip().splitlines()[-1]);assert p.returncode==0 and observation['observation']['complete']
        observation['complete']=True
    except Exception as e:observation['complete']=False;observation['error']=str(e)
    results.append(observation);save(out/'report.json',results)
    print(json.dumps({k:observation.get(k) for k in ['name','side','complete','gcEvents','deoptimizations','error']}),flush=True)
assert all(x['complete'] for x in results)
