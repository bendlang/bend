function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0n ? {$: "Tuple", fst: 0n, snd: a}
    : {$: "Tuple", fst: a / b, snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655n) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && Math.fround(Number(s)) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = Number(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: Math.fround(v)} : {$: "None"};
}

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31n) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** Number(d)).fill(v);
}

// An unbalanced tree fails, as in C.
function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_swap(a, i, v) {
  const at = i % a.length;
  const old = a[at];
  a[at] = v;
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_jump(f, x) {
  return {$: "$JMP", f: f, x: x};
}

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : run_loop(f(...a));
}
// Program
// =======

function $check_book$(book_0) {
  return run_jump($dg_result_error$, [run_loop($check_book_diagnostic$(book_0, {$: "Nil"}))]);
}

function $check$(e_0, ctx_0, t_0, dem_0, ty_0) {
  return run_jump($dg_trace$, [e_0, ctx_0, t_0, ty_0, run_loop($check_node$(e_0, ctx_0, run_loop($core_beta$(t_0)), dem_0, ty_0))]);
}

function $infer$(e_0, ctx_0, t_0, dem_0, sp_0) {
  return run_jump($dg_trace$, [e_0, ctx_0, t_0, run_loop($atom$("Absent")), run_loop($infer_node$(e_0, ctx_0, run_loop($core_beta$(t_0)), dem_0, sp_0))]);
}

function $annotate_book$(book_0) {
  return run_jump($ka_defs$, [run_loop($book_context$(book_0)), book_0]);
}

function $kp_show$(t_0) {
  return run_jump($kp_go$, [t_0, 0, {$: "Nil"}]);
}

function $specialize_book$(book_0) {
  return run_jump($sp_finish$, [run_loop($sp_definitions$(book_0, run_loop($sp_initial$(run_loop($sp_canonical$(book_0, {$: "Nil"})), run_loop($norm_max_book$(book_0))))))]);
}

function $specialized_book$(r_0) {
  const book_0 = r_0["book"];
  const error_0 = r_0["error"];
  return book_0;
}

function $specialized_error$(r_0) {
  const book_0 = r_0["book"];
  const error_0 = r_0["error"];
  return error_0;
}

function $strong$(book_0, t_0) {
  return run_jump($graph_strong$, [book_0, t_0]);
}

function $wnf$(book_0, t_0) {
  return run_jump($norm_eval$, [book_0, t_0, {$: "Nil"}, 0, run_loop($atom$("Absent"))]);
}

function $compare$(book_0, a_0, b_0, le_0) {
  const x_0 = run_loop($norm_max$(run_loop($norm_book_bound$(book_0)), run_loop($norm_max$(run_loop($norm_max_term$(a_0)), run_loop($norm_max_term$(b_0))))));
  return run_jump($norm_compare$, [book_0, a_0, b_0, le_0, ((1 + x_0) >>> 0)]);
}

function $exact_prefix$(book_0, prefix_0) {
  if (prefix_0.$ === "Nil") {
    return true;
  } else {
    const h_0 = prefix_0["head"];
    const rest_0 = prefix_0["tail"];
    return run_jump($exact_prefix_head$, [book_0, h_0, rest_0]);
  }
}

function $check_from_exact_prefix$(book_0, validated_0) {
  return run_jump($dg_result_error$, [run_loop($check_book_diagnostic_from_exact_prefix$(book_0, validated_0, {$: "Nil"}))]);
}

function $reach_book$(book_0, roots_0, stops_0) {
  return run_jump($kr_filter$, [book_0, run_loop($kr_visit$(book_0, roots_0, {$: "Nil"}, stops_0))]);
}

function $lookup$(book_0, name_0) {
  if (book_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "BookCache")), run_clo((x_0) => {
    return run_jump($index_lookup$, [d_0, name_0]);
}), run_clo((x_1) => {
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dn$(d_0)), name_0)), run_clo((x_2) => {
    return d_0;
}), run_clo((x_3) => {
    return run_jump($lookup$, [rest_0, name_0]);
})]);
})]);
  }
}

function $book_cached$(book_0, bound_0) {
  return {$: "Con", ["head"]: {$: "KDef", ["name"]: "$kernel.cache", ["kind"]: "BookCache", ["arity"]: bound_0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Con", ["head"]: run_loop($index_build$(book_0)), ["tail"]: {$: "Nil"}}, ["native"]: true, ["unsafe"]: false}, ["tail"]: book_0};
}

function $book_context$(book_0) {
  if (book_0.$ === "Nil") {
    return run_jump($book_cached$, [{$: "Nil"}, 0]);
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(h_0)), "BookCache")), run_clo((x_0) => {
    return {$: "Con", ["head"]: h_0, ["tail"]: rest_0};
}), run_clo((x_1) => {
    return run_jump($book_cached$, [{$: "Con", ["head"]: h_0, ["tail"]: rest_0}, run_loop($norm_max_book$({$: "Con", ["head"]: h_0, ["tail"]: rest_0}))]);
})]);
  }
}

function $book_put$(book_0, d_0) {
  if (book_0.$ === "Nil") {
    return {$: "Con", ["head"]: d_0, ["tail"]: {$: "Nil"}};
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(h_0)), "BookCache")), run_clo((x_0) => {
    return {$: "Con", ["head"]: {$: "KDef", ["name"]: run_loop($dn$(h_0)), ["kind"]: run_loop($dk$(h_0)), ["arity"]: run_loop($da$(h_0)), ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Con", ["head"]: run_loop($index_set$(run_loop($index_first$(run_loop($dc$(h_0)))), d_0, run_loop($index_hash$(run_loop($dn$(d_0)), 2166136261)), 32)), ["tail"]: {$: "Nil"}}, ["native"]: true, ["unsafe"]: false}, ["tail"]: {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_put_rest$(h_0, rest_0, run_loop($dn$(d_0))))}};
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_remove$({$: "Con", ["head"]: h_0, ["tail"]: rest_0}, run_loop($dn$(d_0))))};
})]);
  }
}

function $f_parse$(source_0) {
  return run_jump($fpe_finish$, [source_0, run_loop($f_tops$(run_loop($f_lex$(source_0, 1, 0, 0, {$: "Nil"})), {$: "Nil"}, {$: "Nil"}, false))]);
}

function $f_source_parsed$(name_0, path_0, text_0, parsed_0) {
  return {$: "FParsedSource", ["name"]: name_0, ["path"]: path_0, ["text"]: text_0, ["parsed"]: parsed_0};
}

function $f_load_graph$(main_0, sources_0) {
  return run_jump($f_graph_result_at$, [run_loop($f_graph_load$(main_0, "", sources_0, {$: "FGraph", ["book"]: {$: "Nil"}, ["error"]: "", ["done"]: {$: "Nil"}}, {$: "Nil"})), sources_0]);
}

function $f_load_graph_seed$(main_0, sources_0, seedPath_0, seedText_0, seedBook_0) {
  return run_jump($f_choose$, [run_loop($f_seed_matches$(run_loop($f_source$("Base", sources_0)), seedPath_0, seedText_0)), run_clo((x_0) => {
  return run_jump($f_graph_result_at$, [run_loop($fs_load$(main_0, "", sources_0, {$: "FGraph", ["book"]: {$: "Nil"}, ["error"]: "", ["done"]: {$: "Nil"}}, {$: "Nil"}, {$: "FSeed", ["path"]: seedPath_0, ["book"]: seedBook_0})), sources_0]);
}), run_clo((x_1) => {
  return run_jump($f_load_graph$, [main_0, sources_0]);
})]);
}

function $f_main_names$(main_0, sources_0) {
  return run_jump($f_main_result_names$, [run_loop($f_parse_source$(run_loop($f_graph_source$(main_0, sources_0))))]);
}

function $f_fresh_term$(t_0, env_0, next_0) {
  return run_jump($f_fresh_stack$, [t_0, env_0, next_0]);
}

function $f_fresh_defs$(ds_0, next_0) {
  return run_jump($f_fresh_book_stack$, [ds_0, next_0]);
}

function $check_book_diagnostic$(book_0, origins_0) {
  return run_jump($dg_suffix_events$, [book_0, run_loop($book_cached$({$: "Nil"}, run_loop($norm_max_book$(book_0)))), book_0, origins_0]);
}

function $diagnostic_render$(result_0) {
  const error_0 = result_0["error"];
  const book_0 = result_0["book"];
  const diagnostic_0 = result_0["diagnostic"];
  return run_jump($kc$, [run_loop($String$eq$(error_0, "")), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  return run_jump($dg_render_checked$, [book_0, diagnostic_0, error_0]);
})]);
}

function $diagnostic_result_locate$(result_0, origins_0) {
  const error_0 = result_0["error"];
  const book_0 = result_0["book"];
  const diagnostic_0 = result_0["diagnostic"];
  return {$: "DResult", ["error"]: error_0, ["book"]: book_0, ["diagnostic"]: run_loop($diagnostic_locate$(diagnostic_0, origins_0))};
}

function $dg_render$(book_0, diagnostic_0) {
  const expected_0 = diagnostic_0["expected"];
  const observed_0 = diagnostic_0["observed"];
  const has_observed_0 = diagnostic_0["has_observed"];
  const context_0 = diagnostic_0["context"];
  const definition_0 = diagnostic_0["definition"];
  const span_0 = diagnostic_0["span"];
  const note_0 = diagnostic_0["note"];
  const trail_0 = diagnostic_0["trail"];
  return run_jump($dg_render_parts$, [book_0, expected_0, observed_0, has_observed_0, run_loop($List$reverse$(context_0)), definition_0, span_0, note_0]);
}

function $diagnostic_locate$(diagnostic_0, origins_0) {
  const expected_0 = diagnostic_0["expected"];
  const observed_0 = diagnostic_0["observed"];
  const has_observed_0 = diagnostic_0["has_observed"];
  const context_0 = diagnostic_0["context"];
  const definition_0 = diagnostic_0["definition"];
  const span_0 = diagnostic_0["span"];
  const note_0 = diagnostic_0["note"];
  const trail_0 = diagnostic_0["trail"];
  return {$: "DDiagnostic", ["expected"]: expected_0, ["observed"]: observed_0, ["has_observed"]: has_observed_0, ["context"]: context_0, ["definition"]: definition_0, ["span"]: run_loop($kc$(run_loop($dg_has_span$(span_0)), run_clo((x_0) => {
  return span_0;
}), run_clo((x_1) => {
  return run_jump($dg_origin_trail$, [origins_0, definition_0, trail_0]);
}))), ["note"]: note_0, ["trail"]: trail_0};
}

function $f_load_origins$(main_0, sources_0) {
  return run_jump($fp_loaded_origins$, [run_loop($f_load_graph_trace$(main_0, sources_0)), true, ""]);
}

function $f_load_origins_for$(main_0, sources_0, definition_0) {
  return run_jump($f_loaded_origins_for$, [run_loop($f_load_graph_trace$(main_0, sources_0)), definition_0]);
}

function $nc_ctor_identity$(book_0, name_0) {
  return run_jump($kc$, [run_loop($nc_ctor_owned$(book_0, name_0)), run_clo((x_0) => {
  return name_0;
}), run_clo((x_1) => {
  return run_jump($nc_ctor_encode$, [name_0]);
})]);
}

function $nc_ctor_display$(name_0) {
  return run_jump($kc$, [run_loop($String$starts_with$(name_0, "$ctor.")), run_clo((x_0) => {
  return run_jump($nc_ctor_decode$, [run_loop($String$drop$(name_0, BigInt([..."$ctor."].length))), 0, 0, "", name_0]);
}), run_clo((x_1) => {
  return name_0;
})]);
}

function $nc_ctor_encode$(name_0) {
  const x_0 = run_loop($nc_ctor_codes$(name_0));
  return ("$ctor." + x_0);
}

function $nc_ctor_owned$(book_0, name_0) {
  if (book_0.$ === "Nil") {
    return false;
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_0) => {
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(run_loop($dc$(d_0)), name_0)))), "Ctr")), run_clo((x_1) => {
    return run_jump($db$, [d_0]);
}), run_clo((x_2) => {
    return run_jump($nc_ctor_owned$, [rest_0, name_0]);
})]);
}), run_clo((x_3) => {
    return run_jump($nc_ctor_owned$, [rest_0, name_0]);
})]);
  }
}

function $dg_result_error$(result_0) {
  const error_0 = result_0["error"];
  const book_0 = result_0["book"];
  const diagnostic_0 = result_0["diagnostic"];
  return error_0;
}

function $dg_trace$(e_0, ctx_0, t_0, ty_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return r_0;
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($ct$(r_0)))), "DTrace")), run_clo((x_2) => {
  return {$: "KChecked", ["term"]: run_loop($kt$("DTrace", run_loop($nm$(run_loop($ct$(r_0)))), run_loop($ix$(run_loop($ct$(r_0)))), run_loop($qt$(run_loop($ct$(r_0)))), {$: "Con", ["head"]: run_loop($kid$(run_loop($ct$(r_0)), 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(run_loop($ct$(r_0)), 1)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(run_loop($ct$(r_0)), 2)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(run_loop($ct$(r_0)), 3)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("DTrail", "", 0, 0, run_loop($norm_join$(run_loop($ks$(run_loop($kid$(run_loop($ct$(r_0)), 4)))), {$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}})))), ["tail"]: {$: "Nil"}}}}}})), ["typ"]: run_loop($cy$(r_0)), ["uses"]: run_loop($cs$(r_0)), ["error"]: run_loop($ce$(r_0))};
}), run_clo((x_3) => {
  return run_jump($dg_trace_detail$, [e_0, ctx_0, t_0, r_0, run_loop($kc$(run_loop($String$eq$(run_loop($tg$(run_loop($ct$(r_0)))), "DDetail")), run_clo((x_4) => {
  return run_jump($ct$, [r_0]);
}), run_clo((x_5) => {
  return run_jump($dg_reason$, [e_0, ctx_0, t_0, ty_0, run_loop($ce$(r_0))]);
})))]);
})]);
})]);
}

function $check_node$(e_0, ctx_0, t_0, dem_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_0) => {
  return run_jump($check_lam$, [e_0, ctx_0, t_0, dem_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr")), run_clo((x_2) => {
  return run_jump($check_ctr$, [e_0, ctx_0, t_0, dem_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}), run_clo((x_3) => {
  const x_4 = run_loop($String$eq$(run_loop($tg$(t_0)), "Mat"));
  const x_5 = run_loop($String$eq$(run_loop($tg$(t_0)), "Efq"));
  return run_jump($kc$, [(x_4 || x_5), run_clo((x_6) => {
  return run_jump($check_mat$, [e_0, ctx_0, t_0, dem_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rfl")), run_clo((x_8) => {
  return run_jump($check_rfl$, [e_0, t_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Hol")), run_clo((x_10) => {
  return run_jump($bad$, ["unresolved hole"]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_12) => {
  return run_jump($check_let$, [e_0, ctx_0, ctx_0, run_loop($ks$(t_0)), dem_0, ty_0, {$: "Nil"}, {$: "Nil"}]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_14) => {
  return run_jump($check_rwt$, [e_0, ctx_0, t_0, dem_0, ty_0, run_loop($infer$(e_0, ctx_0, run_loop($kid$(t_0, 0)), dem_0, {$: "Nil"}))]);
}), run_clo((x_15) => {
  return run_jump($check_fits$, [e_0, run_loop($infer$(e_0, ctx_0, t_0, dem_0, {$: "Nil"})), ty_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $core_beta$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($core_apply$, [run_loop($core_beta$(run_loop($kid$(t_0, 0)))), run_loop($kid$(t_0, 1))]);
}), run_clo((x_1) => {
  return t_0;
})]);
}

function $atom$(tag_0) {
  return run_jump($kt$, [tag_0, "", 0, 0, {$: "Nil"}]);
}

function $infer_node$(e_0, ctx_0, t_0, dem_0, sp_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), run_clo((x_0) => {
  return run_jump($infer_var$, [ctx_0, t_0, dem_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_2) => {
  return run_jump($infer_ref$, [e_0, t_0, dem_0, sp_0, run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(t_0))))]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Typ")), run_clo((x_4) => {
  return run_jump($checked$, [run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 0)), 0, run_loop($atom$("Qnt")))), t_0, run_loop($typ$(1))]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Qnt")), run_clo((x_6) => {
  return run_jump($ok$, [t_0, run_loop($typ$(1)), {$: "Nil"}]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Qua")), run_clo((x_8) => {
  return run_jump($ok$, [t_0, run_loop($atom$("Qnt")), {$: "Nil"}]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Min")), run_clo((x_10) => {
  return run_jump($both$, [run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 0)), dem_0, run_loop($atom$("Qnt")))), run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), dem_0, run_loop($atom$("Qnt")))), t_0, run_loop($atom$("Qnt")), false]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "All")), run_clo((x_12) => {
  return run_jump($both$, [run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 0)), 0, run_loop($typ$(run_loop($kindq$(e_0, run_loop($qt$(t_0)))))))), run_loop($check$(e_0, run_loop($ctx_bind$(ctx_0, run_loop($ix$(t_0)), run_loop($qt$(t_0)), run_loop($nm$(t_0)), run_loop($kid$(t_0, 0)))), run_loop($kid$(t_0, 1)), 0, run_loop($typ$(1)))), t_0, run_loop($typ$(1)), false]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_14) => {
  return run_jump($infer_app$, [e_0, ctx_0, t_0, dem_0, run_loop($infer$(e_0, ctx_0, run_loop($kid$(t_0, 0)), dem_0, {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: sp_0}))]);
}), run_clo((x_15) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "ADT")), run_clo((x_16) => {
  return run_jump($infer_adt$, [e_0, ctx_0, t_0, dem_0, run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(t_0))))]);
}), run_clo((x_17) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Eql")), run_clo((x_18) => {
  return run_jump($both$, [run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 2)), 0, run_loop($typ$(1)))), run_loop($both$(run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 0)), 0, run_loop($kid$(t_0, 2)))), run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), 0, run_loop($kid$(t_0, 2)))), t_0, run_loop($typ$(2)), false)), t_0, run_loop($typ$(2)), false]);
}), run_clo((x_19) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_20) => {
  return run_jump($both$, [run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), 0, run_loop($typ$(1)))), run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 0)), dem_0, run_loop($kid$(t_0, 1)))), run_loop($kid$(t_0, 0)), run_loop($kid$(t_0, 1)), false]);
}), run_clo((x_21) => {
  return run_jump($bad$, ["cannot infer: annotation required"]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $ka_defs$(book_0, ds_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return {$: "Con", ["head"]: run_loop($ka_def$(book_0, d_0)), ["tail"]: run_loop($ka_defs$(book_0, rest_0))};
  }
}

function $kp_go$(t_0, p_0, env_0) {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Var")), run_clo((x_0) => {
  return run_jump($kp_scope$, [env_0, run_loop($ix$(t_0)), run_loop($nm$(t_0))]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_2) => {
  const x_5 = run_loop($qt$(t_0));
  const x_8 = run_loop($kc$(run_loop($kp_bound$(env_0, run_loop($nm$(t_0)))), run_clo((x_3) => {
  return "^";
}), run_clo((x_4) => {
  return "";
})));
  const x_9 = run_loop($kc$((x_5 === 3), run_clo((x_6) => {
  return "!";
}), run_clo((x_7) => {
  return "";
})));
  const x_10 = run_loop($nm$(t_0));
  const x_11 = (x_8 + x_9);
  return (x_10 + x_11);
}), run_clo((x_12) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Typ")), run_clo((x_13) => {
  const x_14 = run_loop($qt$(run_loop($kid$(t_0, 0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_eq$(run_loop($tg$(run_loop($kid$(t_0, 0)))), "Qua")), (x_14 === 1))), run_clo((x_15) => {
  return "Type";
}), run_clo((x_16) => {
  const x_17 = run_loop($qt$(run_loop($kid$(t_0, 0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_eq$(run_loop($tg$(run_loop($kid$(t_0, 0)))), "Qua")), (x_17 === 2))), run_clo((x_18) => {
  return "Data";
}), run_clo((x_19) => {
  const x_20 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 1, env_0));
  const x_21 = (x_20 + ")");
  return ("Kind(" + x_21);
})]);
})]);
}), run_clo((x_22) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Qnt")), run_clo((x_23) => {
  return "Quant";
}), run_clo((x_24) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Qua")), run_clo((x_25) => {
  const x_26 = run_loop($U32$show$(run_loop($qt$(t_0))));
  return ("&" + x_26);
}), run_clo((x_27) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Min")), run_clo((x_28) => {
  const x_29 = run_loop($kp_go$(run_loop($kid$(t_0, 1)), 3, env_0));
  const x_30 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 3, env_0));
  const x_31 = (" <&> " + x_29);
  return run_jump($kp_par$, [(x_30 + x_31), (p_0 > 2)]);
}), run_clo((x_32) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "All")), run_clo((x_33) => {
  const x_34 = run_loop($kp_go$(run_loop($kid$(t_0, 1)), 2, run_loop($kp_bind$(env_0, t_0))));
  const x_35 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 3, env_0));
  const x_36 = (" -> " + x_34);
  const x_37 = (x_35 + x_36);
  const x_38 = run_loop($nm$(t_0));
  const x_39 = (":" + x_37);
  const x_40 = run_loop($kp_quant$(run_loop($qt$(t_0))));
  const x_41 = (x_38 + x_39);
  const x_42 = (x_40 + x_41);
  return run_jump($kp_par$, [("@" + x_42), (p_0 > 2)]);
}), run_clo((x_43) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_44) => {
  const x_45 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 0, run_loop($kp_bind$(env_0, t_0))));
  const x_46 = run_loop($nm$(t_0));
  const x_47 = (" => " + x_45);
  const x_48 = run_loop($kp_quant$(run_loop($qt$(t_0))));
  const x_49 = (x_46 + x_47);
  return run_jump($kp_par$, [(x_48 + x_49), (p_0 > 1)]);
}), run_clo((x_50) => {
  return run_jump($kp_go_tail$, [t_0, p_0, env_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $sp_finish$(st_0) {
  return {$: "KSpecialized", ["book"]: run_loop($index_remove$(run_loop($sp_book$(st_0)), "$kernel.max-id")), ["error"]: run_loop($sp_error$(st_0))};
}

function $sp_definitions$(todo_0, st_0) {
  if (todo_0.$ === "Nil") {
    return st_0;
  } else {
    const d_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($sp_error$(st_0)), "")), run_clo((x_0) => {
    return run_jump($sp_definition_next$, [rest_0, st_0, d_0]);
}), run_clo((x_1) => {
    return st_0;
})]);
  }
}

function $sp_initial$(book_0, bound_0) {
  return {$: "KSpecState", ["book"]: run_loop($sp_stamp$(book_0, bound_0)), ["memo"]: {$: "Nil"}, ["serial"]: 0, ["fresh"]: ((bound_0 + 1) >>> 0), ["error"]: "", ["templates"]: run_loop($sp_template_book$(book_0))};
}

function $sp_canonical$(book_0, done_0) {
  return run_jump($book_final_fast$, [book_0, done_0]);
}

function $norm_max_book$(book_0) {
  return run_jump($norm_max_defs$, [book_0, 0]);
}

function $graph_strong$(book_0, t_0) {
  return run_jump($g_start$, [book_0, t_0, run_loop($norm_max$(run_loop($norm_book_bound$(book_0)), run_loop($norm_max_term$(t_0))))]);
}

function $norm_eval$(book_0, t_0, args_0, left_0, fallback_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), run_clo((x_0) => {
  return run_jump($norm_var$, [book_0, t_0, run_loop($ks$(t_0)), args_0, left_0, fallback_0]);
}), run_clo((x_1) => {
  return run_jump($norm_eval_node$, [book_0, t_0, args_0, left_0, fallback_0]);
})]);
}

function $norm_compare$(book_0, a_0, b_0, le_0, fresh_0) {
  return run_jump($kc$, [run_loop($norm_exact$(a_0, b_0)), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: a_0, ["b"]: b_0, ["le"]: le_0, ["fresh"]: fresh_0}, ["tail"]: {$: "Nil"}}, {$: "Nil"}]);
})]);
}

function $norm_max$(a_0, b_0) {
  return run_jump($kc$, [(a_0 <= b_0), run_clo((x_0) => {
  return b_0;
}), run_clo((x_1) => {
  return a_0;
})]);
}

function $norm_book_bound$(book_0) {
  if (book_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(h_0)), "BookCache")), run_clo((x_0) => {
    return run_jump($da$, [h_0]);
}), run_clo((x_1) => {
    return run_jump($norm_bound_found$, [{$: "Con", ["head"]: h_0, ["tail"]: rest_0}, run_loop($lookup$({$: "Con", ["head"]: h_0, ["tail"]: rest_0}, "$kernel.max-id"))]);
})]);
  }
}

function $norm_max_term$(t_0) {
  return run_jump($norm_max_walk$, [{$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}}, 0]);
}

function $exact_prefix_head$(book_0, h_0, rest_0) {
  if (book_0.$ === "Nil") {
    return false;
  } else {
    const x_0 = book_0["head"];
    const xs_0 = book_0["tail"];
    return run_jump($Bool$and$, [run_loop($exact_def$(x_0, h_0)), run_loop($exact_prefix$(xs_0, rest_0))]);
  }
}

function $check_book_diagnostic_from_exact_prefix$(book_0, validated_0, origins_0) {
  return run_jump($kc$, [run_loop($exact_prefix$(book_0, validated_0)), run_clo((x_0) => {
  return run_jump($dg_prefix_seed$, [book_0, validated_0, run_loop($book_cached$({$: "Nil"}, run_loop($norm_max_book$(book_0)))), book_0, origins_0]);
}), run_clo((x_1) => {
  return run_jump($check_book_diagnostic$, [book_0, origins_0]);
})]);
}

function $kr_filter$(book_0, live_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($has_name$(live_0, run_loop($dn$(d_0)))), run_clo((x_0) => {
    return {$: "Con", ["head"]: d_0, ["tail"]: run_loop($kr_filter$(rest_0, live_0))};
}), run_clo((x_1) => {
    return run_jump($kr_filter$, [rest_0, live_0]);
})]);
  }
}

function $kr_visit$(book_0, todo_0, seen_0, stops_0) {
  if (todo_0.$ === "Nil") {
    return seen_0;
  } else {
    const name_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($kc$, [run_loop($has_name$(seen_0, name_0)), run_clo((x_0) => {
    return run_jump($kr_visit$, [book_0, rest_0, seen_0, stops_0]);
}), run_clo((x_1) => {
    return run_jump($kr_visit_def$, [book_0, rest_0, {$: "Con", ["head"]: name_0, ["tail"]: seen_0}, stops_0, run_loop($kr_resolve$(book_0, name_0))]);
})]);
  }
}

function $missing$() {
  return {$: "KDef", ["name"]: "", ["kind"]: "Absent", ["arity"]: 0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: false};
}

function $kc$(b_0, yes_0, no_0) {
  if (b_0) {
    return run_tail(yes_0, {$: "Unit"});
  } else {
    return run_tail(no_0, {$: "Unit"});
  }
}

function $String$eq$(a_0, b_0) {
  return run_jump($String$eq$fin$, [run_loop($String$cmp$(a_0, b_0))]);
}

function $dk$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return kind_0;
}

function $index_lookup$(cache_0, name_0) {
  return run_jump($index_find$, [run_loop($index_first$(run_loop($dc$(cache_0)))), name_0, run_loop($index_hash$(name_0, 2166136261)), 32]);
}

function $dn$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return name_0;
}

function $index_build$(book_0) {
  if (book_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($index_set$, [run_loop($index_build$(rest_0)), h_0, run_loop($index_hash$(run_loop($dn$(h_0)), 2166136261)), 32]);
  }
}

function $da$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return arity_0;
}

function $index_set$(tree_0, d_0, hash_0, bits_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(tree_0)), "Absent")), run_clo((x_0) => {
  return run_jump($index_leaf$, [d_0, hash_0, {$: "Nil"}]);
}), run_clo((x_1) => {
  const x_2 = run_loop($da$(run_loop($index_tip$(tree_0, hash_0))));
  return run_jump($index_insert$, [tree_0, d_0, hash_0, run_loop($index_split_bit$(((hash_0 ^ x_2) >>> 0)))]);
})]);
}

function $index_first$(ds_0) {
  if (ds_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const h_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return h_0;
  }
}

function $dc$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return ctors_0;
}

function $index_hash$(name_0, acc_0) {
  if (name_0 === "") {
    return acc_0;
  } else {
    const h_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(0, 2) : name_0[0]);
    const rest_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(2) : name_0.slice(1));
    const x_0 = run_loop($Char$to_u32$(h_0));
    const x_1 = ((acc_0 ^ x_0) >>> 0);
    return run_jump($index_hash$, [rest_0, (Math.imul(x_1, 16777619) >>> 0)]);
  }
}

function $index_put_rest$(cache_0, rest_0, name_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$(run_loop($String$eq$(name_0, "")))), run_loop($String$eq$(run_loop($dn$(run_loop($index_lookup$(cache_0, name_0)))), "")))), run_clo((x_0) => {
  return rest_0;
}), run_clo((x_1) => {
  return run_jump($index_remove$, [rest_0, name_0]);
})]);
}

function $index_remove$(ds_0, name_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dn$(h_0)), name_0)), run_clo((x_0) => {
    return run_jump($index_remove$, [rest_0, name_0]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($index_remove$(rest_0, name_0))};
})]);
  }
}

function $fpe_finish$(source_0, raw_0) {
  const book_0 = raw_0["book"];
  const error_0 = raw_0["error"];
  const imports_0 = raw_0["imports"];
  return {$: "FResult", ["book"]: book_0, ["error"]: run_loop($fpe_render$(source_0, error_0)), ["imports"]: imports_0};
}

function $f_tops$(ts0_0, book_0, imports_0, unsafe_0) {
  return run_jump($f_top$, [run_loop($f_skip$(ts0_0)), book_0, imports_0, unsafe_0]);
}

function $f_lex$(s_0, l_0, c_0, d_0, acc_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return run_jump($List$reverse$, [acc_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "\n")), run_clo((x_2) => {
  return run_jump($f_lex$, [run_loop($f_tail$(s_0)), ((l_0 + 1) >>> 0), 0, d_0, run_loop($f_choose$((d_0 === 0), run_clo((x_3) => {
  return {$: "Con", ["head"]: {$: "FToken", ["text"]: "\n", ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: 0}, ["tail"]: acc_0};
}), run_clo((x_4) => {
  return acc_0;
})))]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_ascii_space$(run_loop($f_head$(s_0)))), run_clo((x_6) => {
  return run_jump($f_lex$, [run_loop($f_tail$(s_0)), l_0, ((c_0 + 1) >>> 0), d_0, acc_0]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "#")), run_clo((x_8) => {
  return run_jump($f_lex$, [run_loop($f_scan_comment$(s_0)), l_0, c_0, d_0, acc_0]);
}), run_clo((x_9) => {
  const x_10 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "\""));
  const x_11 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "'"));
  return run_jump($f_choose$, [(x_10 || x_11), run_clo((x_12) => {
  return run_jump($f_lex_scanned$, [run_loop($f_scan_quote$(run_loop($f_tail$(s_0)), run_loop($f_head$(s_0)), (run_loop($f_head$(s_0)) + ""), 1)), l_0, c_0, d_0, 2, acc_0]);
}), run_clo((x_13) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_ident$(run_loop($f_head$(s_0)))), run_loop($Bool$not$(run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), ".")))))), run_clo((x_14) => {
  return run_jump($f_lex_scanned$, [run_loop($f_scan_word$(s_0, "", 0)), l_0, c_0, d_0, 1, acc_0]);
}), run_clo((x_15) => {
  return run_jump($f_choose$, [run_loop($f_triple_op$(s_0)), run_clo((x_16) => {
  return run_jump($f_lex$, [run_loop($f_tail$(run_loop($f_tail$(run_loop($f_tail$(s_0)))))), l_0, ((c_0 + 3) >>> 0), d_0, {$: "Con", ["head"]: {$: "FToken", ["text"]: run_loop($f_three$(s_0)), ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: 0}, ["tail"]: acc_0}]);
}), run_clo((x_17) => {
  return run_jump($f_choose$, [run_loop($f_ident$(run_loop($f_head$(s_0)))), run_clo((x_18) => {
  return run_jump($f_lex_scanned$, [run_loop($f_scan_word$(s_0, "", 0)), l_0, c_0, d_0, 1, acc_0]);
}), run_clo((x_19) => {
  return run_jump($f_lex_symbol$, [s_0, l_0, c_0, d_0, acc_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_graph_result_at$(graph_0, sources_0) {
  return run_jump($fpe_graph_result$, [graph_0, sources_0, run_loop($f_graph_result$(graph_0))]);
}

function $f_graph_load$(path_0, ns_0, sources_0, g_0, stack_0) {
  return run_jump($f_graph_source_load$, [run_loop($f_graph_source$(path_0, sources_0)), ns_0, sources_0, g_0, stack_0]);
}

function $f_choose$(b_0, yes_0, no_0) {
  if (b_0) {
    return run_tail(yes_0, {$: "Unit"});
  } else {
    return run_tail(no_0, {$: "Unit"});
  }
}

function $f_seed_matches$(source_0, path_0, text_0) {
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$not$(run_loop($String$is_empty$(path_0)))), run_loop($f_eq$(run_loop($f_source_name$(source_0)), "Base")))), run_loop($f_eq$(run_loop($f_source_path$(source_0)), path_0)))), run_loop($f_seed_text_equal$(run_loop($f_source_text$(source_0)), text_0))]);
}

function $f_source$(name_0, sources_0) {
  if (sources_0.$ === "Nil") {
    return {$: "FSource", ["name"]: "", ["path"]: "", ["text"]: ""};
  } else {
    const source_0 = sources_0["head"];
    const rest_0 = sources_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(name_0, run_loop($f_source_name$(source_0)))), run_clo((x_0) => {
    return source_0;
}), run_clo((x_1) => {
    return run_jump($f_source$, [name_0, rest_0]);
})]);
  }
}

function $fs_load$(path_0, ns_0, sources_0, g_0, stack_0, seed_0) {
  return run_jump($fs_source$, [run_loop($f_graph_source$(path_0, sources_0)), ns_0, sources_0, g_0, stack_0, seed_0]);
}

function $f_main_result_names$(r_0) {
  const book_0 = r_0["book"];
  const error_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(error_0)), run_clo((x_0) => {
  return run_jump($f_main_order$, [book_0, {$: "Nil"}]);
}), run_clo((x_1) => {
  return {$: "Nil"};
})]);
}

function $f_parse_source$(source_0) {
  if (source_0.$ === "FSource") {
    const name_0 = source_0["name"];
    const path_0 = source_0["path"];
    const text_0 = source_0["text"];
    return run_jump($f_parse$, [text_0]);
  } else {
    const name_1 = source_0["name"];
    const path_1 = source_0["path"];
    const text_1 = source_0["text"];
    const parsed_0 = source_0["parsed"];
    return parsed_0;
  }
}

function $f_graph_source$(path_0, sources_0) {
  if (sources_0.$ === "Nil") {
    return {$: "FSource", ["name"]: "", ["path"]: "", ["text"]: ""};
  } else {
    const s_0 = sources_0["head"];
    const rest_0 = sources_0["tail"];
    const x_0 = run_loop($f_eq$(path_0, run_loop($f_source_name$(s_0))));
    const x_1 = run_loop($f_eq$(path_0, run_loop($f_source_path$(s_0))));
    return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
    return s_0;
}), run_clo((x_3) => {
    return run_jump($f_graph_source$, [path_0, rest_0]);
})]);
  }
}

function $f_fresh_stack$(term_0, env_0, next_0) {
  return run_jump($ffw_walk$, [term_0, env_0, next_0, {$: "Nil"}]);
}

function $f_fresh_book_stack$(book_0, next_0) {
  return run_jump($ffd_walk$, [book_0, next_0, {$: "Nil"}, {$: "Nil"}]);
}

function $dg_suffix_events$(todo_0, done_0, original_0, origins_0) {
  if (todo_0.$ === "Nil") {
    return run_jump($dg_suffix_finish$, [done_0, original_0, origins_0, run_loop($check_open$(done_0))]);
  } else {
    const d_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($dg_suffix_guard$, [rest_0, done_0, d_0, original_0, origins_0, run_loop($event_error$(done_0, d_0, run_loop($lookup$(done_0, run_loop($dn$(d_0))))))]);
  }
}

function $dg_render_checked$(book_0, diagnostic_0, error_0) {
  const expected_0 = diagnostic_0["expected"];
  const observed_0 = diagnostic_0["observed"];
  const has_observed_0 = diagnostic_0["has_observed"];
  const context_0 = diagnostic_0["context"];
  const definition_0 = diagnostic_0["definition"];
  const span_0 = diagnostic_0["span"];
  const note_0 = diagnostic_0["note"];
  const trail_0 = diagnostic_0["trail"];
  const x_0 = run_loop($terms_len$(trail_0));
  return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
  return ("Error: " + error_0);
}), run_clo((x_2) => {
  return run_jump($dg_render$, [book_0, {$: "DDiagnostic", ["expected"]: expected_0, ["observed"]: observed_0, ["has_observed"]: has_observed_0, ["context"]: context_0, ["definition"]: definition_0, ["span"]: span_0, ["note"]: note_0, ["trail"]: trail_0}]);
})]);
}

function $dg_render_parts$(book_0, expected_0, observed_0, has_observed_0, ctx_0, name_0, span_0, note_0) {
  const x_7 = run_loop($terms_len$(ctx_0));
  const x_13 = run_loop($dg_location$(name_0, span_0));
  const x_14 = run_loop($kc$(run_loop($String$eq$(note_0, "")), run_clo((x_11) => {
  return "";
}), run_clo((x_12) => {
  return ("\n" + note_0);
})));
  const x_15 = run_loop($kc$((x_7 === 0), run_clo((x_8) => {
  return "";
}), run_clo((x_9) => {
  const x_10 = run_loop($dg_context$(book_0, ctx_0, {$: "Nil"}, run_loop($dg_context_width$(ctx_0))));
  return ("\nContext:" + x_10);
})));
  const x_16 = (x_13 + x_14);
  const x_17 = run_loop($kc$(has_observed_0, run_clo((x_0) => {
  const x_1 = run_loop($dg_expr$(book_0, observed_0, run_loop($dg_scope$(ctx_0, {$: "Nil"}))));
  const x_2 = run_loop($dg_expr$(book_0, expected_0, run_loop($dg_scope$(ctx_0, {$: "Nil"}))));
  const x_3 = ("\n- observed : " + x_1);
  const x_4 = (x_2 + x_3);
  return ("\n- expected : " + x_4);
}), run_clo((x_5) => {
  const x_6 = run_loop($dg_expr$(book_0, expected_0, run_loop($dg_scope$(ctx_0, {$: "Nil"}))));
  return ("\n- message  : " + x_6);
})));
  const x_18 = (x_15 + x_16);
  const x_19 = (x_17 + x_18);
  return ("Error:" + x_19);
}

function $List$reverse$(xs_0) {
  return run_jump($List$reverse$go$, [xs_0, {$: "Nil"}]);
}

function $dg_has_span$(s_0) {
  if (s_0.$ === "DNoSpan") {
    return false;
  } else {
    const source_0 = s_0["source"];
    const begin_0 = s_0["begin"];
    const end_0 = s_0["end"];
    return true;
  }
}

function $dg_origin_trail$(origins_0, name_0, trail_0) {
  if (trail_0.$ === "Nil") {
    return {$: "DNoSpan"};
  } else {
    const h_0 = trail_0["head"];
    const rest_0 = trail_0["tail"];
    return run_jump($dg_origin_found$, [origins_0, name_0, rest_0, run_loop($dg_origin_scan$(origins_0, name_0, h_0, {$: "DNoSpan"}))]);
  }
}

function $fp_loaded_origins$(trace_0, all_0, definition_0) {
  const result_0 = trace_0["result"];
  const done_0 = trace_0["done"];
  const sources_0 = trace_0["sources"];
  return run_jump($fp_loaded_result$, [result_0, done_0, sources_0, all_0, definition_0]);
}

function $f_load_graph_trace$(main_0, sources_0) {
  return run_jump($f_graph_trace$, [run_loop($f_graph_load$(main_0, "", sources_0, {$: "FGraph", ["book"]: {$: "Nil"}, ["error"]: "", ["done"]: {$: "Nil"}}, {$: "Nil"})), sources_0]);
}

function $f_loaded_origins_for$(trace_0, definition_0) {
  return run_jump($fp_loaded_origins$, [trace_0, false, definition_0]);
}

function $String$starts_with$(s_0, p_0) {
  if (s_0 === "") {
    if (p_0 === "") {
      return true;
    } else {
      const h_0 = (p_0.codePointAt(0) > 0xFFFF ? p_0.slice(0, 2) : p_0[0]);
      const t_0 = (p_0.codePointAt(0) > 0xFFFF ? p_0.slice(2) : p_0.slice(1));
      return false;
    }
  } else {
    const h_1 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_1 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    if (p_0 === "") {
      return true;
    } else {
      const y_0 = (p_0.codePointAt(0) > 0xFFFF ? p_0.slice(0, 2) : p_0[0]);
      const yt_0 = (p_0.codePointAt(0) > 0xFFFF ? p_0.slice(2) : p_0.slice(1));
      return run_jump($String$starts_with$if$, [t_1, yt_0, run_loop($Char$is_eq$(h_1, y_0))]);
    }
  }
}

function $nc_ctor_decode$(rest_0, acc_0, digits_0, out_0, original_0) {
  if (rest_0 === "") {
    return run_jump($kc$, [run_loop($Bool$and$((digits_0 === 0), run_loop($String$eq$(run_loop($nc_ctor_encode$(out_0)), original_0)))), run_clo((x_0) => {
    return out_0;
}), run_clo((x_1) => {
    return original_0;
})]);
  } else {
    const h_0 = (rest_0.codePointAt(0) > 0xFFFF ? rest_0.slice(0, 2) : rest_0[0]);
    const tail_0 = (rest_0.codePointAt(0) > 0xFFFF ? rest_0.slice(2) : rest_0.slice(1));
    return run_jump($nc_ctor_decode_step$, [h_0, tail_0, acc_0, digits_0, out_0, original_0]);
  }
}

function $String$drop$(s_0, n_0) {
  if (s_0 === "") {
    return "";
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    if (n_0 === 0n) {
      return (h_0 + t_0);
    } else {
      const p_0 = (n_0 - 1n);
      return run_jump($String$drop$, [t_0, p_0]);
    }
  }
}

function $nc_ctor_codes$(name_0) {
  if (name_0 === "") {
    return "";
  } else {
    const h_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(0, 2) : name_0[0]);
    const rest_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(2) : name_0.slice(1));
    const x_0 = run_loop($nc_ctor_codes$(rest_0));
    const x_1 = run_loop($U32$show$(run_loop($Char$to_u32$(h_0))));
    const x_2 = ("_" + x_0);
    return (x_1 + x_2);
  }
}

function $db$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return native_0;
}

function $good$(r_0) {
  return run_jump($String$eq$, [run_loop($ce$(r_0)), ""]);
}

function $tg$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return tag_0;
}

function $ct$(r_0) {
  const term_0 = r_0["term"];
  const typ_0 = r_0["typ"];
  const uses_0 = r_0["uses"];
  const error_0 = r_0["error"];
  return term_0;
}

function $kt$(tag_0, name_0, id_0, quant_0, kids_0) {
  return {$: "KTerm", ["tag"]: tag_0, ["name"]: name_0, ["id"]: id_0, ["quant"]: quant_0, ["kids"]: kids_0, ["removed"]: {$: "Nil"}};
}

function $nm$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return name_0;
}

function $ix$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return id_0;
}

function $qt$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return quant_0;
}

function $kid$(t_0, n_0) {
  return run_jump($terms_at$, [run_loop($ks$(t_0)), n_0]);
}

function $norm_join$(a_0, b_0) {
  if (a_0.$ === "Nil") {
    return b_0;
  } else {
    const h_0 = a_0["head"];
    const t_0 = a_0["tail"];
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($norm_join$(t_0, b_0))};
  }
}

function $ks$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return kids_0;
}

function $cy$(r_0) {
  const term_0 = r_0["term"];
  const typ_0 = r_0["typ"];
  const uses_0 = r_0["uses"];
  const error_0 = r_0["error"];
  return typ_0;
}

function $cs$(r_0) {
  const term_0 = r_0["term"];
  const typ_0 = r_0["typ"];
  const uses_0 = r_0["uses"];
  const error_0 = r_0["error"];
  return uses_0;
}

function $ce$(r_0) {
  const term_0 = r_0["term"];
  const typ_0 = r_0["typ"];
  const uses_0 = r_0["uses"];
  const error_0 = r_0["error"];
  return error_0;
}

function $dg_trace_detail$(e_0, ctx_0, t_0, r_0, detail_0) {
  return {$: "KChecked", ["term"]: run_loop($kt$("DTrace", run_loop($cn$(e_0)), 0, run_loop($qt$(detail_0)), {$: "Con", ["head"]: run_loop($kid$(detail_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(detail_0, 1)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("DCtx", "", 0, 0, ctx_0)), ["tail"]: {$: "Con", ["head"]: t_0, ["tail"]: {$: "Con", ["head"]: run_loop($kt$("DTrail", "", 0, 0, {$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}}}}}})), ["typ"]: run_loop($cy$(r_0)), ["uses"]: run_loop($cs$(r_0)), ["error"]: run_loop($ce$(r_0))};
}

function $dg_reason$(e_0, ctx_0, t_0, ty_0, code_0) {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "undefined name")), run_clo((x_0) => {
  return run_jump($dg_pair$, [run_loop($dg_text$("a defined name")), t_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "unbound variable")), run_clo((x_2) => {
  return run_jump($dg_pair$, [run_loop($dg_text$("a bound variable")), t_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "nondecreasing self-call")), run_clo((x_4) => {
  return run_jump($dg_pair$, [run_loop($dg_text$("a decreasing self-call (arguments are read left to right: each passed unchanged until one shrinks)")), t_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "live use of an unfilled law")), run_clo((x_6) => {
  return run_jump($dg_pair$, [run_loop($dg_text$("a filled definition (an unfilled law is a dead claim: live code cannot use it)")), t_0]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "a family requires angle-bracket parameters")), run_clo((x_8) => {
  const x_9 = run_loop($nm$(t_0));
  const x_10 = (x_9 + "<..>)");
  return run_jump($dg_pair$, [run_loop($dg_text$(("a family instance (write " + x_10))), t_0]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "unresolved hole")), run_clo((x_12) => {
  return run_jump($dg_pair$, [ty_0, t_0]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "cannot infer: annotation required")), run_clo((x_14) => {
  return run_jump($dg_pair$, [run_loop($dg_text$(run_loop($kc$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr")), run_loop($String$eq$(run_loop($dg_family$(run_loop($cb$(e_0)), run_loop($nm$(t_0)))), "")))), run_clo((x_15) => {
  return "a declared constructor";
}), run_clo((x_16) => {
  return "an annotated term (cannot infer)";
}))))), t_0]);
}), run_clo((x_17) => {
  const x_18 = run_loop($String$eq$(code_0, "lambda requires a function type"));
  const x_19 = run_loop($String$eq$(code_0, "matcher requires a function type"));
  const x_20 = (x_18 || x_19);
  const x_21 = run_loop($String$eq$(code_0, "reflexivity requires equality goal"));
  return run_jump($kc$, [(x_20 || x_21), run_clo((x_22) => {
  return run_jump($dg_pair$, [ty_0, run_loop($dg_typeless$(run_loop($cb$(e_0)), ctx_0, t_0))]);
}), run_clo((x_23) => {
  return run_jump($kc$, [run_loop($String$eq$(code_0, "constructor requires a datatype goal")), run_clo((x_24) => {
  return run_jump($dg_pair$, [ty_0, run_loop($kc$(run_loop($String$eq$(run_loop($dg_family$(run_loop($cb$(e_0)), run_loop($nm$(t_0)))), "")), run_clo((x_25) => {
  return run_jump($dg_typeless$, [run_loop($cb$(e_0)), ctx_0, t_0]);
}), run_clo((x_26) => {
  return run_jump($ref$, [run_loop($dg_family$(run_loop($cb$(e_0)), run_loop($nm$(t_0))))]);
})))]);
}), run_clo((x_27) => {
  return run_jump($kt$, ["DDetail", "", 0, 0, {$: "Con", ["head"]: run_loop($dg_text$(code_0)), ["tail"]: {$: "Con", ["head"]: run_loop($atom$("Absent")), ["tail"]: {$: "Nil"}}}]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $check_lam$(e_0, ctx_0, t_0, dem_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
  const x_1 = run_loop($qt$(t_0));
  const x_2 = run_loop($qt$(ty_0));
  return run_jump($check_lam_q$, [e_0, ctx_0, t_0, dem_0, ty_0, run_loop($kc$(run_loop($Bool$and$((x_1 === 2), (x_2 === 1))), run_clo((x_3) => {
  return 2;
}), run_clo((x_4) => {
  return run_jump($qt$, [ty_0]);
})))]);
}), run_clo((x_5) => {
  return run_jump($bad$, ["lambda requires a function type"]);
})]);
}

function $cb$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return book_0;
}

function $check_ctr$(e_0, ctx_0, t_0, dem_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "ADT")), run_clo((x_0) => {
  return run_jump($check_ctr_found$, [e_0, ctx_0, t_0, dem_0, ty_0, run_loop($lookup$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(ty_0)))))), run_loop($nm$(t_0))))]);
}), run_clo((x_1) => {
  return run_jump($bad$, ["constructor requires a datatype goal"]);
})]);
}

function $check_mat$(e_0, ctx_0, t_0, dem_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
  const x_1 = run_loop($qt$(ty_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$((dem_0 === 0))), (x_1 === 0))), run_clo((x_2) => {
  return run_jump($dg_bad_message$, ["erased scrutinee in live match", run_loop($dg_text$("a live scrutinee (a - scrutinee matches only in a dead region)"))]);
}), run_clo((x_3) => {
  return run_jump($check_mat_type$, [e_0, ctx_0, t_0, dem_0, ty_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($kid$(ty_0, 0))))]);
})]);
}), run_clo((x_4) => {
  return run_jump($bad$, ["matcher requires a function type"]);
})]);
}

function $check_rfl$(e_0, t_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "Eql")), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($compare$(run_loop($cb$(e_0)), run_loop($kid$(ty_0, 0)), run_loop($kid$(ty_0, 1)), false)), run_clo((x_1) => {
  return run_jump($ok$, [t_0, ty_0, {$: "Nil"}]);
}), run_clo((x_2) => {
  return run_jump($dg_bad_detail$, ["reflexivity endpoints differ", run_loop($kid$(ty_0, 0)), run_loop($kid$(ty_0, 1))]);
})]);
}), run_clo((x_3) => {
  return run_jump($bad$, ["reflexivity requires equality goal"]);
})]);
}

function $bad$(msg_0) {
  return {$: "KChecked", ["term"]: run_loop($atom$("Error")), ["typ"]: run_loop($atom$("Error")), ["uses"]: {$: "Nil"}, ["error"]: msg_0};
}

function $check_let$(e_0, outer_0, ctx_0, xs_0, dem_0, ty_0, bindings_0, us_0) {
  if (xs_0.$ === "Nil") {
    return run_jump($bad$, ["let has no body"]);
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(h_0)), "Bind")), run_clo((x_0) => {
    return run_jump($check_let_value$, [e_0, outer_0, ctx_0, h_0, rest_0, dem_0, ty_0, bindings_0, us_0, run_loop($infer$(e_0, outer_0, run_loop($kid$(h_0, 0)), run_loop($qdem$(run_loop($qt$(h_0)), dem_0)), {$: "Nil"}))]);
}), run_clo((x_1) => {
    return run_jump($check_let_done$, [run_loop($check$(e_0, ctx_0, run_loop($let_cells$(h_0, bindings_0)), dem_0, ty_0)), bindings_0, us_0]);
})]);
  }
}

function $check_rwt$(e_0, ctx_0, t_0, dem_0, ty_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($check_rwt_type$, [e_0, ctx_0, t_0, dem_0, ty_0, r_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($cy$(r_0))))]);
}), run_clo((x_1) => {
  return r_0;
})]);
}

function $check_fits$(e_0, r_0, ty_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($compare$(run_loop($cb$(e_0)), run_loop($cy$(r_0)), ty_0, true)), run_clo((x_1) => {
  return run_jump($checked$, [r_0, run_loop($ct$(r_0)), ty_0]);
}), run_clo((x_2) => {
  return run_jump($dg_bad_detail$, ["type mismatch", ty_0, run_loop($cy$(r_0))]);
})]);
}), run_clo((x_3) => {
  return r_0;
})]);
}

function $core_apply$(f_0, x_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(f_0)), "Lam")), run_clo((x_1) => {
  return run_jump($subst$, [run_loop($kid$(f_0, 0)), run_loop($ix$(f_0)), x_0]);
}), run_clo((x_2) => {
  return run_jump($app$, [f_0, x_0]);
})]);
}

function $infer_var$(ctx_0, t_0, dem_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($ctx_get$(ctx_0, run_loop($ix$(t_0)))))), "Absent")), run_clo((x_0) => {
  return run_jump($bad$, ["unbound variable"]);
}), run_clo((x_1) => {
  return run_jump($ok$, [t_0, run_loop($kid$(run_loop($ctx_get$(ctx_0, run_loop($ix$(t_0)))), 0)), {$: "Con", ["head"]: run_loop($kt$("Use", "", run_loop($ix$(t_0)), dem_0, {$: "Nil"})), ["tail"]: {$: "Nil"}}]);
})]);
}

function $infer_ref$(e_0, t_0, dem_0, sp_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "Absent")), run_clo((x_0) => {
  return run_jump($bad$, ["undefined name"]);
}), run_clo((x_1) => {
  const x_2 = run_loop($da$(d_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), (x_2 > 0))), run_clo((x_3) => {
  return run_jump($bad$, ["a family requires angle-bracket parameters"]);
}), run_clo((x_4) => {
  return run_jump($kc$, [(dem_0 === 0), run_clo((x_5) => {
  return run_jump($ok$, [t_0, run_loop($dt$(d_0)), {$: "Nil"}]);
}), run_clo((x_6) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($nm$(t_0)), run_loop($cn$(e_0)))), run_loop($Bool$not$(run_loop($cu$(e_0)))))), run_loop($Bool$not$(run_loop($descend_spine$(run_loop($cq$(e_0)), sp_0, run_loop($unargs$(run_loop($cl$(e_0)), {$: "Nil"})))))))), run_clo((x_7) => {
  return run_jump($bad$, ["nondecreasing self-call"]);
}), run_clo((x_8) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")), run_loop($Bool$not$(run_loop($db$(d_0)))))), run_loop($Bool$not$(run_loop($cu$(e_0)))))), run_loop($Bool$not$(run_loop($String$eq$(run_loop($nm$(t_0)), run_loop($cn$(e_0)))))))), run_clo((x_9) => {
  return run_jump($bad$, ["live use of an unfilled law"]);
}), run_clo((x_10) => {
  return run_jump($infer_template$, [e_0, t_0, dem_0, sp_0, d_0]);
})]);
})]);
})]);
})]);
})]);
}

function $checked$(r_0, t_0, ty_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($ok$, [t_0, ty_0, run_loop($cs$(r_0))]);
}), run_clo((x_1) => {
  return r_0;
})]);
}

function $typ$(q_0) {
  return run_jump($kt$, ["Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($qua$(q_0)), ["tail"]: {$: "Nil"}}]);
}

function $ok$(t_0, ty_0, us_0) {
  return {$: "KChecked", ["term"]: t_0, ["typ"]: ty_0, ["uses"]: us_0, ["error"]: ""};
}

function $both$(a_0, b_0, t_0, ty_0, join_0) {
  return run_jump($kc$, [run_loop($good$(a_0)), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($good$(b_0)), run_clo((x_1) => {
  return run_jump($ok$, [t_0, ty_0, run_loop($uses_merge$(run_loop($cs$(a_0)), run_loop($cs$(b_0)), join_0))]);
}), run_clo((x_2) => {
  return b_0;
})]);
}), run_clo((x_3) => {
  return a_0;
})]);
}

function $kindq$(e_0, q_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($cu$(e_0)), (q_0 === 2))), run_clo((x_0) => {
  return 1;
}), run_clo((x_1) => {
  return q_0;
})]);
}

function $ctx_bind$(ctx_0, id_0, q_0, name_0, ty_0) {
  return {$: "Con", ["head"]: run_loop($kt$("Bind", name_0, id_0, q_0, {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}})), ["tail"]: ctx_0};
}

function $infer_app$(e_0, ctx_0, t_0, dem_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($infer_app_type$, [e_0, ctx_0, t_0, dem_0, r_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($cy$(r_0))))]);
}), run_clo((x_1) => {
  return r_0;
})]);
}

function $infer_adt$(e_0, ctx_0, t_0, dem_0, d_0) {
  const x_0 = run_loop($terms_len$(run_loop($ks$(t_0))));
  const x_1 = run_loop($da$(d_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), (x_0 === x_1))), run_clo((x_2) => {
  return run_jump($infer_adt_done$, [t_0, run_loop($tele_check$(e_0, ctx_0, run_loop($dt$(d_0)), run_loop($ks$(t_0)), dem_0))]);
}), run_clo((x_3) => {
  return run_jump($dg_adt_error$, [t_0, d_0]);
})]);
}

function $ka_def$(book_0, d_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Foreign"));
  const x_2 = run_loop($dx$(d_0));
  const x_3 = (x_0 || x_1);
  const x_4 = (x_2 > 0);
  return {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($dt$(d_0)), ["value"]: run_loop($kc$((x_3 || x_4), run_clo((x_5) => {
  return run_jump($dv$, [d_0]);
}), run_clo((x_6) => {
  return run_jump($annotate$, [{$: "KEnv", ["book"]: book_0, ["name"]: run_loop($dn$(d_0)), ["lhs"]: run_loop($ref$(run_loop($dn$(d_0)))), ["pending"]: 0, ["quantities"]: {$: "Nil"}, ["unsafe"]: run_loop($du$(d_0))}, {$: "Nil"}, run_loop($dv$(d_0)), run_loop($dt$(d_0))]);
}))), ["ctors"]: run_loop($dc$(d_0)), ["native"]: run_loop($db$(d_0)), ["unsafe"]: run_loop($du$(d_0))};
}

function $kp_eq$(a_0, b_0) {
  return run_jump($String$eq$, [a_0, b_0]);
}

function $kp_scope$(env_0, id_0, name_0) {
  if (env_0.$ === "Nil") {
    const x_0 = run_loop($U32$show$(id_0));
    const x_1 = ("^" + x_0);
    return (name_0 + x_1);
  } else {
    const _t_0 = env_0["head"];
    const n_0 = _t_0["name"];
    const i_0 = _t_0["id"];
    const depth_0 = _t_0["depth"];
    const tail_0 = env_0["tail"];
    return run_jump($kc$, [run_loop($kp_eq$(n_0, name_0)), run_clo((x_2) => {
    return run_jump($kc$, [(i_0 === id_0), run_clo((x_3) => {
    return name_0;
}), run_clo((x_4) => {
    const x_5 = run_loop($U32$show$(run_loop($kp_index$(tail_0, id_0))));
    const x_6 = ("^" + x_5);
    return (name_0 + x_6);
})]);
}), run_clo((x_7) => {
    return run_jump($kp_scope$, [tail_0, id_0, name_0]);
})]);
  }
}

function $kp_bound$(env_0, name_0) {
  if (env_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = env_0["head"];
    const n_0 = _t_0["name"];
    const i_0 = _t_0["id"];
    const depth_0 = _t_0["depth"];
    const t_0 = env_0["tail"];
    const x_0 = run_loop($kp_eq$(n_0, name_0));
    const x_1 = run_loop($kp_bound$(t_0, name_0));
    return (x_0 || x_1);
  }
}

function $Bool$and$(a_0, b_0) {
  if (!a_0) {
    return false;
  } else {
    return b_0;
  }
}

function $U32$show$(a_0) {
  const b_0 = a_0;
  return run_jump($U32$show$if$, [b_0, (b_0 === 0)]);
}

function $kp_par$(s_0, yes_0) {
  return run_jump($kc$, [yes_0, run_clo((x_0) => {
  const x_1 = (s_0 + ")");
  return ("(" + x_1);
}), run_clo((x_2) => {
  return s_0;
})]);
}

function $kp_quant$(q_0) {
  return run_jump($kc$, [(q_0 === 0), run_clo((x_0) => {
  return "-";
}), run_clo((x_1) => {
  return run_jump($kc$, [(q_0 === 2), run_clo((x_2) => {
  return "+";
}), run_clo((x_3) => {
  return "";
})]);
})]);
}

function $kp_bind$(env_0, t_0) {
  return {$: "Con", ["head"]: {$: "KPName", ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["depth"]: run_loop($kp_depth$(env_0))}, ["tail"]: env_0};
}

function $kp_go_tail$(t_0, p_0, env_0) {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($kp_application$, [run_loop($kp_spine$(t_0, {$: "Nil"})), p_0, env_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "ADT")), run_clo((x_2) => {
  return run_jump($kp_adt$, [t_0, p_0, env_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Ctr")), run_clo((x_4) => {
  return run_jump($kp_ctor$, [t_0, p_0, env_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_6) => {
  const x_7 = run_loop($kp_matches$(t_0, env_0));
  const x_8 = (x_7 + "}");
  return ("\\{" + x_8);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Efq")), run_clo((x_10) => {
  return "\\{}";
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Eql")), run_clo((x_12) => {
  const x_13 = run_loop($kp_go$(run_loop($kid$(t_0, 2)), 2, env_0));
  const x_14 = (x_13 + "}");
  const x_15 = run_loop($kp_go$(run_loop($kid$(t_0, 1)), 2, env_0));
  const x_16 = (" : " + x_14);
  const x_17 = (x_15 + x_16);
  const x_18 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 2, env_0));
  const x_19 = (" == " + x_17);
  const x_20 = (x_18 + x_19);
  return ("{" + x_20);
}), run_clo((x_21) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Rfl")), run_clo((x_22) => {
  return "{==}";
}), run_clo((x_23) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Hol")), run_clo((x_24) => {
  const x_25 = run_loop($nm$(t_0));
  return ("?" + x_25);
}), run_clo((x_26) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_27) => {
  const x_28 = run_loop($kp_go$(run_loop($kid$(t_0, 1)), 2, env_0));
  const x_29 = (x_28 + "}");
  const x_30 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 2, env_0));
  const x_31 = (" : " + x_29);
  const x_32 = (x_30 + x_31);
  return ("{" + x_32);
}), run_clo((x_33) => {
  return run_jump($kp_go_last$, [t_0, p_0, env_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $sp_book$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return book_0;
}

function $sp_error$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return error_0;
}

function $sp_definition_next$(rest_0, st_0, d_0) {
  const x_0 = run_loop($dx$(d_0));
  const x_1 = (x_0 > 0);
  const x_2 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent"));
  const x_3 = (x_1 || x_2);
  const x_4 = run_loop($String$eq$(run_loop($dk$(d_0)), "ADT"));
  const x_5 = (x_3 || x_4);
  const x_6 = run_loop($Bool$not$(run_loop($sp_needed$(run_loop($sp_templates$(st_0)), run_loop($dv$(d_0))))));
  return run_jump($kc$, [(x_5 || x_6), run_clo((x_7) => {
  return run_jump($sp_definitions$, [rest_0, st_0]);
}), run_clo((x_8) => {
  return run_jump($sp_definition_done$, [rest_0, d_0, run_loop($sp_term$(st_0, run_loop($dv$(d_0)), {$: "Nil"}, run_loop($dt$(d_0)), run_loop($dn$(d_0)), 0))]);
})]);
}

function $sp_stamp$(book_0, bound_0) {
  return {$: "Con", ["head"]: {$: "KDef", ["name"]: "$kernel.max-id", ["kind"]: "BookBound", ["arity"]: bound_0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: false}, ["tail"]: run_loop($index_remove$(book_0, "$kernel.max-id"))};
}

function $sp_template_book$(book_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    const x_0 = run_loop($dx$(h_0));
    return run_jump($kc$, [(x_0 > 0), run_clo((x_1) => {
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($sp_template_book$(rest_0))};
}), run_clo((x_2) => {
    return run_jump($sp_template_book$, [rest_0]);
})]);
  }
}

function $book_final_fast$(book_0, done_0) {
  return run_jump($kc$, [run_loop($book_final_large$(book_0, 256)), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($book_final_names_valid$(book_0)), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($book_final_names_valid$(done_0)), run_clo((x_2) => {
  return run_jump($book_final_scan$, [run_loop($book_final_reverse$(book_0, {$: "Nil"})), run_loop($missing$()), {$: "Nil"}, done_0]);
}), run_clo((x_3) => {
  return run_jump($book_final_legacy$, [book_0, done_0]);
})]);
}), run_clo((x_4) => {
  return run_jump($book_final_legacy$, [book_0, done_0]);
})]);
}), run_clo((x_5) => {
  return run_jump($book_final_legacy$, [book_0, done_0]);
})]);
}

function $norm_max_defs$(todo_0, bound_0) {
  if (todo_0.$ === "Nil") {
    return bound_0;
  } else {
    const h_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($norm_max_defs$, [run_loop($norm_defs_join$(run_loop($dc$(h_0)), rest_0)), run_loop($norm_max$(bound_0, run_loop($norm_max$(run_loop($norm_max_term$(run_loop($dt$(h_0)))), run_loop($norm_max_term$(run_loop($dv$(h_0))))))))]);
  }
}

function $g_start$(book_0, t_0, bound_0) {
  return run_jump($g_snf_go$, [run_loop($book_cached$(book_0, bound_0)), {$: "GState", ["heap"]: {$: "GEmpty"}, ["next"]: 1}, t_0, {$: "Nil"}, ((bound_0 + 1) >>> 0)]);
}

function $norm_var$(book_0, t_0, values_0, args_0, left_0, fallback_0) {
  if (values_0.$ === "Nil") {
    return run_jump($norm_apply$, [t_0, args_0]);
  } else {
    const h_0 = values_0["head"];
    const rest_0 = values_0["tail"];
    return run_jump($norm_eval$, [book_0, h_0, args_0, left_0, fallback_0]);
  }
}

function $norm_eval_node$(book_0, t_0, args_0, left_0, fallback_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($norm_eval$, [book_0, run_loop($kid$(t_0, 0)), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: args_0}, left_0, fallback_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_2) => {
  return run_jump($norm_eval$, [book_0, run_loop($kid$(t_0, 0)), args_0, left_0, fallback_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_4) => {
  return run_jump($norm_eval$, [book_0, run_loop($norm_let$(run_loop($ks$(t_0)))), args_0, left_0, fallback_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_6) => {
  return run_jump($norm_ref$, [book_0, t_0, args_0, run_loop($lookup$(book_0, run_loop($nm$(t_0))))]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Min")), run_clo((x_8) => {
  return run_jump($norm_apply$, [run_loop($norm_min$(book_0, run_loop($kid$(t_0, 0)), run_loop($kid$(t_0, 1)))), args_0]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_10) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($wnf$(book_0, run_loop($kid$(t_0, 0)))))), "Rfl")), run_clo((x_11) => {
  return run_jump($norm_eval$, [book_0, run_loop($kid$(t_0, 2)), args_0, left_0, fallback_0]);
}), run_clo((x_12) => {
  return run_jump($norm_apply$, [t_0, args_0]);
})]);
}), run_clo((x_13) => {
  return run_jump($norm_args$, [book_0, t_0, args_0, left_0, fallback_0]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $norm_exact$(a_0, b_0) {
  return run_jump($norm_exact_lists$, [{$: "Con", ["head"]: a_0, ["tail"]: {$: "Nil"}}, {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}]);
}

function $norm_cmp_loop$(book_0, todo_0, alts_0) {
  if (todo_0.$ === "Nil") {
    return true;
  } else {
    const _t_0 = todo_0["head"];
    const a_0 = _t_0["a"];
    const b_0 = _t_0["b"];
    const le_0 = _t_0["le"];
    const fresh_0 = _t_0["fresh"];
    const rest_0 = todo_0["tail"];
    return run_jump($kc$, [run_loop($norm_cmp_quick$(a_0, b_0)), run_clo((x_0) => {
    return run_jump($norm_cmp_loop$, [book_0, rest_0, alts_0]);
}), run_clo((x_1) => {
    return run_jump($norm_cmp_heads$, [book_0, run_loop($wnf$(book_0, a_0)), run_loop($wnf$(book_0, b_0)), le_0, fresh_0, rest_0, alts_0]);
})]);
  }
}

function $norm_bound_found$(book_0, stamp_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(stamp_0)), "BookBound")), run_clo((x_0) => {
  return run_jump($da$, [stamp_0]);
}), run_clo((x_1) => {
  return run_jump($norm_max_book$, [book_0]);
})]);
}

function $norm_max_walk$(todo_0, bound_0) {
  if (todo_0.$ === "Nil") {
    return bound_0;
  } else {
    const h_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($norm_max_walk$, [run_loop($norm_join$(run_loop($ks$(h_0)), rest_0)), run_loop($norm_max$(bound_0, run_loop($ix$(h_0))))]);
  }
}

function $exact_def$(a_0, b_0) {
  const x_0 = run_loop($da$(a_0));
  const x_1 = run_loop($da$(b_0));
  const x_2 = run_loop($dx$(a_0));
  const x_3 = run_loop($dx$(b_0));
  const x_4 = run_loop($db$(a_0));
  const x_5 = run_loop($db$(b_0));
  const x_6 = run_loop($du$(a_0));
  const x_7 = run_loop($du$(b_0));
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($dn$(a_0)), run_loop($dn$(b_0)))), run_loop($String$eq$(run_loop($dk$(a_0)), run_loop($dk$(b_0)))))), (x_0 === x_1))), (x_2 === x_3))), run_loop($Bool$not$((x_4 !== x_5))))), run_loop($Bool$not$((x_6 !== x_7))))), run_loop($exact_term$(run_loop($dt$(a_0)), run_loop($dt$(b_0)))))), run_loop($exact_term$(run_loop($dv$(a_0)), run_loop($dv$(b_0)))))), run_loop($exact_defs$(run_loop($dc$(a_0)), run_loop($dc$(b_0))))]);
}

function $dg_prefix_seed$(todo_0, validated_0, done_0, original_0, origins_0) {
  if (validated_0.$ === "Nil") {
    return run_jump($dg_suffix_events$, [todo_0, done_0, original_0, origins_0]);
  } else {
    const head_0 = validated_0["head"];
    const tail_0 = validated_0["tail"];
    return run_jump($dg_prefix_step$, [todo_0, head_0, tail_0, done_0, original_0, origins_0]);
  }
}

function $has_name$(ns_0, name_0) {
  if (ns_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = ns_0["head"];
    const t_0 = ns_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(h_0, name_0)), run_clo((x_0) => {
    return true;
}), run_clo((x_1) => {
    return run_jump($has_name$, [t_0, name_0]);
})]);
  }
}

function $kr_visit_def$(book_0, todo_0, seen_0, stops_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "Absent")), run_clo((x_0) => {
  return run_jump($kr_visit$, [book_0, todo_0, seen_0, stops_0]);
}), run_clo((x_1) => {
  return run_jump($kr_visit$, [book_0, run_loop($kr_dependencies$(d_0, stops_0, todo_0)), {$: "Con", ["head"]: run_loop($dn$(d_0)), ["tail"]: seen_0}, stops_0]);
})]);
}

function $kr_resolve$(book_0, name_0) {
  return run_jump($kr_resolve_head$, [book_0, name_0, run_loop($lookup$(book_0, name_0))]);
}

function $String$eq$fin$(r_0) {
  const _t_0 = r_0["fst"];
  const a2_0 = _t_0["fst"];
  const b2_0 = _t_0["snd"];
  const c_0 = r_0["snd"];
  return run_jump($Cmp$is_eq$, [c_0]);
}

function $String$cmp$(a_0, b_0) {
  if (a_0 === "") {
    if (b_0 === "") {
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: "", ["snd"]: ""}, ["snd"]: {$: "EQ"}};
    } else {
      const h_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(0, 2) : b_0[0]);
      const t_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(2) : b_0.slice(1));
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: "", ["snd"]: (h_0 + t_0)}, ["snd"]: {$: "LT"}};
    }
  } else {
    const h_1 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(0, 2) : a_0[0]);
    const t_1 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(2) : a_0.slice(1));
    if (b_0 === "") {
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h_1 + t_1), ["snd"]: ""}, ["snd"]: {$: "GT"}};
    } else {
      const h2_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(0, 2) : b_0[0]);
      const t2_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(2) : b_0.slice(1));
      return run_jump($String$cmp$fin$, [t_1, t2_0, run_loop($Char$cmp$(h_1, h2_0))]);
    }
  }
}

function $index_find$(tree_0, name_0, hash_0, bits_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(tree_0)), "Absent")), run_clo((x_0) => {
  return run_jump($missing$, []);
}), run_clo((x_1) => {
  const x_2 = run_loop($dx$(tree_0));
  return run_jump($kc$, [(x_2 === 0), run_clo((x_3) => {
  const x_4 = run_loop($da$(tree_0));
  return run_jump($kc$, [(x_4 === hash_0), run_clo((x_5) => {
  return run_jump($index_bucket$, [run_loop($dc$(tree_0)), name_0]);
}), run_clo((x_6) => {
  return run_jump($missing$, []);
})]);
}), run_clo((x_7) => {
  const x_8 = run_loop($dx$(tree_0));
  const x_9 = ((hash_0 & x_8) >>> 0);
  return run_jump($index_find$, [run_loop($index_child$(tree_0, run_loop($Bool$not$((x_9 === 0))))), name_0, hash_0, bits_0]);
})]);
})]);
}

function $index_leaf$(d_0, hash_0, ds_0) {
  return {$: "KDef", ["name"]: "", ["kind"]: "IndexLeaf", ["arity"]: hash_0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_remove$(ds_0, run_loop($dn$(d_0))))}, ["native"]: true, ["unsafe"]: false};
}

function $index_insert$(tree_0, d_0, hash_0, mask_0) {
  const x_0 = run_loop($dx$(tree_0));
  const x_1 = run_loop($dx$(tree_0));
  const x_2 = (x_0 === 0);
  const x_3 = (mask_0 < x_1);
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$((mask_0 === 0))), (x_2 || x_3))), run_clo((x_4) => {
  return run_jump($index_join$, [tree_0, d_0, hash_0, mask_0]);
}), run_clo((x_5) => {
  const x_6 = run_loop($dx$(tree_0));
  return run_jump($kc$, [(x_6 === 0), run_clo((x_7) => {
  return run_jump($index_leaf$, [d_0, hash_0, run_loop($dc$(tree_0))]);
}), run_clo((x_8) => {
  const x_9 = run_loop($dx$(tree_0));
  const x_10 = ((hash_0 & x_9) >>> 0);
  return run_jump($kc$, [(x_10 === 0), run_clo((x_11) => {
  return run_jump($index_node$, [run_loop($da$(tree_0)), run_loop($dx$(tree_0)), run_loop($index_insert$(run_loop($index_child$(tree_0, false)), d_0, hash_0, mask_0)), run_loop($index_child$(tree_0, true))]);
}), run_clo((x_12) => {
  return run_jump($index_node$, [run_loop($da$(tree_0)), run_loop($dx$(tree_0)), run_loop($index_child$(tree_0, false)), run_loop($index_insert$(run_loop($index_child$(tree_0, true)), d_0, hash_0, mask_0))]);
})]);
})]);
})]);
}

function $index_split_bit$(diff_0) {
  const x_0 = ((0 - diff_0) >>> 0);
  return ((diff_0 & x_0) >>> 0);
}

function $index_tip$(tree_0, hash_0) {
  const x_0 = run_loop($dx$(tree_0));
  return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
  return tree_0;
}), run_clo((x_2) => {
  const x_3 = run_loop($dx$(tree_0));
  const x_4 = ((hash_0 & x_3) >>> 0);
  return run_jump($index_tip$, [run_loop($index_child$(tree_0, run_loop($Bool$not$((x_4 === 0))))), hash_0]);
})]);
}

function $Char$to_u32$(c_0) {
  const x_0 = c_0.codePointAt(0);
  return x_0;
}

function $Bool$not$(b_0) {
  if (!b_0) {
    return true;
  } else {
    return false;
  }
}

function $fpe_render$(source_0, error_0) {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(error_0)), "Absent")), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  const x_2 = run_loop($ix$(error_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(error_0)), "Error")), run_loop($String$eq$(run_loop($tg$(run_loop($kid$(error_0, 0)))), "ParseExpected")))), run_loop($String$eq$(run_loop($tg$(run_loop($kid$(error_0, 1)))), "ParseToken")))), (x_2 > 0))), run_clo((x_3) => {
  return run_jump($fpe_seek$, [source_0, source_0, 1, 0, error_0]);
}), run_clo((x_4) => {
  return run_jump($nm$, [error_0]);
})]);
})]);
}

function $f_top$(ts_0, book_0, imports_0, unsafe_0) {
  return run_jump($f_choose$, [unsafe_0, run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "def")), run_clo((x_1) => {
  return run_jump($f_top_ready$, [ts_0, book_0, imports_0, unsafe_0]);
}), run_clo((x_2) => {
  return run_jump($f_result$, [book_0, run_loop($f_pn$(run_loop($f_err$(ts_0, "expected def after @unsafe")))), imports_0]);
})]);
}), run_clo((x_3) => {
  return run_jump($f_top_ready$, [ts_0, book_0, imports_0, unsafe_0]);
})]);
}

function $f_skip$(ts_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "\n"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), ";"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_skip$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_3) => {
  return ts_0;
})]);
}

function $String$is_empty$(s_0) {
  if (s_0 === "") {
    return true;
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return false;
  }
}

function $f_ascii_char_eq$(a_0, b_0) {
  const x_0 = run_loop($Char$to_u32$(a_0));
  const x_1 = run_loop($Char$to_u32$(b_0));
  return (x_0 === x_1);
}

function $f_head$(s_0) {
  if (s_0 === "") {
    return "\u0000";
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return h_0;
  }
}

function $f_tail$(s_0) {
  if (s_0 === "") {
    return "";
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return t_0;
  }
}

function $f_ascii_space$(c_0) {
  return run_jump($f_ascii_space_code$, [run_loop($Char$to_u32$(c_0))]);
}

function $f_scan_comment$(s_0) {
  const x_0 = run_loop($String$is_empty$(s_0));
  const x_1 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "\n"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return s_0;
}), run_clo((x_3) => {
  return run_jump($f_scan_comment$, [run_loop($f_tail$(s_0))]);
})]);
}

function $f_lex_scanned$(sc_0, l_0, c_0, d_0, k_0, acc_0) {
  const word_0 = sc_0["word"];
  const rest_0 = sc_0["rest"];
  const size_0 = sc_0["size"];
  return run_jump($f_choose$, [(size_0 === 0), run_clo((x_0) => {
  return run_jump($List$reverse$, [{$: "Con", ["head"]: {$: "FToken", ["text"]: "unterminated string", ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: 3}, ["tail"]: acc_0}]);
}), run_clo((x_1) => {
  return run_jump($f_lex$, [rest_0, l_0, ((c_0 + size_0) >>> 0), d_0, {$: "Con", ["head"]: {$: "FToken", ["text"]: word_0, ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: k_0}, ["tail"]: acc_0}]);
})]);
}

function $f_scan_quote$(s_0, quote_0, acc_0, n_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return {$: "FScanned", ["word"]: "", ["rest"]: "", ["size"]: 0};
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), quote_0)), run_clo((x_2) => {
  return {$: "FScanned", ["word"]: run_loop($String$reverse$((quote_0 + acc_0))), ["rest"]: run_loop($f_tail$(s_0)), ["size"]: ((n_0 + 1) >>> 0)};
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "\\")), run_clo((x_4) => {
  return run_jump($f_scan_quote$, [run_loop($f_tail$(run_loop($f_tail$(s_0)))), quote_0, (run_loop($f_head$(run_loop($f_tail$(s_0)))) + ("\\" + acc_0)), ((n_0 + 2) >>> 0)]);
}), run_clo((x_5) => {
  return run_jump($f_scan_quote$, [run_loop($f_tail$(s_0)), quote_0, (run_loop($f_head$(s_0)) + acc_0), ((n_0 + 1) >>> 0)]);
})]);
})]);
})]);
}

function $f_ident$(c_0) {
  return run_jump($f_ascii_ident_code$, [run_loop($Char$to_u32$(c_0))]);
}

function $f_scan_word$(s_0, acc_0, n_0) {
  return run_jump($f_choose$, [run_loop($f_choose$(run_loop($f_ident$(run_loop($f_head$(s_0)))), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  const x_2 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "+"));
  const x_3 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "-"));
  const x_4 = run_loop($f_ascii_char_eq$(run_loop($f_head$(acc_0)), "e"));
  const x_5 = run_loop($f_ascii_char_eq$(run_loop($f_head$(acc_0)), "E"));
  return run_jump($Bool$and$, [run_loop($Bool$and$((x_2 || x_3), (x_4 || x_5))), run_loop($f_ascii_digit$(run_loop($f_head$(run_loop($f_tail$(s_0))))))]);
}))), run_clo((x_6) => {
  return run_jump($f_scan_word$, [run_loop($f_tail$(s_0)), (run_loop($f_head$(s_0)) + acc_0), ((n_0 + 1) >>> 0)]);
}), run_clo((x_7) => {
  return {$: "FScanned", ["word"]: run_loop($String$reverse$(acc_0)), ["rest"]: s_0, ["size"]: n_0};
})]);
}

function $f_triple_op$(s_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_three$(s_0)), ".&."));
  const x_1 = run_loop($f_eq$(run_loop($f_three$(s_0)), ".|."));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($f_three$(s_0)), ".^."));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(run_loop($f_three$(s_0)), "<&>"));
  return (x_4 || x_5);
}

function $f_three$(s_0) {
  return (run_loop($f_head$(s_0)) + (run_loop($f_head$(run_loop($f_tail$(s_0)))) + (run_loop($f_head$(run_loop($f_tail$(run_loop($f_tail$(s_0)))))) + "")));
}

function $f_lex_symbol$(s_0, l_0, c_0, d_0, acc_0) {
  const x_0 = run_loop($f_tx$(acc_0));
  const x_1 = BigInt([...x_0].length);
  const x_2 = run_loop($f_col$(acc_0));
  const x_3 = Number(x_1 & 0xFFFFFFFFn);
  const x_4 = ((x_2 + x_3) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_pair_op$(run_loop($f_two$(s_0)))), run_loop($Bool$not$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_two$(s_0)), "++")), run_loop($String$ends_with$(run_loop($f_tx$(acc_0)), "n")))), (c_0 === x_4))))))), run_clo((x_5) => {
  const x_6 = run_loop($f_tx$(acc_0));
  const x_7 = BigInt([...x_6].length);
  const x_8 = run_loop($f_col$(acc_0));
  const x_9 = Number(x_7 & 0xFFFFFFFFn);
  const x_10 = ((x_8 + x_9) >>> 0);
  return run_jump($f_lex$, [run_loop($f_tail$(run_loop($f_tail$(s_0)))), l_0, ((c_0 + 2) >>> 0), d_0, {$: "Con", ["head"]: {$: "FToken", ["text"]: run_loop($f_choose$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_two$(s_0)), ">>")), (c_0 > x_10))), run_clo((x_11) => {
  return ">>op";
}), run_clo((x_12) => {
  return run_jump($f_two$, [s_0]);
}))), ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: 0}, ["tail"]: acc_0}]);
}), run_clo((x_13) => {
  const x_14 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "("));
  const x_15 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "["));
  const x_16 = (x_14 || x_15);
  const x_17 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "{"));
  return run_jump($f_lex$, [run_loop($f_tail$(s_0)), l_0, ((c_0 + 1) >>> 0), run_loop($f_choose$((x_16 || x_17), run_clo((x_18) => {
  return ((d_0 + 1) >>> 0);
}), run_clo((x_19) => {
  const x_20 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), ")"));
  const x_21 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "]"));
  const x_22 = (x_20 || x_21);
  const x_23 = run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "}"));
  return run_jump($f_choose$, [(x_22 || x_23), run_clo((x_24) => {
  return ((d_0 - 1) >>> 0);
}), run_clo((x_25) => {
  return d_0;
})]);
}))), {$: "Con", ["head"]: {$: "FToken", ["text"]: run_loop($f_symbol_text$(s_0, c_0, acc_0)), ["f_line"]: l_0, ["f_col"]: c_0, ["f_kind"]: 0}, ["tail"]: acc_0}]);
})]);
}

function $fpe_graph_result$(graph_0, sources_0, result_0) {
  const book_0 = graph_0["book"];
  const error_0 = graph_0["error"];
  const done_0 = graph_0["done"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(error_0)), run_clo((x_0) => {
  return run_jump($fpe_rejected$, [result_0, book_0, done_0, sources_0]);
}), run_clo((x_1) => {
  return result_0;
})]);
}

function $f_graph_result$(g_0) {
  const book_0 = g_0["book"];
  const err_0 = g_0["error"];
  const done_0 = g_0["done"];
  return run_jump($f_fresh_result$, [run_loop($f_graph_fresh_result$(run_loop($f_validate_result$({$: "FResult", ["book"]: book_0, ["error"]: err_0, ["imports"]: {$: "Nil"}}))))]);
}

function $f_graph_source_load$(s_0, ns_0, sources_0, g_0, stack_0) {
  const book_0 = g_0["book"];
  const err_0 = g_0["error"];
  const done_0 = g_0["done"];
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($String$is_empty$(err_0)))), run_clo((x_0) => {
  return {$: "FGraph", ["book"]: book_0, ["error"]: err_0, ["done"]: done_0};
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($String$is_empty$(run_loop($f_source_path$(s_0)))), run_clo((x_2) => {
  return {$: "FGraph", ["book"]: book_0, ["error"]: "module source was not supplied", ["done"]: done_0};
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($has_name$(stack_0, run_loop($f_source_path$(s_0)))), run_clo((x_4) => {
  const x_5 = run_loop($f_source_path$(s_0));
  return {$: "FGraph", ["book"]: book_0, ["error"]: ("cyclic import through " + x_5), ["done"]: done_0};
}), run_clo((x_6) => {
  return run_jump($f_graph_cached$, [s_0, ns_0, sources_0, {$: "FGraph", ["book"]: book_0, ["error"]: err_0, ["done"]: done_0}, stack_0, run_loop($f_env$(run_loop($f_source_path$(s_0)), done_0))]);
})]);
})]);
})]);
}

function $f_eq$(a_0, b_0) {
  return run_jump($String$eq$, [a_0, b_0]);
}

function $f_source_name$(source_0) {
  if (source_0.$ === "FSource") {
    const name_0 = source_0["name"];
    const path_0 = source_0["path"];
    const text_0 = source_0["text"];
    return name_0;
  } else {
    const name_1 = source_0["name"];
    const path_1 = source_0["path"];
    const text_1 = source_0["text"];
    const parsed_0 = source_0["parsed"];
    return name_1;
  }
}

function $f_source_path$(source_0) {
  if (source_0.$ === "FSource") {
    const name_0 = source_0["name"];
    const path_0 = source_0["path"];
    const text_0 = source_0["text"];
    return path_0;
  } else {
    const name_1 = source_0["name"];
    const path_1 = source_0["path"];
    const text_1 = source_0["text"];
    const parsed_0 = source_0["parsed"];
    return path_1;
  }
}

function $f_seed_text_equal$(a_0, b_0) {
  if (a_0 === "") {
    if (b_0 === "") {
      return true;
    } else {
      return false;
    }
  } else {
    const x_0 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(0, 2) : a_0[0]);
    const xs_0 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(2) : a_0.slice(1));
    if (b_0 !== "") {
      const y_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(0, 2) : b_0[0]);
      const ys_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(2) : b_0.slice(1));
      return run_jump($f_choose$, [run_loop($Char$is_eq$(x_0, y_0)), run_clo((x_1) => {
      return run_jump($f_seed_text_equal$, [xs_0, ys_0]);
}), run_clo((x_2) => {
      return false;
})]);
    } else {
      return false;
    }
  }
}

function $f_source_text$(source_0) {
  if (source_0.$ === "FSource") {
    const name_0 = source_0["name"];
    const path_0 = source_0["path"];
    const text_0 = source_0["text"];
    return text_0;
  } else {
    const name_1 = source_0["name"];
    const path_1 = source_0["path"];
    const text_1 = source_0["text"];
    const parsed_0 = source_0["parsed"];
    return text_1;
  }
}

function $fs_source$(s_0, ns_0, sources_0, g_0, stack_0, seed_0) {
  const book_0 = g_0["book"];
  const err_0 = g_0["error"];
  const done_0 = g_0["done"];
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($String$is_empty$(err_0)))), run_clo((x_0) => {
  return {$: "FGraph", ["book"]: book_0, ["error"]: err_0, ["done"]: done_0};
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($String$is_empty$(run_loop($f_source_path$(s_0)))), run_clo((x_2) => {
  return {$: "FGraph", ["book"]: book_0, ["error"]: "module source was not supplied", ["done"]: done_0};
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($has_name$(stack_0, run_loop($f_source_path$(s_0)))), run_clo((x_4) => {
  const x_5 = run_loop($f_source_path$(s_0));
  return {$: "FGraph", ["book"]: book_0, ["error"]: ("cyclic import through " + x_5), ["done"]: done_0};
}), run_clo((x_6) => {
  return run_jump($fs_cached$, [s_0, ns_0, sources_0, {$: "FGraph", ["book"]: book_0, ["error"]: err_0, ["done"]: done_0}, stack_0, run_loop($f_env$(run_loop($f_source_path$(s_0)), done_0)), seed_0]);
})]);
})]);
})]);
}

function $f_main_order$(book_0, seen_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($f_choose$, [run_loop($f_main_seen$(run_loop($dn$(d_0)), seen_0)), run_clo((x_0) => {
    return run_jump($f_main_order$, [rest_0, seen_0]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: run_loop($dn$(d_0)), ["tail"]: run_loop($f_main_order$(rest_0, {$: "Con", ["head"]: run_loop($dn$(d_0)), ["tail"]: seen_0}))};
})]);
  }
}

function $ffw_walk$(term_0, env_0, next_0, stack_0) {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Var")), run_clo((x_0) => {
  return run_jump($ffw_done$, [run_loop($f_rename_var$(term_0, env_0)), next_0, stack_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "All")), run_clo((x_2) => {
  return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), env_0, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFAllA", ["term"]: term_0, ["env"]: env_0, ["id"]: next_0}, ["tail"]: stack_0}]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Lam")), run_clo((x_4) => {
  return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(term_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(term_0)), next_0)), ["tail"]: {$: "Nil"}})), ["tail"]: env_0}, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFLambda", ["term"]: term_0, ["id"]: next_0}, ["tail"]: stack_0}]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Let")), run_clo((x_6) => {
  return run_jump($ffw_let$, [env_0, env_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
}), run_clo((x_7) => {
  return run_jump($ffw_kids$, [term_0, env_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
})]);
})]);
})]);
})]);
}

function $ffd_walk$(book_0, next_0, built_0, stack_0) {
  if (book_0.$ === "Nil") {
    return run_jump($ffd_done$, [run_loop($List$reverse$(built_0)), next_0, stack_0]);
  } else {
    const definition_0 = book_0["head"];
    const pending_0 = book_0["tail"];
    return run_jump($ffd_type$, [definition_0, pending_0, built_0, stack_0, run_loop($f_fresh_term$(run_loop($dt$(definition_0)), {$: "Nil"}, next_0))]);
  }
}

function $dg_suffix_finish$(done_0, original_0, origins_0, error_0) {
  return run_jump($kc$, [run_loop($String$eq$(error_0, "")), run_clo((x_0) => {
  return {$: "DResult", ["error"]: "", ["book"]: original_0, ["diagnostic"]: run_loop($dg_no_report$("", ""))};
}), run_clo((x_1) => {
  return run_jump($dg_finish$, [error_0, done_0, run_loop($dg_no_report$("", error_0)), origins_0]);
})]);
}

function $check_open$(book_0) {
  return run_jump($check_open_message$, [run_loop($count_open$(book_0))]);
}

function $dg_suffix_guard$(rest_0, done_0, d_0, original_0, origins_0, guard_0) {
  return run_jump($kc$, [run_loop($String$eq$(guard_0, "")), run_clo((x_0) => {
  return run_jump($dg_suffix_check$, [rest_0, done_0, d_0, original_0, origins_0, run_loop($check_definition_result$(run_loop($book_put$(done_0, run_loop($declared$(d_0)))), run_loop($signature_mode$(d_0, rest_0))))]);
}), run_clo((x_1) => {
  const x_2 = run_loop($dn$(d_0));
  const x_3 = (": " + guard_0);
  return run_jump($dg_finish$, [(x_2 + x_3), done_0, run_loop($dg_no_report$(run_loop($dn$(d_0)), guard_0)), origins_0]);
})]);
}

function $event_error$(done_0, d_0, old_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(old_0)), "Absent")), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_1) => {
  return run_jump($constructor_names$, [done_0, run_loop($dc$(d_0)), {$: "Nil"}]);
}), run_clo((x_2) => {
  return "";
})]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(old_0)), "Def")), run_loop($String$eq$(run_loop($dk$(d_0)), "Def")))), run_loop($String$eq$(run_loop($tg$(run_loop($dv$(old_0)))), "Absent")))), run_loop($Bool$not$(run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")))))), run_clo((x_4) => {
  const x_5 = run_loop($dx$(old_0));
  const x_6 = run_loop($dx$(d_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($compare$(done_0, run_loop($dt$(old_0)), run_loop($dt$(d_0)), false)), (x_5 === x_6))), run_clo((x_7) => {
  return "";
}), run_clo((x_8) => {
  return "definition does not match prior law signature";
})]);
}), run_clo((x_9) => {
  return "duplicate declaration";
})]);
})]);
}

function $terms_len$(ts_0) {
  if (ts_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    const x_0 = run_loop($terms_len$(t_0));
    return ((1 + x_0) >>> 0);
  }
}

function $dg_expr$(book_0, expr_0, env_0) {
  if (expr_0.$ === "DText") {
    const text_0 = expr_0["text"];
    return text_0;
  } else {
    const term_0 = expr_0["term"];
    return run_jump($kp_go$, [run_loop($strong$(book_0, term_0)), 0, env_0]);
  }
}

function $dg_scope$(ctx_0, env_0) {
  if (ctx_0.$ === "Nil") {
    return env_0;
  } else {
    const h_0 = ctx_0["head"];
    const rest_0 = ctx_0["tail"];
    return run_jump($dg_scope$, [rest_0, run_loop($kp_bind$(env_0, h_0))]);
  }
}

function $dg_context$(book_0, ctx_0, env_0, width_0) {
  if (ctx_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ctx_0["head"];
    const rest_0 = ctx_0["tail"];
    const x_0 = run_loop($dg_expr$(book_0, {$: "DTerm", ["term"]: run_loop($kid$(h_0, 0))}, env_0));
    const x_1 = run_loop($dg_context$(book_0, rest_0, run_loop($kp_bind$(env_0, h_0)), width_0));
    const x_2 = (x_0 + x_1);
    const x_3 = run_loop($dg_rpad$(run_loop($nm$(h_0)), width_0));
    const x_4 = (" : " + x_2);
    const x_5 = (x_3 + x_4);
    return ("\n- " + x_5);
  }
}

function $dg_context_width$(ctx_0) {
  if (ctx_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = ctx_0["head"];
    const rest_0 = ctx_0["tail"];
    return run_jump($norm_max$, [run_loop($dg_width$(run_loop($nm$(h_0)))), run_loop($dg_context_width$(rest_0))]);
  }
}

function $dg_location$(name_0, span_0) {
  return run_jump($dg_location_text$, [name_0, run_loop($dg_snippet$(span_0))]);
}

function $List$reverse$go$(xs_0, acc_0) {
  if (xs_0.$ === "Nil") {
    return acc_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return run_jump($List$reverse$go$, [t_0, {$: "Con", ["head"]: h_0, ["tail"]: acc_0}]);
  }
}

function $dg_origin_found$(origins_0, name_0, rest_0, found_0) {
  return run_jump($kc$, [run_loop($dg_has_span$(found_0)), run_clo((x_0) => {
  return found_0;
}), run_clo((x_1) => {
  return run_jump($dg_origin_trail$, [origins_0, name_0, rest_0]);
})]);
}

function $dg_origin_scan$(origins_0, name_0, t_0, found_0) {
  if (origins_0.$ === "Nil") {
    return found_0;
  } else {
    const _t_0 = origins_0["head"];
    const definition_0 = _t_0["definition"];
    const term_0 = _t_0["term"];
    const source_0 = _t_0["source"];
    const begin_0 = _t_0["begin"];
    const end_0 = _t_0["end"];
    const path_0 = _t_0["path"];
    const rest_0 = origins_0["tail"];
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(name_0, definition_0)), run_loop($norm_exact$(t_0, term_0)))), run_clo((x_0) => {
    const x_1 = run_loop($Bool$not$(run_loop($dg_has_span$(found_0))));
    const x_2 = run_loop($dg_span_same$(found_0, {$: "DSpan", ["source"]: source_0, ["begin"]: begin_0, ["end"]: end_0}));
    return run_jump($kc$, [(x_1 || x_2), run_clo((x_3) => {
    return run_jump($dg_origin_scan$, [rest_0, name_0, t_0, {$: "DSpan", ["source"]: source_0, ["begin"]: begin_0, ["end"]: end_0}]);
}), run_clo((x_4) => {
    return {$: "DNoSpan"};
})]);
}), run_clo((x_5) => {
    return run_jump($dg_origin_scan$, [rest_0, name_0, t_0, found_0]);
})]);
  }
}

function $fp_loaded_result$(result_0, done_0, sources_0, all_0, definition_0) {
  const book_0 = result_0["book"];
  const error_0 = result_0["error"];
  const imports_0 = result_0["imports"];
  return {$: "FProvenance", ["result"]: {$: "FResult", ["book"]: book_0, ["error"]: error_0, ["imports"]: imports_0}, ["origins"]: run_loop($f_choose$(run_loop($String$is_empty$(error_0)), run_clo((x_0) => {
  return run_jump($fp_loaded_modules$, [run_loop($List$reverse$(done_0)), book_0, sources_0, all_0, definition_0]);
}), run_clo((x_1) => {
  return {$: "Nil"};
})))};
}

function $f_graph_trace$(graph_0, sources_0) {
  const book_0 = graph_0["book"];
  const error_0 = graph_0["error"];
  const done_0 = graph_0["done"];
  return {$: "FLoadTrace", ["result"]: run_loop($f_graph_result_at$({$: "FGraph", ["book"]: book_0, ["error"]: error_0, ["done"]: done_0}, sources_0)), ["done"]: done_0, ["sources"]: sources_0};
}

function $String$starts_with$if$(t_0, pt_0, same_0) {
  if (!same_0) {
    return false;
  } else {
    return run_jump($String$starts_with$, [t_0, pt_0]);
  }
}

function $Char$is_eq$(a_0, b_0) {
  const x_0 = a_0.codePointAt(0);
  const y_0 = b_0.codePointAt(0);
  return (x_0 === y_0);
}

function $nc_ctor_decode_step$(h_0, rest_0, acc_0, digits_0, out_0, original_0) {
  return run_jump($kc$, [run_loop($Char$is_eq$(h_0, "_")), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$((digits_0 > 0), (acc_0 <= 1114111))), run_loop($Bool$not$(run_loop($Bool$and$((acc_0 >= 55296), (acc_0 <= 57343))))))), run_clo((x_1) => {
  const x_2 = run_loop($Char$show$(run_loop($Char$from_u32$(acc_0))));
  return run_jump($nc_ctor_decode$, [rest_0, 0, 0, (out_0 + x_2), original_0]);
}), run_clo((x_3) => {
  return original_0;
})]);
}), run_clo((x_4) => {
  const x_5 = run_loop($Char$to_u32$(h_0));
  const x_6 = run_loop($Char$to_u32$(h_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$((x_5 >= 48), (x_6 <= 57))), (digits_0 < 7))), run_clo((x_7) => {
  const x_8 = run_loop($Char$to_u32$(h_0));
  const x_9 = (Math.imul(acc_0, 10) >>> 0);
  const x_10 = ((x_8 - 48) >>> 0);
  return run_jump($nc_ctor_decode$, [rest_0, ((x_9 + x_10) >>> 0), ((digits_0 + 1) >>> 0), out_0, original_0]);
}), run_clo((x_11) => {
  return original_0;
})]);
})]);
}

function $terms_at$(ts_0, n_0) {
  if (ts_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
    return h_0;
}), run_clo((x_1) => {
    return run_jump($terms_at$, [t_0, ((n_0 - 1) >>> 0)]);
})]);
  }
}

function $cn$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return name_0;
}

function $dg_pair$(expected_0, observed_0) {
  return run_jump($kt$, ["DDetail", "", 0, 1, {$: "Con", ["head"]: expected_0, ["tail"]: {$: "Con", ["head"]: observed_0, ["tail"]: {$: "Nil"}}}]);
}

function $dg_text$(s_0) {
  return run_jump($kt$, ["DText", s_0, 0, 0, {$: "Nil"}]);
}

function $dg_family$(book_0, name_0) {
  if (book_0.$ === "Nil") {
    return "";
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_loop($Bool$not$(run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(run_loop($dc$(d_0)), name_0)))), "Absent")))))), run_clo((x_0) => {
    return run_jump($dn$, [d_0]);
}), run_clo((x_1) => {
    return run_jump($dg_family$, [rest_0, name_0]);
})]);
  }
}

function $dg_typeless$(book_0, ctx_0, t_0) {
  const x_4 = run_loop($kc$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr")), run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(book_0, run_loop($nm$(t_0)))))), "ADT")))), run_clo((x_0) => {
  const x_1 = run_loop($nm$(t_0));
  const x_2 = (x_1 + " is a datatype: write its arguments as <>)");
  return (" (" + x_2);
}), run_clo((x_3) => {
  return "";
})));
  const x_5 = run_loop($dg_expr$(book_0, {$: "DTerm", ["term"]: t_0}, run_loop($dg_scope$(run_loop($List$reverse$(ctx_0)), {$: "Nil"}))));
  const x_6 = ("'" + x_4);
  const x_7 = (x_5 + x_6);
  return run_jump($dg_text$, [("non-inferrable term '" + x_7)]);
}

function $ref$(name_0) {
  return run_jump($kt$, ["Ref", name_0, 0, 0, {$: "Nil"}]);
}

function $check_lam_q$(e_0, ctx_0, t_0, dem_0, ty_0, q_0) {
  return run_jump($check_lam_done$, [t_0, ty_0, q_0, run_loop($both$(run_loop($check$(e_0, ctx_0, run_loop($kid$(ty_0, 0)), 0, run_loop($typ$(run_loop($kindq$(e_0, q_0)))))), run_loop($check$(run_loop($lhs_step$(e_0, run_loop($var$(run_loop($nm$(t_0)), run_loop($ix$(t_0)))))), run_loop($ctx_bind$(ctx_0, run_loop($ix$(t_0)), q_0, run_loop($nm$(t_0)), run_loop($kid$(ty_0, 0)))), run_loop($kid$(t_0, 0)), dem_0, run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), run_loop($var$(run_loop($nm$(t_0)), run_loop($ix$(t_0)))))))), t_0, ty_0, false))]);
}

function $check_ctr_found$(e_0, ctx_0, t_0, dem_0, ty_0, ctr_0) {
  const x_0 = run_loop($da$(ctr_0));
  const x_1 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$not$(run_loop($String$eq$(run_loop($dk$(ctr_0)), "Absent")))), run_loop($Bool$not$(run_loop($has_name$(run_loop($rm$(ty_0)), run_loop($nm$(t_0)))))))), (x_0 === x_1))), run_clo((x_2) => {
  return run_jump($checked$, [run_loop($tele_check$(e_0, ctx_0, run_loop($tele_fill$(run_loop($cb$(e_0)), run_loop($dt$(ctr_0)), run_loop($ks$(ty_0)))), run_loop($ks$(t_0)), dem_0)), t_0, ty_0]);
}), run_clo((x_3) => {
  return run_jump($dg_ctor_error$, [e_0, t_0, ty_0, ctr_0]);
})]);
}

function $dg_bad_message$(message_0, expected_0) {
  return {$: "KChecked", ["term"]: run_loop($kt$("DDetail", "", 0, 0, {$: "Con", ["head"]: expected_0, ["tail"]: {$: "Con", ["head"]: run_loop($atom$("Absent")), ["tail"]: {$: "Nil"}}})), ["typ"]: run_loop($atom$("Error")), ["uses"]: {$: "Nil"}, ["error"]: message_0};
}

function $check_mat_type$(e_0, ctx_0, t_0, dem_0, ty_0, a_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "ADT")), run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(a_0)))))), "ADT")))), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Efq")), run_clo((x_1) => {
  const x_2 = run_loop($dead_type$(run_loop($cb$(e_0)), a_0));
  const x_3 = run_loop($ctx_dead$(run_loop($cb$(e_0)), ctx_0));
  return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($ok$, [t_0, ty_0, {$: "Nil"}]);
}), run_clo((x_5) => {
  const x_6 = run_loop($dg_constructor_names$(run_loop($remaining$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(a_0)))))), run_loop($rm$(a_0))))));
  return run_jump($dg_bad_detail$, ["nonexhaustive match", run_loop($dg_text$(("cases for " + x_6))), t_0]);
})]);
}), run_clo((x_7) => {
  return run_jump($check_mat_ctr$, [e_0, ctx_0, t_0, dem_0, ty_0, a_0, run_loop($lookup$(run_loop($remaining$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(a_0)))))), run_loop($rm$(a_0)))), run_loop($nm$(t_0))))]);
})]);
}), run_clo((x_8) => {
  return run_jump($dg_bad_detail$, ["match scrutinee requires a datatype", run_loop($dg_text$("a datatype")), run_loop($kid$(ty_0, 0))]);
})]);
}

function $dg_bad_detail$(message_0, expected_0, observed_0) {
  return {$: "KChecked", ["term"]: run_loop($kt$("DDetail", "", 0, 1, {$: "Con", ["head"]: expected_0, ["tail"]: {$: "Con", ["head"]: observed_0, ["tail"]: {$: "Nil"}}})), ["typ"]: run_loop($atom$("Error")), ["uses"]: {$: "Nil"}, ["error"]: message_0};
}

function $check_let_value$(e_0, outer_0, ctx_0, h_0, rest_0, dem_0, ty_0, bindings_0, us_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($check_let_kind$, [e_0, outer_0, ctx_0, h_0, rest_0, dem_0, ty_0, bindings_0, us_0, r_0, run_loop($check$(e_0, outer_0, run_loop($cy$(r_0)), 0, run_loop($typ$(run_loop($kindq$(e_0, run_loop($qt$(h_0))))))))]);
}), run_clo((x_1) => {
  return r_0;
})]);
}

function $qdem$(q_0, d_0) {
  return run_jump($kc$, [(q_0 === 0), run_clo((x_0) => {
  return 0;
}), run_clo((x_1) => {
  return d_0;
})]);
}

function $check_let_done$(r_0, bs_0, us_0) {
  if (bs_0.$ === "Nil") {
    return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
    return run_jump($ok$, [run_loop($ct$(r_0)), run_loop($cy$(r_0)), run_loop($uses_merge$(us_0, run_loop($cs$(r_0)), false))]);
}), run_clo((x_1) => {
    return r_0;
})]);
  } else {
    const h_0 = bs_0["head"];
    const t_0 = bs_0["tail"];
    const x_2 = run_loop($uses_get$(run_loop($cs$(r_0)), run_loop($ix$(h_0))));
    const x_3 = run_loop($qt$(h_0));
    return run_jump($kc$, [(x_2 > x_3), run_clo((x_4) => {
    return run_jump($dg_quant_error$, ["let binder consumed more than allowed", run_loop($nm$(h_0)), run_loop($qt$(h_0)), run_loop($uses_get$(run_loop($cs$(r_0)), run_loop($ix$(h_0))))]);
}), run_clo((x_5) => {
    return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_6) => {
    return run_jump($check_let_done$, [run_loop($ok$(run_loop($ct$(r_0)), run_loop($cy$(r_0)), run_loop($uses_del$(run_loop($cs$(r_0)), run_loop($ix$(h_0)))))), t_0, us_0]);
}), run_clo((x_7) => {
    return r_0;
})]);
})]);
  }
}

function $let_cells$(body_0, bs_0) {
  if (bs_0.$ === "Nil") {
    return body_0;
  } else {
    const h_0 = bs_0["head"];
    const t_0 = bs_0["tail"];
    return run_jump($let_cells$, [run_loop($subst$(body_0, run_loop($ix$(h_0)), run_loop($kt$("Var", run_loop($nm$(h_0)), run_loop($ix$(h_0)), 0, {$: "Con", ["head"]: run_loop($kid$(h_0, 0)), ["tail"]: {$: "Nil"}})))), t_0]);
  }
}

function $check_rwt_type$(e_0, ctx_0, t_0, dem_0, ty_0, r_0, eq_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(eq_0)), "Eql")), run_clo((x_0) => {
  const x_1 = run_loop($norm_max_term$(t_0));
  const x_2 = run_loop($norm_book_bound$(run_loop($cb$(e_0))));
  const x_3 = ((x_1 + 1) >>> 0);
  return run_jump($check_rwt_goal$, [e_0, ctx_0, t_0, dem_0, ty_0, r_0, eq_0, ((x_2 + x_3) >>> 0)]);
}), run_clo((x_4) => {
  return run_jump($dg_bad_detail$, ["rewrite requires equality evidence", run_loop($dg_text$("an equation {a == b : T}")), run_loop($cy$(r_0))]);
})]);
}

function $subst$(t_0, id_0, v_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), run_clo((x_0) => {
  const x_1 = run_loop($ix$(t_0));
  return run_jump($kc$, [(x_1 === id_0), run_clo((x_2) => {
  return v_0;
}), run_clo((x_3) => {
  return t_0;
})]);
}), run_clo((x_4) => {
  return run_jump($subst_node$, [t_0, id_0, v_0]);
})]);
}

function $app$(f_0, x_0) {
  return run_jump($kt$, ["App", "", 0, 0, {$: "Con", ["head"]: f_0, ["tail"]: {$: "Con", ["head"]: x_0, ["tail"]: {$: "Nil"}}}]);
}

function $ctx_get$(ctx_0, id_0) {
  if (ctx_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const h_0 = ctx_0["head"];
    const t_0 = ctx_0["tail"];
    const x_0 = run_loop($ix$(h_0));
    return run_jump($kc$, [(x_0 === id_0), run_clo((x_1) => {
    return h_0;
}), run_clo((x_2) => {
    return run_jump($ctx_get$, [t_0, id_0]);
})]);
  }
}

function $dt$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return typ_0;
}

function $cu$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return unsafe_0;
}

function $descend_spine$(qs_0, args_0, cols_0) {
  if (cols_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = cols_0["head"];
    const t_0 = cols_0["tail"];
    return run_jump($descend_step$, [run_loop($descend$(run_loop($qt$(run_loop($terms_at$(qs_0, 0)))), run_loop($terms_at$(args_0, 0)), h_0)), run_loop($terms_tail$(qs_0)), run_loop($terms_tail$(args_0)), t_0]);
  }
}

function $cq$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return quantities_0;
}

function $unargs$(t_0, acc_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($unargs$, [run_loop($kid$(t_0, 0)), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: acc_0}]);
}), run_clo((x_1) => {
  return acc_0;
})]);
}

function $cl$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return lhs_0;
}

function $dv$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return value_0;
}

function $infer_template$(e_0, t_0, dem_0, sp_0, d_0) {
  const x_0 = run_loop($dx$(d_0));
  const x_1 = run_loop($dx$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($cn$(e_0))))));
  const x_2 = (x_0 === 0);
  const x_3 = (x_1 > 0);
  return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($ok$, [t_0, run_loop($dt$(d_0)), {$: "Nil"}]);
}), run_clo((x_5) => {
  return run_jump($checked$, [run_loop($template_args$(e_0, run_loop($dt$(d_0)), sp_0, run_loop($dx$(d_0)))), t_0, run_loop($dt$(d_0))]);
})]);
}

function $qua$(q_0) {
  return run_jump($kt$, ["Qua", "", 0, q_0, {$: "Nil"}]);
}

function $uses_merge$(a_0, b_0, join_0) {
  if (a_0.$ === "Nil") {
    return b_0;
  } else {
    const h_0 = a_0["head"];
    const t_0 = a_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Use", "", run_loop($ix$(h_0)), run_loop($kc$(join_0, run_clo((x_0) => {
    return run_jump($qjoin$, [run_loop($qt$(h_0)), run_loop($uses_get$(b_0, run_loop($ix$(h_0))))]);
}), run_clo((x_1) => {
    return run_jump($qadd$, [run_loop($qt$(h_0)), run_loop($uses_get$(b_0, run_loop($ix$(h_0))))]);
}))), {$: "Nil"})), ["tail"]: run_loop($uses_merge$(t_0, run_loop($uses_del$(b_0, run_loop($ix$(h_0)))), join_0))};
  }
}

function $infer_app_type$(e_0, ctx_0, t_0, dem_0, r_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
  return run_jump($both$, [r_0, run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), run_loop($qdem$(run_loop($qt$(ty_0)), dem_0)), run_loop($kid$(ty_0, 0)))), t_0, run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), run_loop($kid$(t_0, 1)))), false]);
}), run_clo((x_1) => {
  return run_jump($dg_bad_detail$, ["application requires a function type", run_loop($dg_text$("a function type")), run_loop($cy$(r_0))]);
})]);
}

function $infer_adt_done$(t_0, r_0) {
  return run_jump($checked$, [r_0, t_0, run_loop($cy$(r_0))]);
}

function $tele_check$(e_0, ctx_0, tel_0, args_0, dem_0) {
  if (args_0.$ === "Nil") {
    return run_jump($ok$, [run_loop($atom$("Args")), tel_0, {$: "Nil"}]);
  } else {
    const h_0 = args_0["head"];
    const t_0 = args_0["tail"];
    return run_jump($tele_check_cached_head$, [e_0, ctx_0, run_loop($wnf$(run_loop($cb$(e_0)), tel_0)), h_0, t_0, dem_0]);
  }
}

function $dg_adt_error$(t_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_0) => {
  const x_1 = run_loop($da$(d_0));
  const x_4 = run_loop($U32$show$(run_loop($da$(d_0))));
  const x_5 = run_loop($kc$((x_1 === 1), run_clo((x_2) => {
  return " parameter";
}), run_clo((x_3) => {
  return " parameters";
})));
  const x_6 = (x_4 + x_5);
  const x_7 = run_loop($nm$(t_0));
  const x_8 = (" with " + x_6);
  return run_jump($dg_bad_detail$, ["unknown family or wrong parameter count", run_loop($dg_text$((x_7 + x_8))), t_0]);
}), run_clo((x_9) => {
  const x_10 = run_loop($nm$(t_0));
  const x_11 = (x_10 + ")");
  return run_jump($dg_bad_message$, ["unknown family or wrong parameter count", run_loop($dg_text$(("a declared datatype (unknown: " + x_11)))]);
})]);
}

function $dx$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return templates_0;
}

function $annotate$(e_0, ctx_0, t_0, ty_0) {
  return run_jump($ka_wrap$, [run_loop($ka_node$(e_0, ctx_0, run_loop($core_beta$(t_0)), run_loop($wnf$(run_loop($cb$(e_0)), ty_0)))), ty_0]);
}

function $du$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return unsafe_0;
}

function $kp_index$(env_0, id_0) {
  if (env_0.$ === "Nil") {
    return id_0;
  } else {
    const _t_0 = env_0["head"];
    const n_0 = _t_0["name"];
    const i_0 = _t_0["id"];
    const depth_0 = _t_0["depth"];
    const tail_0 = env_0["tail"];
    return run_jump($kc$, [(i_0 === id_0), run_clo((x_0) => {
    return depth_0;
}), run_clo((x_1) => {
    return run_jump($kp_index$, [tail_0, id_0]);
})]);
  }
}

function $U32$show$if$(a_0, z_0) {
  if (z_0) {
    return "0";
  } else {
    return run_jump($U32$show$go$, [10n, a_0, ""]);
  }
}

function $kp_depth$(env_0) {
  if (env_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = env_0["head"];
    const t_0 = env_0["tail"];
    const x_0 = run_loop($kp_depth$(t_0));
    return ((1 + x_0) >>> 0);
  }
}

function $kp_application$(s_0, p_0, env_0) {
  const xs_0 = s_0["items"];
  const h_0 = s_0["tail"];
  const x_0 = run_loop($terms_len$(xs_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($kp_is$(h_0, "Ref", "Exists")), (x_0 === 2))), run_loop($kp_eq$(run_loop($tg$(run_loop($terms_at$(xs_0, 1)))), "Lam")))), run_clo((x_1) => {
  return run_jump($kp_exists$, [run_loop($terms_at$(xs_0, 0)), run_loop($terms_at$(xs_0, 1)), p_0, env_0]);
}), run_clo((x_2) => {
  const x_3 = run_loop($kp_join$(run_loop($kp_each$(xs_0, 1, env_0)), ", "));
  const x_4 = (x_3 + ")");
  const x_5 = run_loop($kp_go$(h_0, 3, env_0));
  const x_6 = ("(" + x_4);
  return (x_5 + x_6);
})]);
}

function $kp_spine$(t_0, acc_0) {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($kp_spine$, [run_loop($kid$(t_0, 0)), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: acc_0}]);
}), run_clo((x_1) => {
  return {$: "KPChain", ["items"]: acc_0, ["tail"]: t_0};
})]);
}

function $kp_adt$(t_0, p_0, env_0) {
  const x_0 = run_loop($terms_len$(run_loop($ks$(t_0))));
  const x_5 = run_loop($kc$(run_loop($Bool$and$((x_0 === 0), run_loop($Bool$not$(run_loop($kp_has_removed$(run_loop($rm$(t_0)))))))), run_clo((x_1) => {
  return "";
}), run_clo((x_2) => {
  const x_3 = run_loop($kp_join$(run_loop($kp_each$(run_loop($ks$(t_0)), 1, env_0)), ", "));
  const x_4 = (x_3 + ">");
  return ("<" + x_4);
})));
  const x_6 = run_loop($kp_removed$(run_loop($rm$(t_0))));
  const x_7 = run_loop($nm$(t_0));
  const x_8 = (x_5 + x_6);
  return run_jump($kp_par$, [(x_7 + x_8), run_loop($Bool$and$(run_loop($kp_has_removed$(run_loop($rm$(t_0)))), (p_0 > 2)))]);
}

function $kp_ctor$(t_0, p_0, env_0) {
  return run_jump($kp_ctor_number$, [run_loop($kp_number$(t_0)), t_0, p_0, env_0]);
}

function $kp_matches$(t_0, env_0) {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_0) => {
  const x_4 = run_loop($kp_go$(run_loop($kid$(t_0, 0)), 2, env_0));
  const x_5 = run_loop($kc$(run_loop($kp_eq$(run_loop($tg$(run_loop($kid$(t_0, 1)))), "Efq")), run_clo((x_1) => {
  return "";
}), run_clo((x_2) => {
  const x_3 = run_loop($kp_matches$(run_loop($kid$(t_0, 1)), env_0));
  return ("; " + x_3);
})));
  const x_6 = (x_4 + x_5);
  const x_7 = run_loop($nm$(t_0));
  const x_8 = (": " + x_6);
  return (x_7 + x_8);
}), run_clo((x_9) => {
  return run_jump($kp_go$, [t_0, 2, env_0]);
})]);
}

function $kp_go_last$(t_0, p_0, env_0) {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Sub")), run_clo((x_0) => {
  return run_jump($kp_go$, [run_loop($kid$(t_0, 1)), p_0, env_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_2) => {
  return run_jump($kp_rewrite$, [t_0, p_0, env_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_4) => {
  return run_jump($kp_let$, [t_0, p_0, env_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($kp_eq$(run_loop($tg$(t_0)), "Literal")), run_clo((x_6) => {
  return run_jump($nm$, [t_0]);
}), run_clo((x_7) => {
  const x_8 = run_loop($nm$(t_0));
  const x_9 = (x_8 + ">");
  const x_10 = run_loop($tg$(t_0));
  const x_11 = (":" + x_9);
  const x_12 = (x_10 + x_11);
  return ("<" + x_12);
})]);
})]);
})]);
})]);
}

function $sp_needed$(book_0, t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_0) => {
  const x_1 = run_loop($dx$(run_loop($lookup$(book_0, run_loop($nm$(t_0))))));
  return (x_1 > 0);
}), run_clo((x_2) => {
  return run_jump($sp_neededs$, [book_0, run_loop($ks$(t_0))]);
})]);
}

function $sp_templates$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return templates_0;
}

function $sp_definition_done$(rest_0, d_0, r_0) {
  return run_jump($sp_definitions$, [rest_0, run_loop($sp_put$(run_loop($sp_state$(r_0)), {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($dt$(d_0)), ["value"]: run_loop($sp_value$(r_0)), ["ctors"]: run_loop($dc$(d_0)), ["native"]: run_loop($db$(d_0)), ["unsafe"]: run_loop($du$(d_0))}))]);
}

function $sp_term$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0) {
  return run_jump($kc$, [run_loop($Bool$not$(run_loop($String$eq$(run_loop($sp_error$(st_0)), "")))), run_clo((x_0) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: t_0};
}), run_clo((x_1) => {
  const x_2 = run_loop($String$eq$(run_loop($tg$(t_0)), "App"));
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ref"));
  return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($sp_spine$, [st_0, t_0, {$: "Nil"}, ctx_0, owner_0, depth_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_6) => {
  return run_jump($sp_annotation$, [t_0, run_loop($sp_term$(st_0, run_loop($kid$(t_0, 0)), ctx_0, run_loop($kid$(t_0, 1)), owner_0, depth_0))]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_8) => {
  return run_jump($sp_lambda$, [st_0, t_0, ctx_0, run_loop($wnf$(run_loop($sp_book$(st_0)), goal_0)), owner_0, depth_0]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_10) => {
  return run_jump($sp_match$, [st_0, t_0, ctx_0, run_loop($wnf$(run_loop($sp_book$(st_0)), goal_0)), owner_0, depth_0]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr")), run_clo((x_12) => {
  return run_jump($sp_constructor$, [st_0, t_0, ctx_0, run_loop($wnf$(run_loop($sp_book$(st_0)), goal_0)), owner_0, depth_0]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_14) => {
  return run_jump($sp_let_result$, [t_0, run_loop($sp_let$(st_0, run_loop($ks$(t_0)), ctx_0, ctx_0, goal_0, owner_0, depth_0))]);
}), run_clo((x_15) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_16) => {
  return run_jump($sp_rewrite$, [st_0, t_0, ctx_0, owner_0, depth_0]);
}), run_clo((x_17) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: t_0};
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $book_final_large$(book_0, remaining_0) {
  if (book_0.$ === "Nil") {
    return (remaining_0 === 0);
  } else {
    const h_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [(remaining_0 === 0), run_clo((x_0) => {
    return true;
}), run_clo((x_1) => {
    return run_jump($book_final_large$, [rest_0, ((remaining_0 - 1) >>> 0)]);
})]);
  }
}

function $book_final_names_valid$(book_0) {
  if (book_0.$ === "Nil") {
    return true;
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($book_final_name_valid$(run_loop($dn$(d_0)))), run_clo((x_0) => {
    return run_jump($book_final_names_valid$, [rest_0]);
}), run_clo((x_1) => {
    return false;
})]);
  }
}

function $book_final_scan$(book_0, seen_0, kept_0, done_0) {
  if (book_0.$ === "Nil") {
    return run_jump($book_final_reverse$, [kept_0, run_loop($book_final_filter$(done_0, seen_0))]);
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($book_final_step$, [d_0, rest_0, seen_0, kept_0, done_0, run_loop($index_hash$(run_loop($dn$(d_0)), 2166136261))]);
  }
}

function $book_final_reverse$(book_0, done_0) {
  if (book_0.$ === "Nil") {
    return done_0;
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($book_final_reverse$, [rest_0, {$: "Con", ["head"]: d_0, ["tail"]: done_0}]);
  }
}

function $book_final_legacy$(book_0, done_0) {
  if (book_0.$ === "Nil") {
    return done_0;
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($book_final_legacy$, [rest_0, {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_remove$(done_0, run_loop($dn$(d_0))))}]);
  }
}

function $norm_defs_join$(a_0, b_0) {
  if (a_0.$ === "Nil") {
    return b_0;
  } else {
    const h_0 = a_0["head"];
    const rest_0 = a_0["tail"];
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($norm_defs_join$(rest_0, b_0))};
  }
}

function $g_snf_go$(book_0, st_0, t_0, stack_0, fresh_0) {
  return run_jump($g_snf_head$, [book_0, stack_0, fresh_0, run_loop($g_wnf$(book_0, st_0, t_0))]);
}

function $norm_apply$(t_0, args_0) {
  if (args_0.$ === "Nil") {
    return t_0;
  } else {
    const h_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($norm_apply$, [run_loop($app$(t_0, h_0)), rest_0]);
  }
}

function $norm_let$(ts_0) {
  if (ts_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($norm_let_tail$, [h_0, rest_0]);
  }
}

function $norm_ref$(book_0, t_0, args_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_0) => {
  const x_1 = run_loop($da$(d_0));
  return run_jump($kc$, [(x_1 === 0), run_clo((x_2) => {
  return run_jump($norm_apply$, [run_loop($kt$("ADT", run_loop($nm$(t_0)), 0, 0, {$: "Nil"})), args_0]);
}), run_clo((x_3) => {
  return run_jump($norm_apply$, [t_0, args_0]);
})]);
}), run_clo((x_4) => {
  const x_5 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent"));
  const x_6 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Foreign"));
  const x_7 = run_loop($da$(d_0));
  const x_8 = run_loop($terms_len$(args_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$((x_5 || x_6))), (x_7 <= x_8))), run_clo((x_9) => {
  return run_jump($norm_eval$, [book_0, run_loop($dv$(d_0)), args_0, run_loop($da$(d_0)), run_loop($norm_apply$(t_0, args_0))]);
}), run_clo((x_10) => {
  return run_jump($norm_apply$, [t_0, args_0]);
})]);
})]);
}

function $norm_min$(book_0, a_0, b_0) {
  return run_jump($norm_min_left$, [book_0, run_loop($wnf$(book_0, a_0)), b_0]);
}

function $norm_args$(book_0, t_0, args_0, left_0, fallback_0) {
  if (args_0.$ === "Nil") {
    return t_0;
  } else {
    const x_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_1) => {
    return run_jump($norm_eval$, [book_0, run_loop($subst$(run_loop($kid$(t_0, 0)), run_loop($ix$(t_0)), x_0)), rest_0, run_loop($norm_dec$(left_0)), fallback_0]);
}), run_clo((x_2) => {
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_3) => {
    return run_jump($norm_match$, [book_0, t_0, t_0, x_0, run_loop($wnf$(book_0, x_0)), rest_0, left_0, fallback_0]);
}), run_clo((x_4) => {
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Efq")), run_loop($Bool$not$((left_0 === 0))))), run_clo((x_5) => {
    return fallback_0;
}), run_clo((x_6) => {
    return run_jump($norm_apply$, [t_0, {$: "Con", ["head"]: x_0, ["tail"]: rest_0}]);
})]);
})]);
})]);
  }
}

function $norm_exact_lists$(as_0, bs_0) {
  if (as_0.$ === "Nil") {
    if (bs_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const a_0 = as_0["head"];
    const ar_0 = as_0["tail"];
    if (bs_0.$ === "Con") {
      const b_0 = bs_0["head"];
      const br_0 = bs_0["tail"];
      return run_jump($kc$, [run_loop($norm_exact_head$(a_0, b_0)), run_clo((x_0) => {
      return run_jump($norm_exact_lists$, [run_loop($norm_join$(run_loop($ks$(a_0)), ar_0)), run_loop($norm_join$(run_loop($ks$(b_0)), br_0))]);
}), run_clo((x_1) => {
      return false;
})]);
    } else {
      return false;
    }
  }
}

function $norm_cmp_quick$(a_0, b_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(a_0)), "App"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(a_0)), "Ref"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(a_0)), "Var"));
  return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($norm_exact$, [a_0, b_0]);
}), run_clo((x_5) => {
  return false;
})]);
}

function $norm_cmp_heads$(book_0, a_0, b_0, le_0, fresh_0, rest_0, alts_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(a_0)), "Lam"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(b_0)), "Lam"));
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($app$(a_0, run_loop($var$("_", fresh_0)))), ["b"]: run_loop($app$(b_0, run_loop($var$("_", fresh_0)))), ["le"]: le_0, ["fresh"]: ((fresh_0 + 1) >>> 0)}, ["tail"]: rest_0}, alts_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), run_loop($tg$(b_0)))), run_clo((x_4) => {
  return run_jump($norm_cmp_same$, [book_0, a_0, b_0, le_0, fresh_0, rest_0, alts_0]);
}), run_clo((x_5) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
})]);
}

function $exact_term$(a_0, b_0) {
  const x_0 = run_loop($ix$(a_0));
  const x_1 = run_loop($ix$(b_0));
  const x_2 = run_loop($qt$(a_0));
  const x_3 = run_loop($qt$(b_0));
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), run_loop($tg$(b_0)))), run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(b_0)))))), (x_0 === x_1))), (x_2 === x_3))), run_loop($exact_terms$(run_loop($ks$(a_0)), run_loop($ks$(b_0)))))), run_loop($exact_names$(run_loop($rm$(a_0)), run_loop($rm$(b_0))))]);
}

function $exact_defs$(a_0, b_0) {
  if (a_0.$ === "Nil") {
    return run_jump($defs_empty$, [b_0]);
  } else {
    const h_0 = a_0["head"];
    const rest_0 = a_0["tail"];
    return run_jump($exact_defs_head$, [h_0, rest_0, b_0]);
  }
}

function $dg_prefix_step$(todo_0, head_0, tail_0, done_0, original_0, origins_0) {
  if (todo_0.$ === "Nil") {
    return run_jump($check_book_diagnostic$, [original_0, origins_0]);
  } else {
    const event_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($dg_prefix_seed$, [rest_0, tail_0, run_loop($book_put$(done_0, head_0)), original_0, origins_0]);
  }
}

function $kr_dependencies$(d_0, stops_0, todo_0) {
  return run_jump($List$append$, [run_loop($kr_refs$(run_loop($dt$(d_0)), run_loop($kr_ctor_refs$(run_loop($dc$(d_0)), run_loop($kc$(run_loop($has_name$(stops_0, run_loop($dn$(d_0)))), run_clo((x_0) => {
  return {$: "Nil"};
}), run_clo((x_1) => {
  return run_jump($kr_refs$, [run_loop($dv$(d_0)), {$: "Nil"}]);
}))))))), todo_0]);
}

function $kr_resolve_head$(book_0, name_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "Absent")), run_clo((x_0) => {
  return run_jump($kr_parent$, [book_0, name_0]);
}), run_clo((x_1) => {
  return d_0;
})]);
}

function $Cmp$is_eq$(c_0) {
  if (c_0.$ === "LT") {
    return false;
  } else if (c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$cmp$fin$(t1_0, t2_0, hc_0) {
  const _t_0 = hc_0["fst"];
  const h1b_0 = _t_0["fst"];
  const h2b_0 = _t_0["snd"];
  const _t_1 = hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1_0), ["snd"]: (h2b_0 + t2_0)}, ["snd"]: {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return run_jump($String$cmp$rec$, [h1b_0, h2b_0, run_loop($String$cmp$(t1_0, t2_0))]);
  } else {
    return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1_0), ["snd"]: (h2b_0 + t2_0)}, ["snd"]: {$: "GT"}};
  }
}

function $Char$cmp$(a_0, b_0) {
  const x_0 = a_0.codePointAt(0);
  const y_0 = b_0.codePointAt(0);
  return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: char_new(x_0), ["snd"]: char_new(y_0)}, ["snd"]: cmp_new(x_0, y_0)};
}

function $index_bucket$(ds_0, name_0) {
  if (ds_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const h_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($dn$(h_0)), name_0)), run_clo((x_0) => {
    return h_0;
}), run_clo((x_1) => {
    return run_jump($index_bucket$, [rest_0, name_0]);
})]);
  }
}

function $index_child$(tree_0, right_0) {
  return run_jump($index_child_list$, [run_loop($dc$(tree_0)), right_0]);
}

function $index_join$(tree_0, d_0, hash_0, mask_0) {
  const x_0 = ((hash_0 & mask_0) >>> 0);
  return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
  return run_jump($index_node$, [run_loop($da$(tree_0)), mask_0, run_loop($index_leaf$(d_0, hash_0, {$: "Nil"})), tree_0]);
}), run_clo((x_2) => {
  return run_jump($index_node$, [run_loop($da$(tree_0)), mask_0, tree_0, run_loop($index_leaf$(d_0, hash_0, {$: "Nil"}))]);
})]);
}

function $index_node$(hash_0, mask_0, left_0, right_0) {
  return {$: "KDef", ["name"]: "", ["kind"]: "IndexNode", ["arity"]: hash_0, ["templates"]: mask_0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Con", ["head"]: left_0, ["tail"]: {$: "Con", ["head"]: right_0, ["tail"]: {$: "Nil"}}}, ["native"]: true, ["unsafe"]: false};
}

function $fpe_seek$(source_0, rest_0, line_0, column_0, error_0) {
  const x_0 = run_loop($ix$(error_0));
  const x_1 = run_loop($qt$(error_0));
  return run_jump($f_choose$, [run_loop($Bool$and$((line_0 === x_0), (column_0 === x_1))), run_clo((x_2) => {
  return run_jump($fpe_here$, [source_0, rest_0, error_0]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($String$is_empty$(rest_0)), run_clo((x_4) => {
  return run_jump($nm$, [error_0]);
}), run_clo((x_5) => {
  const x_6 = run_loop($Char$to_u32$(run_loop($f_head$(rest_0))));
  return run_jump($f_choose$, [(x_6 === 10), run_clo((x_7) => {
  return run_jump($fpe_seek$, [source_0, run_loop($f_tail$(rest_0)), ((line_0 + 1) >>> 0), 0, error_0]);
}), run_clo((x_8) => {
  return run_jump($fpe_seek$, [source_0, run_loop($f_tail$(rest_0)), line_0, ((column_0 + 1) >>> 0), error_0]);
})]);
})]);
})]);
}

function $f_tx$(ts_0) {
  if (ts_0.$ === "Nil") {
    return "<eof>";
  } else {
    const _t_0 = ts_0["head"];
    const t_0 = _t_0["text"];
    const l_0 = _t_0["f_line"];
    const c_0 = _t_0["f_col"];
    const k_0 = _t_0["f_kind"];
    const rest_0 = ts_0["tail"];
    return t_0;
  }
}

function $f_top_ready$(ts_0, book_0, imports_0, unsafe_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<eof>")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, run_loop($atom$("Absent")), imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "@")), run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "unsafe")))), run_clo((x_2) => {
  return run_jump($f_tops$, [run_loop($f_tl$(run_loop($f_tl$(ts_0)))), book_0, imports_0, true]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "import")), run_clo((x_4) => {
  return run_jump($f_import_leading$, [ts_0, book_0, imports_0, unsafe_0]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "law")), run_clo((x_6) => {
  return run_jump($f_law$, [run_loop($f_tx$(run_loop($f_tl$(ts_0)))), run_loop($f_skip$(run_loop($f_tl$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))))))), book_0, imports_0, {$: "Nil"}]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "def")), run_clo((x_8) => {
  return run_jump($f_def$, [run_loop($f_tx$(run_loop($f_tl$(ts_0)))), run_loop($f_tele$(run_loop($f_tl$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))))), ")", {$: "Nil"})), book_0, imports_0, unsafe_0]);
}), run_clo((x_9) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "type")), run_clo((x_10) => {
  return run_jump($f_type$, [run_loop($f_tx$(run_loop($f_tl$(ts_0)))), run_loop($f_tl$(run_loop($f_tl$(ts_0)))), book_0, imports_0]);
}), run_clo((x_11) => {
  return run_jump($f_result$, [book_0, run_loop($f_pn$(run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "@")), run_clo((x_12) => {
  return run_jump($f_err$, [ts_0, "expected def, law, type or import"]);
}), run_clo((x_13) => {
  return run_jump($fpe_error$, [ts_0, "expected def, law, type or import", "'def', 'type' or 'law'"]);
}))))), imports_0]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_result$(book_0, err_0, imports_0) {
  return {$: "FRawResult", ["book"]: run_loop($List$reverse$(book_0)), ["error"]: err_0, ["imports"]: run_loop($List$reverse$(imports_0))};
}

function $f_pn$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return n_0;
}

function $f_err$(ts_0, msg_0) {
  const x_0 = run_loop($f_tx$(ts_0));
  const x_1 = ("; got " + x_0);
  const x_2 = (msg_0 + x_1);
  const x_3 = run_loop($U32$show$(run_loop($f_col$(ts_0))));
  const x_4 = (": " + x_2);
  const x_5 = (x_3 + x_4);
  const x_6 = run_loop($U32$show$(run_loop($f_line$(ts_0))));
  const x_7 = (":" + x_5);
  const x_8 = (x_6 + x_7);
  return {$: "FParsed", ["term"]: run_loop($kt$("Error", ("line " + x_8), 0, 0, {$: "Nil"})), ["rest"]: {$: "Nil"}};
}

function $f_tl$(ts_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return rest_0;
  }
}

function $f_ascii_space_code$(code_0) {
  const x_0 = ((code_0 - 9) >>> 0);
  const x_1 = (code_0 === 32);
  const x_2 = (x_0 <= 4);
  return (x_1 || x_2);
}

function $String$reverse$(s_0) {
  return run_jump($String$reverse$go$, [s_0, ""]);
}

function $f_ascii_ident_code$(code_0) {
  const x_0 = ((code_0 | 32) >>> 0);
  const x_1 = ((x_0 - 97) >>> 0);
  const x_2 = ((code_0 - 48) >>> 0);
  const x_3 = (x_1 <= 25);
  const x_4 = (x_2 <= 9);
  const x_5 = (x_3 || x_4);
  const x_6 = (code_0 === 95);
  const x_7 = (x_5 || x_6);
  const x_8 = (code_0 === 46);
  return (x_7 || x_8);
}

function $f_ascii_digit$(c_0) {
  const x_0 = run_loop($Char$to_u32$(c_0));
  const x_1 = ((x_0 - 48) >>> 0);
  return (x_1 <= 9);
}

function $f_pair_op$(s_0) {
  const x_0 = run_loop($f_eq$(s_0, "->"));
  const x_1 = run_loop($f_eq$(s_0, "=>"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(s_0, "<-"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(s_0, "++"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($f_eq$(s_0, "<>"));
  const x_8 = (x_6 || x_7);
  const x_9 = run_loop($f_eq$(s_0, "=="));
  const x_10 = (x_8 || x_9);
  const x_11 = run_loop($f_eq$(s_0, "!="));
  const x_12 = (x_10 || x_11);
  const x_13 = run_loop($f_eq$(s_0, "<="));
  const x_14 = (x_12 || x_13);
  const x_15 = run_loop($f_eq$(s_0, ">="));
  const x_16 = (x_14 || x_15);
  const x_17 = run_loop($f_eq$(s_0, "&&"));
  const x_18 = (x_16 || x_17);
  const x_19 = run_loop($f_eq$(s_0, "||"));
  const x_20 = (x_18 || x_19);
  const x_21 = run_loop($f_eq$(s_0, "<<"));
  const x_22 = (x_20 || x_21);
  const x_23 = run_loop($f_eq$(s_0, ">>"));
  return (x_22 || x_23);
}

function $f_two$(s_0) {
  return (run_loop($f_head$(s_0)) + (run_loop($f_head$(run_loop($f_tail$(s_0)))) + ""));
}

function $String$ends_with$(s_0, p_0) {
  return run_jump($String$starts_with$, [run_loop($String$reverse$(s_0)), run_loop($String$reverse$(p_0))]);
}

function $f_col$(ts_0) {
  if (ts_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = ts_0["head"];
    const t_0 = _t_0["text"];
    const l_0 = _t_0["f_line"];
    const c_0 = _t_0["f_col"];
    const k_0 = _t_0["f_kind"];
    const rest_0 = ts_0["tail"];
    return c_0;
  }
}

function $f_symbol_text$(s_0, c_0, acc_0) {
  const x_0 = run_loop($f_tx$(acc_0));
  const x_1 = BigInt([...x_0].length);
  const x_2 = run_loop($f_col$(acc_0));
  const x_3 = Number(x_1 & 0xFFFFFFFFn);
  const x_4 = ((x_2 + x_3) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), "+")), run_loop($f_ascii_alpha$(run_loop($f_head$(run_loop($f_tail$(s_0)))))))), run_loop($Bool$not$(run_loop($Bool$and$(run_loop($String$ends_with$(run_loop($f_tx$(acc_0)), "n")), (x_4 === c_0))))))), run_clo((x_5) => {
  return "+bind";
}), run_clo((x_6) => {
  const x_7 = run_loop($f_tx$(acc_0));
  const x_8 = BigInt([...x_7].length);
  const x_9 = run_loop($f_col$(acc_0));
  const x_10 = Number(x_8 & 0xFFFFFFFFn);
  const x_11 = ((x_9 + x_10) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_ascii_char_eq$(run_loop($f_head$(s_0)), ">")), (c_0 > x_11))), run_clo((x_12) => {
  return ">op";
}), run_clo((x_13) => {
  return (run_loop($f_head$(s_0)) + "");
})]);
})]);
}

function $fpe_rejected$(result_0, book_0, done_0, sources_0) {
  const out_0 = result_0["book"];
  const error_0 = result_0["error"];
  const imports_0 = result_0["imports"];
  return {$: "FResult", ["book"]: out_0, ["error"]: run_loop($f_choose$(run_loop($String$is_empty$(error_0)), run_clo((x_0) => {
  return error_0;
}), run_clo((x_1) => {
  return run_jump($fpe_selected$, [error_0, run_loop($fpe_find$(book_0, 0)), done_0, sources_0]);
}))), ["imports"]: imports_0};
}

function $f_fresh_result$(r_0) {
  const book_0 = r_0["book"];
  const err_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return run_jump($f_fresh_result_end$, [run_loop($f_fresh_defs$(book_0, 1)), err_0, imports_0]);
}

function $f_graph_fresh_result$(r_0) {
  const book_0 = r_0["book"];
  const err_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return {$: "FResult", ["book"]: book_0, ["error"]: run_loop($f_graph_fresh_names$(book_0, run_loop($missing$()))), ["imports"]: imports_0};
}), run_clo((x_1) => {
  return {$: "FResult", ["book"]: book_0, ["error"]: err_0, ["imports"]: imports_0};
})]);
}

function $f_validate_result$(r_0) {
  const book_0 = r_0["book"];
  const err_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return {$: "FResult", ["book"]: book_0, ["error"]: run_loop($f_choose$(run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_error_defs$, [book_0]);
}), run_clo((x_1) => {
  return err_0;
}))), ["imports"]: imports_0};
}

function $f_graph_cached$(s_0, ns_0, sources_0, g_0, stack_0, entry_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(entry_0)), "Absent")), run_clo((x_0) => {
  return run_jump($f_graph_parsed$, [s_0, ns_0, sources_0, g_0, {$: "Con", ["head"]: run_loop($f_source_path$(s_0)), ["tail"]: stack_0}, run_loop($f_parse_source$(s_0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($nm$(run_loop($kid$(entry_0, 0)))), ns_0)), run_clo((x_2) => {
  return g_0;
}), run_clo((x_3) => {
  const x_4 = run_loop($f_source_path$(s_0));
  return run_jump($f_graph_error$, [g_0, ("one namespace per source file: " + x_4)]);
})]);
})]);
}

function $f_env$(name_0, env_0) {
  if (env_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const x_0 = env_0["head"];
    const xs_0 = env_0["tail"];
    const x_1 = run_loop($Bool$not$(run_loop($f_eq$(name_0, "_"))));
    const x_2 = run_loop($f_eq$(run_loop($tg$(x_0)), "RewriteVar"));
    return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(name_0, run_loop($nm$(x_0)))), (x_1 || x_2))), run_clo((x_3) => {
    return x_0;
}), run_clo((x_4) => {
    return run_jump($f_env$, [name_0, xs_0]);
})]);
  }
}

function $fs_cached$(s_0, ns_0, sources_0, g_0, stack_0, entry_0, seed_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(entry_0)), "Absent")), run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$is_empty$(ns_0)), run_loop($f_eq$(run_loop($f_source_name$(s_0)), "Base")))), run_loop($f_eq$(run_loop($f_source_path$(s_0)), run_loop($fs_path$(seed_0)))))), run_clo((x_1) => {
  return run_jump($fs_inject$, [g_0, seed_0]);
}), run_clo((x_2) => {
  return run_jump($fs_parsed$, [s_0, ns_0, sources_0, g_0, {$: "Con", ["head"]: run_loop($f_source_path$(s_0)), ["tail"]: stack_0}, run_loop($f_parse_source$(s_0)), seed_0]);
})]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($nm$(run_loop($kid$(entry_0, 0)))), ns_0)), run_clo((x_4) => {
  return g_0;
}), run_clo((x_5) => {
  const x_6 = run_loop($f_source_path$(s_0));
  return run_jump($f_graph_error$, [g_0, ("one namespace per source file: " + x_6)]);
})]);
})]);
}

function $f_main_seen$(name_0, seen_0) {
  if (seen_0.$ === "Nil") {
    return false;
  } else {
    const head_0 = seen_0["head"];
    const rest_0 = seen_0["tail"];
    const x_0 = run_loop($String$eq$(name_0, head_0));
    const x_1 = run_loop($f_main_seen$(name_0, rest_0));
    return (x_0 || x_1);
  }
}

function $ffw_done$(term_0, next_0, stack_0) {
  if (stack_0.$ === "Nil") {
    return {$: "FFresh", ["term"]: term_0, ["next"]: next_0};
  } else {
    const frame_0 = stack_0["head"];
    const rest_0 = stack_0["tail"];
    return run_jump($ffw_frame$, [frame_0, term_0, next_0, rest_0]);
  }
}

function $f_rename_var$(t_0, env_0) {
  if (env_0.$ === "Nil") {
    return t_0;
  } else {
    const m_0 = env_0["head"];
    const ms_0 = env_0["tail"];
    const x_0 = run_loop($ix$(t_0));
    const x_1 = run_loop($ix$(m_0));
    return run_jump($f_choose$, [(x_0 === x_1), run_clo((x_2) => {
    return run_jump($kt$, ["Var", run_loop($nm$(t_0)), run_loop($ix$(run_loop($kid$(m_0, 0)))), run_loop($qt$(t_0)), {$: "Nil"}]);
}), run_clo((x_3) => {
    return run_jump($f_rename_var$, [t_0, ms_0]);
})]);
  }
}

function $var$(name_0, id_0) {
  return run_jump($kt$, ["Var", name_0, id_0, 0, {$: "Nil"}]);
}

function $ffw_let$(env_0, bodyenv_0, items_0, built_0, next_0, stack_0) {
  if (items_0.$ === "Nil") {
    return run_jump($ffw_done$, [run_loop($kt$("Error", "empty core let", 0, 0, {$: "Nil"})), next_0, stack_0]);
  } else {
    const term_0 = items_0["head"];
    const tail_0 = items_0["tail"];
    return run_jump($ffw_let_tail$, [env_0, bodyenv_0, term_0, tail_0, built_0, next_0, stack_0]);
  }
}

function $ffw_kids$(term_0, env_0, pending_0, built_0, next_0, stack_0) {
  if (pending_0.$ === "Nil") {
    return run_jump($ffw_done$, [{$: "KTerm", ["tag"]: run_loop($tg$(term_0)), ["name"]: run_loop($nm$(term_0)), ["id"]: run_loop($ix$(term_0)), ["quant"]: run_loop($qt$(term_0)), ["kids"]: run_loop($List$reverse$(built_0)), ["removed"]: run_loop($rm$(term_0))}, next_0, stack_0]);
  } else {
    const head_0 = pending_0["head"];
    const rest_0 = pending_0["tail"];
    return run_jump($ffw_walk$, [head_0, env_0, next_0, {$: "Con", ["head"]: {$: "FFKids", ["term"]: term_0, ["env"]: env_0, ["pending"]: rest_0, ["built"]: built_0}, ["tail"]: stack_0}]);
  }
}

function $ffd_done$(book_0, next_0, stack_0) {
  if (stack_0.$ === "Nil") {
    return {$: "FFreshDefs", ["defs"]: book_0, ["next"]: next_0};
  } else {
    const frame_0 = stack_0["head"];
    const rest_0 = stack_0["tail"];
    return run_jump($ffd_frame$, [frame_0, book_0, next_0, rest_0]);
  }
}

function $ffd_type$(definition_0, pending_0, built_0, stack_0, result_0) {
  const typ_0 = result_0["term"];
  const next_0 = result_0["next"];
  return run_jump($ffd_value$, [definition_0, pending_0, built_0, stack_0, typ_0, run_loop($f_fresh_term$(run_loop($dv$(definition_0)), {$: "Nil"}, next_0))]);
}

function $dg_no_report$(name_0, message_0) {
  return {$: "DDiagnostic", ["expected"]: {$: "DText", ["text"]: message_0}, ["observed"]: {$: "DText", ["text"]: ""}, ["has_observed"]: false, ["context"]: {$: "Nil"}, ["definition"]: name_0, ["span"]: {$: "DNoSpan"}, ["note"]: "", ["trail"]: {$: "Nil"}};
}

function $dg_finish$(error_0, book_0, diagnostic_0, origins_0) {
  return {$: "DResult", ["error"]: error_0, ["book"]: book_0, ["diagnostic"]: run_loop($diagnostic_locate$(diagnostic_0, origins_0))};
}

function $check_open_message$(n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  const x_4 = run_loop($kc$((n_0 === 1), run_clo((x_2) => {
  return "";
}), run_clo((x_3) => {
  return "s";
})));
  const x_5 = (x_4 + " found.\nThe code is incomplete, and not a valid proof yet.");
  const x_6 = run_loop($U32$show$(n_0));
  const x_7 = (" TODO" + x_5);
  return (x_6 + x_7);
})]);
}

function $count_open$(book_0) {
  if (book_0.$ === "Nil") {
    return 0;
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    const x_2 = run_loop($kc$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "Def")), run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")))), run_loop($Bool$not$(run_loop($db$(d_0)))))), run_clo((x_0) => {
    return 1;
}), run_clo((x_1) => {
    return 0;
})));
    const x_3 = run_loop($count_open$(rest_0));
    return ((x_2 + x_3) >>> 0);
  }
}

function $dg_suffix_check$(rest_0, done_0, d_0, original_0, origins_0, checked_0) {
  return run_jump($kc$, [run_loop($good$(checked_0)), run_clo((x_0) => {
  return run_jump($dg_suffix_events$, [rest_0, run_loop($book_put$(done_0, d_0)), original_0, origins_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($ce$(checked_0));
  const x_3 = run_loop($dn$(d_0));
  const x_4 = (": " + x_2);
  return run_jump($dg_finish$, [(x_3 + x_4), run_loop($book_put$(done_0, run_loop($declared$(d_0)))), run_loop($dg_report$(checked_0, run_loop($dn$(d_0)))), origins_0]);
})]);
}

function $check_definition_result$(book_0, d_0) {
  return run_jump($check_definition_type$, [book_0, d_0, {$: "KEnv", ["book"]: book_0, ["name"]: run_loop($dn$(d_0)), ["lhs"]: run_loop($ref$(run_loop($dn$(d_0)))), ["pending"]: 0, ["quantities"]: {$: "Nil"}, ["unsafe"]: run_loop($du$(d_0))}, run_loop($check$({$: "KEnv", ["book"]: book_0, ["name"]: run_loop($dn$(d_0)), ["lhs"]: run_loop($ref$(run_loop($dn$(d_0)))), ["pending"]: 0, ["quantities"]: {$: "Nil"}, ["unsafe"]: run_loop($du$(d_0))}, {$: "Nil"}, run_loop($dt$(d_0)), 0, run_loop($typ$(1))))]);
}

function $declared$(d_0) {
  return {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($dt$(d_0)), ["value"]: run_loop($atom$("Absent")), ["ctors"]: run_loop($dc$(d_0)), ["native"]: run_loop($db$(d_0)), ["unsafe"]: run_loop($du$(d_0))};
}

function $signature_mode$(d_0, later_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "Def")), run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")))), run_loop($Bool$not$(run_loop($du$(d_0)))))), run_clo((x_0) => {
  return run_jump($signature_fill_mode$, [d_0, run_loop($lookup$(later_0, run_loop($dn$(d_0))))]);
}), run_clo((x_1) => {
  return d_0;
})]);
}

function $constructor_names$(done_0, ctrs_0, names_0) {
  if (ctrs_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ctrs_0["head"];
    const rest_0 = ctrs_0["tail"];
    const x_0 = run_loop($has_name$(names_0, run_loop($dn$(h_0))));
    const x_1 = run_loop($constructor_exists$(done_0, run_loop($dn$(h_0))));
    return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
    return "duplicate constructor name";
}), run_clo((x_3) => {
    return run_jump($constructor_names$, [done_0, rest_0, {$: "Con", ["head"]: run_loop($dn$(h_0)), ["tail"]: names_0}]);
})]);
  }
}

function $dg_rpad$(s_0, width_0) {
  const x_0 = run_loop($dg_width$(s_0));
  const x_4 = run_loop($dg_padding$(run_loop($kc$((width_0 > x_0), run_clo((x_1) => {
  const x_2 = run_loop($dg_width$(s_0));
  return ((width_0 - x_2) >>> 0);
}), run_clo((x_3) => {
  return 0;
})))));
  return (s_0 + x_4);
}

function $dg_width$(s_0) {
  if (s_0 === "") {
    return 0;
  } else {
    const c_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const rest_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    const x_0 = run_loop($dg_units$(c_0));
    const x_1 = run_loop($dg_width$(rest_0));
    return ((x_0 + x_1) >>> 0);
  }
}

function $dg_location_text$(name_0, snippet_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(name_0, "")), run_loop($String$eq$(snippet_0, "")))), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  const x_4 = run_loop($kc$(run_loop($String$eq$(name_0, "")), run_clo((x_2) => {
  return "";
}), run_clo((x_3) => {
  return (" " + name_0);
})));
  const x_5 = (x_4 + snippet_0);
  return ("\nLocation:" + x_5);
})]);
}

function $dg_snippet$(span_0) {
  if (span_0.$ === "DNoSpan") {
    return "";
  } else {
    const source_0 = span_0["source"];
    const begin_0 = span_0["begin"];
    const end_0 = span_0["end"];
    return run_jump($dg_snippet_at$, [run_loop($String$lines$(source_0)), run_loop($dg_line_at$(source_0, begin_0, 1))]);
  }
}

function $dg_span_same$(a_0, b_0) {
  if (a_0.$ === "DNoSpan") {
    return false;
  } else {
    const s_0 = a_0["source"];
    const b0_0 = a_0["begin"];
    const e0_0 = a_0["end"];
    return run_jump($dg_span_fields$, [s_0, b0_0, e0_0, b_0]);
  }
}

function $fp_loaded_modules$(done_0, book_0, sources_0, all_0, definition_0) {
  if (done_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const entry_0 = done_0["head"];
    const rest_0 = done_0["tail"];
    return run_jump($List$append$, [run_loop($fp_loaded_module$(run_loop($fp_loaded_take$(book_0, run_loop($ix$(entry_0)))), run_loop($f_graph_source$(run_loop($nm$(entry_0)), sources_0)), all_0, definition_0)), run_loop($fp_loaded_modules$(rest_0, run_loop($fp_loaded_drop$(book_0, run_loop($ix$(entry_0)))), sources_0, all_0, definition_0))]);
  }
}

function $Char$show$(c_0) {
  return (c_0 + "");
}

function $Char$from_u32$(x_0) {
  return char_new(x_0);
}

function $check_lam_done$(t_0, ty_0, q_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  const x_1 = run_loop($uses_get$(run_loop($cs$(r_0)), run_loop($ix$(t_0))));
  return run_jump($kc$, [(x_1 > q_0), run_clo((x_2) => {
  return run_jump($dg_quant_error$, ["affine variable consumed more than allowed", run_loop($nm$(t_0)), q_0, run_loop($uses_get$(run_loop($cs$(r_0)), run_loop($ix$(t_0))))]);
}), run_clo((x_3) => {
  return run_jump($ok$, [t_0, ty_0, run_loop($uses_del$(run_loop($cs$(r_0)), run_loop($ix$(t_0))))]);
})]);
}), run_clo((x_4) => {
  return r_0;
})]);
}

function $lhs_step$(e_0, x_0) {
  const x_1 = run_loop($cp$(e_0));
  return run_jump($kc$, [(x_1 === 0), run_clo((x_2) => {
  return e_0;
}), run_clo((x_3) => {
  const x_4 = run_loop($cp$(e_0));
  return {$: "KEnv", ["book"]: run_loop($cb$(e_0)), ["name"]: run_loop($cn$(e_0)), ["lhs"]: run_loop($kapply$(run_loop($cl$(e_0)), x_0)), ["pending"]: ((x_4 - 1) >>> 0), ["quantities"]: run_loop($cq$(e_0)), ["unsafe"]: run_loop($cu$(e_0))};
})]);
}

function $rm$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return removed_0;
}

function $tele_fill$(book_0, tel_0, args_0) {
  if (args_0.$ === "Nil") {
    return tel_0;
  } else {
    const h_0 = args_0["head"];
    const t_0 = args_0["tail"];
    return run_jump($tele_fill_head$, [book_0, run_loop($wnf$(book_0, tel_0)), h_0, t_0]);
  }
}

function $dg_ctor_error$(e_0, t_0, ty_0, ctr_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$(run_loop($String$eq$(run_loop($dk$(ctr_0)), "Absent")))), run_loop($Bool$not$(run_loop($has_name$(run_loop($rm$(ty_0)), run_loop($nm$(t_0)))))))), run_clo((x_0) => {
  const x_1 = run_loop($da$(ctr_0));
  const x_4 = run_loop($U32$show$(run_loop($da$(ctr_0))));
  const x_5 = run_loop($kc$((x_1 === 1), run_clo((x_2) => {
  return " field";
}), run_clo((x_3) => {
  return " fields";
})));
  const x_6 = (x_4 + x_5);
  const x_7 = run_loop($nm$(t_0));
  const x_8 = (" with " + x_6);
  return run_jump($dg_bad_detail$, ["constructor does not belong to goal or field count differs", run_loop($dg_text$((x_7 + x_8))), t_0]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dg_family$(run_loop($cb$(e_0)), run_loop($nm$(t_0)))), "")), run_clo((x_10) => {
  const x_11 = run_loop($dg_constructor_names$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(ty_0))))))));
  const x_12 = (x_11 + ")");
  const x_13 = run_loop($nm$(ty_0));
  const x_14 = (" declares " + x_12);
  const x_15 = (x_13 + x_14);
  return run_jump($dg_bad_detail$, ["constructor does not belong to goal or field count differs", run_loop($dg_text$(("a declared constructor (" + x_15))), t_0]);
}), run_clo((x_16) => {
  return run_jump($dg_bad_detail$, ["constructor does not belong to goal or field count differs", ty_0, run_loop($ref$(run_loop($dg_family$(run_loop($cb$(e_0)), run_loop($nm$(t_0))))))]);
})]);
})]);
}

function $dead_type$(book_0, ty_0) {
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(ty_0)), "ADT")), run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(book_0, run_loop($nm$(ty_0)))))), "ADT")))), run_loop($defs_empty$(run_loop($remaining$(run_loop($dc$(run_loop($lookup$(book_0, run_loop($nm$(ty_0)))))), run_loop($rm$(ty_0))))))]);
}

function $ctx_dead$(book_0, ctx_0) {
  if (ctx_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = ctx_0["head"];
    const t_0 = ctx_0["tail"];
    const x_0 = run_loop($qt$(h_0));
    return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
    return run_jump($ctx_dead$, [book_0, t_0]);
}), run_clo((x_2) => {
    const x_3 = run_loop($dead_type$(book_0, run_loop($wnf$(book_0, run_loop($kid$(h_0, 0))))));
    const x_4 = run_loop($ctx_dead$(book_0, t_0));
    return (x_3 || x_4);
})]);
  }
}

function $dg_constructor_names$(ds_0) {
  if (ds_0.$ === "Nil") {
    return "";
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    const x_3 = run_loop($dn$(d_0));
    const x_4 = run_loop($kc$(run_loop($defs_empty$(rest_0)), run_clo((x_0) => {
    return "";
}), run_clo((x_1) => {
    const x_2 = run_loop($dg_constructor_names$(rest_0));
    return (", " + x_2);
})));
    return (x_3 + x_4);
  }
}

function $remaining$(cs_0, removed_0) {
  if (cs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = cs_0["head"];
    const t_0 = cs_0["tail"];
    return run_jump($kc$, [run_loop($has_name$(removed_0, run_loop($dn$(h_0)))), run_clo((x_0) => {
    return run_jump($remaining$, [t_0, removed_0]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($remaining$(t_0, removed_0))};
})]);
  }
}

function $check_mat_ctr$(e_0, ctx_0, t_0, dem_0, ty_0, a_0, ctr_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(ctr_0)), "Absent")), run_clo((x_0) => {
  const x_1 = run_loop($nm$(a_0));
  const x_2 = (x_1 + " (missing, or already matched)");
  return run_jump($dg_bad_detail$, ["unknown or duplicate match constructor", run_loop($dg_text$(("a constructor of " + x_2))), t_0]);
}), run_clo((x_3) => {
  return run_jump($both$, [run_loop($check$(run_loop($mat_lhs$(e_0, run_loop($nm$(t_0)), run_loop($tele_fill$(run_loop($cb$(e_0)), run_loop($dt$(ctr_0)), run_loop($ks$(a_0)))), run_loop($da$(ctr_0)))), ctx_0, run_loop($kid$(t_0, 0)), dem_0, run_loop($mat_goal$(run_loop($cb$(e_0)), ty_0, run_loop($tele_fill$(run_loop($cb$(e_0)), run_loop($dt$(ctr_0)), run_loop($ks$(a_0)))), run_loop($da$(ctr_0)), run_loop($nm$(t_0)), {$: "Nil"})))), run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), dem_0, run_loop($all$(run_loop($qt$(ty_0)), run_loop($nm$(ty_0)), run_loop($ix$(ty_0)), {$: "KTerm", ["tag"]: run_loop($tg$(a_0)), ["name"]: run_loop($nm$(a_0)), ["id"]: run_loop($ix$(a_0)), ["quant"]: run_loop($qt$(a_0)), ["kids"]: run_loop($ks$(a_0)), ["removed"]: {$: "Con", ["head"]: run_loop($nm$(t_0)), ["tail"]: run_loop($rm$(a_0))}}, run_loop($kid$(ty_0, 1)))))), t_0, ty_0, true]);
})]);
}

function $check_let_kind$(e_0, outer_0, ctx_0, h_0, rest_0, dem_0, ty_0, bindings_0, us_0, r_0, k_0) {
  return run_jump($kc$, [run_loop($good$(k_0)), run_clo((x_0) => {
  return run_jump($check_let$, [e_0, outer_0, run_loop($ctx_bind$(ctx_0, run_loop($ix$(h_0)), run_loop($qt$(h_0)), run_loop($nm$(h_0)), run_loop($cy$(r_0)))), rest_0, dem_0, ty_0, {$: "Con", ["head"]: h_0, ["tail"]: bindings_0}, run_loop($uses_merge$(us_0, run_loop($cs$(r_0)), false))]);
}), run_clo((x_1) => {
  return k_0;
})]);
}

function $uses_get$(xs_0, id_0) {
  if (xs_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    const x_0 = run_loop($ix$(h_0));
    return run_jump($kc$, [(x_0 === id_0), run_clo((x_1) => {
    return run_jump($qt$, [h_0]);
}), run_clo((x_2) => {
    return run_jump($uses_get$, [t_0, id_0]);
})]);
  }
}

function $dg_quant_error$(message_0, name_0, allowed_0, used_0) {
  const x_0 = run_loop($kp_quant$(allowed_0));
  return run_jump($dg_bad_detail$, [message_0, run_loop($dg_text$((x_0 + name_0))), run_loop($dg_text$(run_loop($kc$((used_0 === 2), run_clo((x_1) => {
  return (name_0 + " (consumed more than once)");
}), run_clo((x_2) => {
  const x_3 = run_loop($kp_quant$(used_0));
  return (x_3 + name_0);
})))))]);
}

function $uses_del$(xs_0, id_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    const x_0 = run_loop($ix$(h_0));
    return run_jump($kc$, [(x_0 === id_0), run_clo((x_1) => {
    return run_jump($uses_del$, [t_0, id_0]);
}), run_clo((x_2) => {
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($uses_del$(t_0, id_0))};
})]);
  }
}

function $check_rwt_goal$(e_0, ctx_0, t_0, dem_0, ty_0, r_0, eq_0, fresh_0) {
  return run_jump($kc$, [run_loop($compare$(run_loop($cb$(e_0)), run_loop($kapply$(run_loop($kapply$(run_loop($kid$(t_0, 1)), run_loop($kid$(eq_0, 1)))), run_loop($kid$(t_0, 0)))), ty_0, true)), run_clo((x_0) => {
  return run_jump($both$, [r_0, run_loop($both$(run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 1)), 0, run_loop($all$(1, "_", fresh_0, run_loop($kid$(eq_0, 2)), run_loop($all$(1, "e", ((fresh_0 + 1) >>> 0), run_loop($kt$("Eql", "", 0, 0, {$: "Con", ["head"]: run_loop($kid$(eq_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($var$("_", fresh_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(eq_0, 2)), ["tail"]: {$: "Nil"}}}})), run_loop($typ$(1)))))))), run_loop($check$(e_0, ctx_0, run_loop($kid$(t_0, 2)), dem_0, run_loop($kapply$(run_loop($kapply$(run_loop($kid$(t_0, 1)), run_loop($kid$(eq_0, 0)))), run_loop($atom$("Rfl")))))), t_0, ty_0, false)), t_0, ty_0, false]);
}), run_clo((x_1) => {
  return run_jump($dg_bad_detail$, ["rewrite motive does not fit goal", ty_0, run_loop($kapply$(run_loop($kapply$(run_loop($kid$(t_0, 1)), run_loop($kid$(eq_0, 1)))), run_loop($kid$(t_0, 0))))]);
})]);
}

function $subst_node$(t_0, id_0, v_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const n_0 = t_0["id"];
  const q_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return run_jump($core_rebuild$, [{$: "KTerm", ["tag"]: tag_0, ["name"]: name_0, ["id"]: n_0, ["quant"]: q_0, ["kids"]: run_loop($subst_terms$(kids_0, id_0, v_0)), ["removed"]: removed_0}]);
}

function $descend_step$(ord_0, qs_0, args_0, cols_0) {
  return run_jump($kc$, [(ord_0 === 0), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  return run_jump($kc$, [(ord_0 === 1), run_clo((x_2) => {
  return run_jump($descend_spine$, [qs_0, args_0, cols_0]);
}), run_clo((x_3) => {
  return false;
})]);
})]);
}

function $descend$(q_0, a_0, p_0) {
  return run_jump($kc$, [(q_0 === 0), run_clo((x_0) => {
  return 1;
}), run_clo((x_1) => {
  return run_jump($descend_go$, [run_loop($strip$(a_0)), run_loop($strip$(p_0))]);
})]);
}

function $terms_tail$(ts_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    return t_0;
  }
}

function $template_args$(e_0, ty_0, sp_0, n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return run_jump($ok$, [run_loop($atom$("Args")), ty_0, {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($template_arg_head$, [e_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0)), sp_0, n_0]);
})]);
}

function $qjoin$(a_0, b_0) {
  return run_jump($kc$, [(a_0 > b_0), run_clo((x_0) => {
  return a_0;
}), run_clo((x_1) => {
  return b_0;
})]);
}

function $qadd$(a_0, b_0) {
  return run_jump($kc$, [(a_0 === 0), run_clo((x_0) => {
  return b_0;
}), run_clo((x_1) => {
  return run_jump($kc$, [(b_0 === 0), run_clo((x_2) => {
  return a_0;
}), run_clo((x_3) => {
  return 2;
})]);
})]);
}

function $tele_check_cached_head$(e_0, ctx_0, tel_0, h_0, rest_0, dem_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
  return run_jump($tele_check_after_head$, [e_0, ctx_0, tel_0, h_0, rest_0, dem_0, run_loop($check$(e_0, ctx_0, h_0, run_loop($qdem$(run_loop($qt$(tel_0)), dem_0)), run_loop($kid$(tel_0, 0))))]);
}), run_clo((x_1) => {
  return run_jump($bad$, ["too many telescope arguments"]);
})]);
}

function $ka_wrap$(t_0, ty_0) {
  return run_jump($kt$, ["Ann", "", 0, 0, {$: "Con", ["head"]: t_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}}]);
}

function $ka_node$(e_0, ctx_0, t_0, ty_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_0) => {
  return run_jump($ka_node$, [e_0, ctx_0, run_loop($kid$(t_0, 0)), run_loop($wnf$(run_loop($cb$(e_0)), run_loop($kid$(t_0, 1))))]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_2) => {
  return run_jump($ka_lam$, [e_0, ctx_0, t_0, ty_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_4) => {
  return run_jump($kc$, [run_loop($ka_spine_eligible$(t_0)), run_clo((x_5) => {
  return run_jump($ka_app_spine$, [e_0, ctx_0, t_0]);
}), run_clo((x_6) => {
  return run_jump($ka_app$, [e_0, ctx_0, t_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($ka_type$(e_0, ctx_0, run_loop($kid$(t_0, 0))))))]);
})]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr")), run_clo((x_8) => {
  return run_jump($kt$, ["Ctr", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), run_loop($ka_args_cached$(e_0, ctx_0, run_loop($tele_fill$(run_loop($cb$(e_0)), run_loop($dt$(run_loop($lookup$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(ty_0)))))), run_loop($nm$(t_0)))))), run_loop($ks$(ty_0)))), run_loop($ks$(t_0))))]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_10) => {
  return run_jump($ka_mat$, [e_0, ctx_0, t_0, ty_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($kid$(ty_0, 0))))]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_12) => {
  return run_jump($kt$, ["Let", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), run_loop($ka_let$(e_0, ctx_0, ctx_0, run_loop($ks$(t_0)), ty_0))]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_14) => {
  return run_jump($ka_rwt$, [e_0, ctx_0, t_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($ka_type$(e_0, ctx_0, run_loop($kid$(t_0, 0))))))]);
}), run_clo((x_15) => {
  return t_0;
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $U32$show$go$(f_0, n_0, acc_0) {
  if (f_0 === 0n) {
    return acc_0;
  } else {
    const g_0 = (f_0 - 1n);
    return run_jump($U32$show$fin$, [g_0, acc_0, n_0, (n_0 === 0)]);
  }
}

function $kp_is$(t_0, tag_0, name_0) {
  return run_jump($Bool$and$, [run_loop($kp_eq$(run_loop($tg$(t_0)), tag_0)), run_loop($kp_eq$(run_loop($nm$(t_0)), name_0))]);
}

function $kp_exists$(A_0, b_0, p_0, env_0) {
  const x_0 = run_loop($kp_go$(run_loop($kid$(b_0, 0)), 2, run_loop($kp_bind$(env_0, b_0))));
  const x_1 = run_loop($kp_go$(A_0, 3, env_0));
  const x_2 = (" -> " + x_0);
  const x_3 = (x_1 + x_2);
  const x_4 = run_loop($nm$(b_0));
  const x_5 = (":" + x_3);
  const x_6 = (x_4 + x_5);
  return run_jump($kp_par$, [("&" + x_6), (p_0 > 2)]);
}

function $kp_join$(xs_0, sep_0) {
  if (xs_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = xs_0["head"];
    const _t_0 = xs_0["tail"];
    if (_t_0.$ === "Nil") {
      return h_0;
    } else {
      const x_0 = run_loop($kp_join$(_t_0, sep_0));
      const x_1 = (sep_0 + x_0);
      return (h_0 + x_1);
    }
  }
}

function $kp_each$(ts_0, p_0, env_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($kp_go$(h_0, p_0, env_0)), ["tail"]: run_loop($kp_each$(t_0, p_0, env_0))};
  }
}

function $kp_has_removed$(xs_0) {
  if (xs_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return true;
  }
}

function $kp_removed$(xs_0) {
  if (xs_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    const x_0 = run_loop($kp_removed$(t_0));
    const x_1 = ("{}" + x_0);
    const x_2 = (h_0 + x_1);
    return (" - " + x_2);
  }
}

function $kp_ctor_number$(n_0, t_0, p_0, env_0) {
  if (n_0.$ === "Some") {
    const x_0 = n_0["value"];
    return run_jump($kc$, [run_loop($kp_eq$(run_loop($nm$(t_0)), "F32")), run_clo((x_1) => {
    return run_jump($kp_float_show$, [x_0]);
}), run_clo((x_2) => {
    return run_jump($U32$show$, [x_0]);
})]);
  } else {
    return run_jump($kp_ctor_other$, [t_0, p_0, env_0]);
  }
}

function $kp_number$(t_0) {
  const x_0 = run_loop($kp_is$(t_0, "Ctr", "U32"));
  const x_1 = run_loop($kp_is$(t_0, "Ctr", "F32"));
  const x_2 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$((x_0 || x_1), (x_2 === 1))), run_clo((x_3) => {
  return run_jump($kp_word$, [run_loop($kid$(t_0, 0)), 1, 32, 0]);
}), run_clo((x_4) => {
  return {$: "None"};
})]);
}

function $kp_rewrite$(t_0, p_0, env_0) {
  const x_0 = run_loop($kp_go$(run_loop($kid$(t_0, 2)), 0, env_0));
  const x_1 = run_loop($kp_rewrite_motive$(run_loop($kid$(t_0, 0)), run_loop($kid$(t_0, 1)), env_0));
  const x_2 = ("; " + x_0);
  const x_3 = (x_1 + x_2);
  return run_jump($kp_par$, [("%" + x_3), (p_0 > 1)]);
}

function $kp_let$(t_0, p_0, env_0) {
  const x_0 = run_loop($kp_let_body$(run_loop($ks$(t_0)), env_0));
  const x_1 = run_loop($kp_let_vals$(run_loop($ks$(t_0)), env_0));
  const x_2 = ("; " + x_0);
  const x_3 = (x_1 + x_2);
  const x_4 = run_loop($kp_let_names$(run_loop($ks$(t_0))));
  const x_5 = (" = " + x_3);
  return run_jump($kp_par$, [(x_4 + x_5), (p_0 > 0)]);
}

function $sp_neededs$(book_0, ts_0) {
  if (ts_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($kc$, [run_loop($sp_needed$(book_0, h_0)), run_clo((x_0) => {
    return true;
}), run_clo((x_1) => {
    return run_jump($sp_neededs$, [book_0, rest_0]);
})]);
  }
}

function $sp_put$(st_0, d_0) {
  return {$: "KSpecState", ["book"]: {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_remove$(run_loop($sp_book$(st_0)), run_loop($dn$(d_0))))}, ["memo"]: run_loop($sp_memo$(st_0)), ["serial"]: run_loop($sp_serial$(st_0)), ["fresh"]: run_loop($sp_fresh$(st_0)), ["error"]: run_loop($sp_error$(st_0)), ["templates"]: run_loop($sp_templates$(st_0))};
}

function $sp_state$(r_0) {
  const state_0 = r_0["state"];
  const term_0 = r_0["term"];
  return state_0;
}

function $sp_value$(r_0) {
  const state_0 = r_0["state"];
  const term_0 = r_0["term"];
  return term_0;
}

function $sp_spine$(st_0, t_0, xs_0, ctx_0, owner_0, depth_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($sp_spine$, [st_0, run_loop($kid$(t_0, 0)), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: xs_0}, ctx_0, owner_0, depth_0]);
}), run_clo((x_1) => {
  return run_jump($sp_head$, [st_0, t_0, xs_0, ctx_0, owner_0, depth_0, run_loop($lookup$(run_loop($sp_book$(st_0)), run_loop($nm$(run_loop($strip$(t_0))))))]);
})]);
}

function $sp_annotation$(t_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_state$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Nil"}}}, ["removed"]: run_loop($rm$(t_0))}};
}

function $sp_lambda$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0) {
  return run_jump($sp_single$, [t_0, run_loop($sp_term$(st_0, run_loop($kid$(t_0, 0)), run_loop($ctx_bind$(ctx_0, run_loop($ix$(t_0)), run_loop($qt$(goal_0)), run_loop($nm$(t_0)), run_loop($kid$(goal_0, 0)))), run_loop($subst$(run_loop($kid$(goal_0, 1)), run_loop($ix$(goal_0)), run_loop($var$(run_loop($nm$(t_0)), run_loop($ix$(t_0)))))), owner_0, depth_0))]);
}

function $sp_match$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0) {
  return run_jump($sp_match_type$, [st_0, t_0, ctx_0, goal_0, owner_0, depth_0, run_loop($wnf$(run_loop($sp_book$(st_0)), run_loop($kid$(goal_0, 0))))]);
}

function $sp_constructor$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0) {
  return run_jump($sp_ctor_done$, [t_0, run_loop($sp_args$(st_0, run_loop($ks$(t_0)), ctx_0, run_loop($tele_fill$(run_loop($sp_book$(st_0)), run_loop($dt$(run_loop($lookup$(run_loop($dc$(run_loop($lookup$(run_loop($sp_book$(st_0)), run_loop($nm$(goal_0)))))), run_loop($nm$(t_0)))))), run_loop($ks$(goal_0)))), owner_0, depth_0))]);
}

function $sp_let_result$(t_0, r_0) {
  return run_jump($sp_ctor_done$, [t_0, r_0]);
}

function $sp_let$(st_0, xs_0, outer_0, ctx_0, goal_0, owner_0, depth_0) {
  if (xs_0.$ === "Nil") {
    return {$: "KSpecTerms", ["state"]: run_loop($sp_fail$(st_0, "let has no body")), ["terms"]: {$: "Nil"}};
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(h_0)), "Bind")), run_clo((x_0) => {
    return run_jump($sp_let_binding$, [st_0, h_0, rest_0, outer_0, ctx_0, goal_0, owner_0, depth_0, run_loop($sp_type$(st_0, run_loop($kid$(h_0, 0)), outer_0, owner_0))]);
}), run_clo((x_1) => {
    return run_jump($sp_let_body$, [run_loop($sp_term$(st_0, h_0, ctx_0, goal_0, owner_0, depth_0))]);
})]);
  }
}

function $sp_rewrite$(st_0, t_0, ctx_0, owner_0, depth_0) {
  return run_jump($sp_rewrite_type$, [st_0, t_0, ctx_0, owner_0, depth_0, run_loop($wnf$(run_loop($sp_book$(st_0)), run_loop($sp_type$(st_0, run_loop($kid$(t_0, 0)), ctx_0, owner_0))))]);
}

function $book_final_name_valid$(name_0) {
  if (name_0 === "") {
    return true;
  } else {
    const h_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(0, 2) : name_0[0]);
    const rest_0 = (name_0.codePointAt(0) > 0xFFFF ? name_0.slice(2) : name_0.slice(1));
    const x_0 = run_loop($Char$to_u32$(h_0));
    const x_1 = ((x_0 - 55296) >>> 0);
    return run_jump($kc$, [(x_1 <= 2047), run_clo((x_2) => {
    return false;
}), run_clo((x_3) => {
    return run_jump($book_final_name_valid$, [rest_0]);
})]);
  }
}

function $book_final_filter$(done_0, seen_0) {
  if (done_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = done_0["head"];
    const rest_0 = done_0["tail"];
    return run_jump($kc$, [run_loop($book_final_seen$(seen_0, run_loop($dn$(d_0)), run_loop($index_hash$(run_loop($dn$(d_0)), 2166136261)))), run_clo((x_0) => {
    return run_jump($book_final_filter$, [rest_0, seen_0]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: d_0, ["tail"]: run_loop($book_final_filter$(rest_0, seen_0))};
})]);
  }
}

function $book_final_step$(d_0, rest_0, seen_0, kept_0, done_0, hash_0) {
  return run_jump($kc$, [run_loop($book_final_seen$(seen_0, run_loop($dn$(d_0)), hash_0)), run_clo((x_0) => {
  return run_jump($book_final_scan$, [rest_0, seen_0, kept_0, done_0]);
}), run_clo((x_1) => {
  return run_jump($book_final_scan$, [rest_0, run_loop($index_set$(seen_0, {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: "$final.seen", ["arity"]: 0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: true, ["unsafe"]: false}, hash_0, 32)), {$: "Con", ["head"]: d_0, ["tail"]: kept_0}, done_0]);
})]);
}

function $g_snf_head$(book_0, stack_0, fresh_0, r_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(run_loop($g_term$(r_0)))), "Lam"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(run_loop($g_term$(r_0)))), "All"));
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($g_snf_open$, [book_0, run_loop($g_state$(r_0)), run_loop($norm_rebind$(run_loop($g_term$(r_0)), fresh_0)), stack_0, ((fresh_0 + 1) >>> 0)]);
}), run_clo((x_3) => {
  return run_jump($g_snf_open$, [book_0, run_loop($g_state$(r_0)), run_loop($g_term$(r_0)), stack_0, fresh_0]);
})]);
}

function $g_wnf$(book_0, st_0, t_0) {
  return run_jump($g_eval$, [book_0, st_0, t_0, {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Nil"}]);
}

function $norm_let_tail$(h_0, rest_0) {
  if (rest_0.$ === "Nil") {
    return h_0;
  } else {
    const x_0 = rest_0["head"];
    const xs_0 = rest_0["tail"];
    return run_jump($subst$, [run_loop($norm_let$({$: "Con", ["head"]: x_0, ["tail"]: xs_0})), run_loop($ix$(h_0)), run_loop($kid$(h_0, 0))]);
  }
}

function $norm_min_left$(book_0, a_0, b_0) {
  const x_0 = run_loop($qt$(a_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")), (x_0 === 2))), run_clo((x_1) => {
  return run_jump($wnf$, [book_0, b_0]);
}), run_clo((x_2) => {
  const x_3 = run_loop($qt$(a_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")), (x_3 === 0))), run_clo((x_4) => {
  return a_0;
}), run_clo((x_5) => {
  return run_jump($norm_min_right$, [a_0, run_loop($wnf$(book_0, b_0))]);
})]);
})]);
}

function $norm_dec$(n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return 0;
}), run_clo((x_1) => {
  return ((n_0 - 1) >>> 0);
})]);
}

function $norm_match$(book_0, arm_0, original_0, raw_0, x_0, args_0, left_0, fallback_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(x_0)), "Ctr")), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Ann")), run_clo((x_2) => {
  return run_jump($norm_match$, [book_0, run_loop($kid$(arm_0, 0)), original_0, raw_0, x_0, args_0, left_0, fallback_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Mat")), run_clo((x_4) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($nm$(arm_0)), run_loop($nm$(x_0)))), run_clo((x_5) => {
  return run_jump($kc$, [(left_0 === 0), run_clo((x_6) => {
  return run_jump($norm_eval$, [book_0, run_loop($kid$(arm_0, 0)), run_loop($norm_join$(run_loop($ks$(x_0)), args_0)), 0, fallback_0]);
}), run_clo((x_7) => {
  const x_8 = run_loop($norm_dec$(left_0));
  const x_9 = run_loop($terms_len$(run_loop($ks$(x_0))));
  return run_jump($norm_eval$, [book_0, run_loop($kid$(arm_0, 0)), run_loop($norm_join$(run_loop($ks$(x_0)), args_0)), ((x_8 + x_9) >>> 0), fallback_0]);
})]);
}), run_clo((x_10) => {
  return run_jump($norm_match$, [book_0, run_loop($kid$(arm_0, 1)), original_0, raw_0, x_0, args_0, left_0, fallback_0]);
})]);
}), run_clo((x_11) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Efq")), run_clo((x_12) => {
  return run_jump($norm_stuck$, [original_0, raw_0, args_0, left_0, fallback_0]);
}), run_clo((x_13) => {
  return run_jump($norm_eval$, [book_0, arm_0, {$: "Con", ["head"]: x_0, ["tail"]: args_0}, left_0, fallback_0]);
})]);
})]);
})]);
}), run_clo((x_14) => {
  return run_jump($norm_stuck$, [original_0, raw_0, args_0, left_0, fallback_0]);
})]);
}

function $norm_exact_head$(a_0, b_0) {
  const x_0 = run_loop($ix$(a_0));
  const x_1 = run_loop($ix$(b_0));
  const x_2 = run_loop($qt$(a_0));
  const x_3 = run_loop($qt$(b_0));
  const x_4 = run_loop($terms_len$(run_loop($ks$(a_0))));
  const x_5 = run_loop($terms_len$(run_loop($ks$(b_0))));
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), run_loop($tg$(b_0)))), run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(b_0)))))), (x_0 === x_1))), (x_2 === x_3))), (x_4 === x_5))), run_loop($norm_exact_names$(run_loop($rm$(a_0)), run_loop($rm$(b_0))))]);
}

function $norm_cmp_same$(book_0, a_0, b_0, le_0, fresh_0, rest_0, alts_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), "Var")), run_clo((x_0) => {
  const x_1 = run_loop($ix$(a_0));
  const x_2 = run_loop($ix$(b_0));
  return run_jump($norm_cmp_test$, [book_0, (x_1 === x_2), rest_0, alts_0]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), "Typ")), run_clo((x_4) => {
  return run_jump($kc$, [le_0, run_clo((x_5) => {
  return run_jump($norm_cmp_kind$, [book_0, a_0, b_0, run_loop($wnf$(book_0, run_loop($kid$(a_0, 0)))), run_loop($wnf$(book_0, run_loop($kid$(b_0, 0)))), fresh_0, rest_0, alts_0]);
}), run_clo((x_6) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($kid$(a_0, 0)), ["b"]: run_loop($kid$(b_0, 0)), ["le"]: false, ["fresh"]: fresh_0}, ["tail"]: rest_0}, alts_0]);
})]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), "All")), run_clo((x_8) => {
  const x_9 = run_loop($qt$(a_0));
  const x_10 = run_loop($qt$(b_0));
  return run_jump($kc$, [(x_9 === x_10), run_clo((x_11) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($kid$(b_0, 0)), ["b"]: run_loop($kid$(a_0, 0)), ["le"]: le_0, ["fresh"]: fresh_0}, ["tail"]: {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($subst$(run_loop($kid$(a_0, 1)), run_loop($ix$(a_0)), run_loop($var$("_", fresh_0)))), ["b"]: run_loop($subst$(run_loop($kid$(b_0, 1)), run_loop($ix$(b_0)), run_loop($var$("_", fresh_0)))), ["le"]: le_0, ["fresh"]: ((fresh_0 + 1) >>> 0)}, ["tail"]: rest_0}}, alts_0]);
}), run_clo((x_12) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
}), run_clo((x_13) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), "ADT")), run_clo((x_14) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(b_0)))), run_loop($norm_removed$(run_loop($rm$(a_0)), run_loop($rm$(b_0)), le_0)))), run_clo((x_15) => {
  return run_jump($norm_cmp_fields$, [book_0, run_loop($ks$(a_0)), run_loop($ks$(b_0)), fresh_0, rest_0, alts_0]);
}), run_clo((x_16) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
}), run_clo((x_17) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")), run_clo((x_18) => {
  const x_19 = run_loop($qt$(a_0));
  const x_20 = run_loop($qt$(b_0));
  return run_jump($norm_cmp_test$, [book_0, (x_19 === x_20), rest_0, alts_0]);
}), run_clo((x_21) => {
  return run_jump($norm_cmp_plain$, [book_0, a_0, b_0, fresh_0, rest_0, alts_0]);
})]);
})]);
})]);
})]);
})]);
}

function $norm_cmp_fail$(book_0, alts_0) {
  if (alts_0.$ === "Nil") {
    return false;
  } else {
    const _t_0 = alts_0["head"];
    const todo_0 = _t_0["todo"];
    const rest_0 = alts_0["tail"];
    return run_jump($norm_cmp_loop$, [book_0, todo_0, rest_0]);
  }
}

function $exact_terms$(a_0, b_0) {
  if (a_0.$ === "Nil") {
    const x_0 = run_loop($terms_len$(b_0));
    return (x_0 === 0);
  } else {
    const h_0 = a_0["head"];
    const rest_0 = a_0["tail"];
    return run_jump($exact_terms_head$, [h_0, rest_0, b_0]);
  }
}

function $exact_names$(a_0, b_0) {
  if (a_0.$ === "Nil") {
    return run_jump($exact_names_empty$, [b_0]);
  } else {
    const h_0 = a_0["head"];
    const rest_0 = a_0["tail"];
    return run_jump($exact_names_head$, [h_0, rest_0, b_0]);
  }
}

function $defs_empty$(ds_0) {
  if (ds_0.$ === "Nil") {
    return true;
  } else {
    const h_0 = ds_0["head"];
    const t_0 = ds_0["tail"];
    return false;
  }
}

function $exact_defs_head$(h_0, rest_0, b_0) {
  if (b_0.$ === "Nil") {
    return false;
  } else {
    const x_0 = b_0["head"];
    const xs_0 = b_0["tail"];
    return run_jump($Bool$and$, [run_loop($exact_def$(h_0, x_0)), run_loop($exact_defs$(rest_0, xs_0))]);
  }
}

function $List$append$(xs_0, ys_0) {
  if (xs_0.$ === "Nil") {
    return ys_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($List$append$(t_0, ys_0))};
  }
}

function $kr_refs$(t_0, todo_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ref"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(t_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($String$eq$(run_loop($tg$(t_0)), "Mat"));
  return run_jump($kr_refs_list$, [run_loop($ks$(t_0)), run_loop($kc$((x_4 || x_5), run_clo((x_6) => {
  return run_jump($kr_push$, [run_loop($nm$(t_0)), todo_0]);
}), run_clo((x_7) => {
  return todo_0;
})))]);
}

function $kr_ctor_refs$(ctors_0, todo_0) {
  if (ctors_0.$ === "Nil") {
    return todo_0;
  } else {
    const d_0 = ctors_0["head"];
    const rest_0 = ctors_0["tail"];
    return run_jump($kr_refs$, [run_loop($dt$(d_0)), run_loop($kr_ctor_refs$(rest_0, todo_0))]);
  }
}

function $kr_parent$(book_0, name_0) {
  if (book_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_loop($Bool$not$(run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(run_loop($dc$(d_0)), name_0)))), "Absent")))))), run_clo((x_0) => {
    return d_0;
}), run_clo((x_1) => {
    return run_jump($kr_parent$, [rest_0, name_0]);
})]);
  }
}

function $String$cmp$rec$(h1b_0, h2b_0, rr_0) {
  const _t_0 = rr_0["fst"];
  const t1b_0 = _t_0["fst"];
  const t2b_0 = _t_0["snd"];
  const r_0 = rr_0["snd"];
  return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1b_0), ["snd"]: (h2b_0 + t2b_0)}, ["snd"]: r_0};
}

function $index_child_list$(ds_0, right_0) {
  if (ds_0.$ === "Nil") {
    return run_jump($missing$, []);
  } else {
    const h_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return run_jump($kc$, [right_0, run_clo((x_0) => {
    return run_jump($index_first$, [rest_0]);
}), run_clo((x_1) => {
    return h_0;
})]);
  }
}

function $fpe_here$(source_0, rest_0, error_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(rest_0)), run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($nm$(run_loop($kid$(error_0, 1)))), "<eof>")), run_clo((x_1) => {
  return run_jump($fpe_message$, [source_0, error_0, "end of input"]);
}), run_clo((x_2) => {
  return run_jump($nm$, [error_0]);
})]);
}), run_clo((x_3) => {
  const x_4 = run_loop($Char$to_u32$(run_loop($f_head$(rest_0))));
  const x_5 = run_loop($Char$to_u32$(run_loop($f_head$(run_loop($nm$(run_loop($kid$(error_0, 1))))))));
  const x_6 = run_loop($Char$to_u32$(run_loop($f_head$(rest_0))));
  const x_7 = run_loop($Bool$not$((x_4 === x_5)));
  const x_8 = (x_6 > 65535);
  const x_9 = run_loop($Char$to_u32$(run_loop($f_head$(rest_0))));
  const x_10 = run_loop($Char$to_u32$(run_loop($f_head$(rest_0))));
  const x_11 = (x_7 || x_8);
  const x_12 = run_loop($Bool$and$((x_9 >= 55296), (x_10 <= 57343)));
  return run_jump($f_choose$, [(x_11 || x_12), run_clo((x_13) => {
  return run_jump($nm$, [error_0]);
}), run_clo((x_14) => {
  const x_15 = (run_loop($f_head$(rest_0)) + "");
  const x_16 = (x_15 + "'");
  return run_jump($fpe_message$, [source_0, error_0, ("'" + x_16)]);
})]);
})]);
}

function $f_import_leading$(ts_0, book_0, imports_0, unsafe_0) {
  if (book_0.$ === "Nil") {
    return run_jump($f_choose$, [unsafe_0, run_clo((x_0) => {
    return run_jump($f_result$, [{$: "Nil"}, run_loop($f_pn$(run_loop($f_err$(ts_0, "expected def after @unsafe")))), imports_0]);
}), run_clo((x_1) => {
    return run_jump($f_import$, [run_loop($f_tl$(ts_0)), {$: "Nil"}, imports_0]);
})]);
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    return run_jump($f_result$, [{$: "Con", ["head"]: d_0, ["tail"]: rest_0}, run_loop($f_pn$(run_loop($fpe_error$(ts_0, "expected def, law or type; imports must precede declarations", "'def', 'type' or 'law'")))), imports_0]);
  }
}

function $f_law$(name_0, ts_0, book_0, imports_0, clauses_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_valid_name$(name_0)), run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(name_0, book_0)))), "Missing")))), run_clo((x_0) => {
  return run_jump($f_law_base$, [name_0, ts_0, book_0, imports_0, clauses_0]);
}), run_clo((x_1) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", ("invalid or reserved law name: " + name_0), 0, 0, {$: "Nil"})), imports_0]);
})]);
}

function $f_def$(name_0, p_0, book_0, imports_0, unsafe_0) {
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($f_valid_name$(name_0)))), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", ("reserved definition name: " + name_0), 0, 0, {$: "Nil"})), imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_def_prior$, [name_0, p_0, book_0, imports_0, unsafe_0, run_loop($f_find$(name_0, book_0))]);
})]);
}

function $f_tele$(ts0_0, end_0, acc_0) {
  return run_jump($f_tele_at$, [run_loop($f_skip$(ts0_0)), end_0, acc_0]);
}

function $f_type$(name_0, ts_0, book_0, imports_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_valid_name$(name_0)), run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(name_0, book_0)))), "Missing")))), run_clo((x_0) => {
  return run_jump($f_type_named$, [name_0, ts_0, book_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", ("invalid or reserved datatype name: " + name_0), 0, 0, {$: "Nil"})), imports_0]);
})]);
}

function $fpe_error$(ts_0, legacy_0, expected_0) {
  return run_jump($fpe_legacy$, [ts_0, run_loop($nm$(run_loop($f_pn$(run_loop($f_err$(ts_0, legacy_0)))))), expected_0]);
}

function $f_line$(ts_0) {
  if (ts_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = ts_0["head"];
    const t_0 = _t_0["text"];
    const l_0 = _t_0["f_line"];
    const c_0 = _t_0["f_col"];
    const k_0 = _t_0["f_kind"];
    const rest_0 = ts_0["tail"];
    return l_0;
  }
}

function $String$reverse$go$(s_0, acc_0) {
  if (s_0 === "") {
    return acc_0;
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return run_jump($String$reverse$go$, [t_0, (h_0 + acc_0)]);
  }
}

function $f_ascii_alpha$(c_0) {
  const x_0 = run_loop($Char$to_u32$(c_0));
  const x_1 = ((x_0 | 32) >>> 0);
  const x_2 = ((x_1 - 97) >>> 0);
  return (x_2 <= 25);
}

function $fpe_selected$(legacy_0, owner_0, done_0, sources_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(owner_0)), "ParseOwner")), run_loop($String$eq$(run_loop($nm$(run_loop($kid$(owner_0, 0)))), legacy_0)))), run_clo((x_0) => {
  return run_jump($fpe_source_render$, [legacy_0, run_loop($kid$(owner_0, 0)), run_loop($fpe_unique_source$(run_loop($fpe_owner_path$(run_loop($List$reverse$(done_0)), run_loop($ix$(owner_0)))), sources_0, run_loop($atom$("Absent"))))]);
}), run_clo((x_1) => {
  return legacy_0;
})]);
}

function $fpe_find$(ds_0, index_0) {
  if (ds_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const head_0 = ds_0["head"];
    const tail_0 = ds_0["tail"];
    return run_jump($fpe_find_next$, [run_loop($fpe_def$(head_0)), tail_0, index_0]);
  }
}

function $f_fresh_result_end$(r_0, err_0, imports_0) {
  const book_0 = r_0["defs"];
  const next_0 = r_0["next"];
  return {$: "FResult", ["book"]: book_0, ["error"]: err_0, ["imports"]: imports_0};
}

function $f_graph_fresh_names$(todo_0, done_0) {
  if (todo_0.$ === "Nil") {
    return "";
  } else {
    const d_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($f_graph_fresh_hashed$, [rest_0, done_0, d_0, run_loop($index_hash$(run_loop($dn$(d_0)), 2166136261))]);
  }
}

function $f_error_defs$(ds_0) {
  if (ds_0.$ === "Nil") {
    return "";
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return run_jump($f_error_def_next$, [run_loop($f_error_terms$({$: "Con", ["head"]: run_loop($dt$(d_0)), ["tail"]: {$: "Con", ["head"]: run_loop($dv$(d_0)), ["tail"]: {$: "Nil"}}})), run_loop($dc$(d_0)), rest_0]);
  }
}

function $f_graph_parsed$(s_0, ns_0, sources_0, g_0, stack_0, r_0) {
  const book_0 = r_0["book"];
  const err_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_graph_imports$, [s_0, ns_0, book_0, imports_0, imports_0, sources_0, g_0, stack_0]);
}), run_clo((x_1) => {
  return run_jump($f_graph_error$, [g_0, err_0]);
})]);
}

function $f_graph_error$(g_0, err_0) {
  const book_0 = g_0["book"];
  const old_0 = g_0["error"];
  const done_0 = g_0["done"];
  return {$: "FGraph", ["book"]: book_0, ["error"]: err_0, ["done"]: done_0};
}

function $fs_path$(seed_0) {
  const path_0 = seed_0["path"];
  const book_0 = seed_0["book"];
  return path_0;
}

function $fs_inject$(g_0, seed_0) {
  const book_0 = g_0["book"];
  const err_0 = g_0["error"];
  const done_0 = g_0["done"];
  return {$: "FGraph", ["book"]: run_loop($f_defs_append$(book_0, run_loop($fs_book$(seed_0)))), ["error"]: err_0, ["done"]: {$: "Con", ["head"]: run_loop($kt$("Loaded", run_loop($fs_path$(seed_0)), run_loop($f_graph_count_defs$(run_loop($fs_book$(seed_0)), 0)), 0, {$: "Con", ["head"]: run_loop($ref$("")), ["tail"]: {$: "Nil"}})), ["tail"]: done_0}};
}

function $fs_parsed$(s_0, ns_0, sources_0, g_0, stack_0, r_0, seed_0) {
  const book_0 = r_0["book"];
  const err_0 = r_0["error"];
  const imports_0 = r_0["imports"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($fs_imports$, [s_0, ns_0, book_0, imports_0, imports_0, sources_0, g_0, stack_0, seed_0]);
}), run_clo((x_1) => {
  return run_jump($f_graph_error$, [g_0, err_0]);
})]);
}

function $ffw_frame$(frame_0, value_0, next_0, stack_0) {
  if (frame_0.$ === "FFAllA") {
    const term_0 = frame_0["term"];
    const env_0 = frame_0["env"];
    const id_0 = frame_0["id"];
    return run_jump($ffw_walk$, [run_loop($kid$(term_0, 1)), {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(term_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(term_0)), id_0)), ["tail"]: {$: "Nil"}})), ["tail"]: env_0}, next_0, {$: "Con", ["head"]: {$: "FFAllB", ["term"]: term_0, ["id"]: id_0, ["typ"]: value_0}, ["tail"]: stack_0}]);
  } else if (frame_0.$ === "FFAllB") {
    const term_1 = frame_0["term"];
    const id_1 = frame_0["id"];
    const typ_0 = frame_0["typ"];
    return run_jump($ffw_done$, [run_loop($kt$("All", run_loop($nm$(term_1)), id_1, run_loop($qt$(term_1)), {$: "Con", ["head"]: typ_0, ["tail"]: {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}}})), next_0, stack_0]);
  } else if (frame_0.$ === "FFLambda") {
    const term_2 = frame_0["term"];
    const id_2 = frame_0["id"];
    return run_jump($ffw_done$, [run_loop($kt$("Lam", run_loop($nm$(term_2)), id_2, run_loop($qt$(term_2)), {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})), next_0, stack_0]);
  } else if (frame_0.$ === "FFKids") {
    const term_3 = frame_0["term"];
    const env_1 = frame_0["env"];
    const pending_0 = frame_0["pending"];
    const built_0 = frame_0["built"];
    return run_jump($ffw_kids$, [term_3, env_1, pending_0, {$: "Con", ["head"]: value_0, ["tail"]: built_0}, next_0, stack_0]);
  } else if (frame_0.$ === "FFLetValue") {
    const env_2 = frame_0["env"];
    const bodyenv_0 = frame_0["bodyenv"];
    const id_3 = frame_0["id"];
    const binding_0 = frame_0["binding"];
    const pending_1 = frame_0["pending"];
    const built_1 = frame_0["built"];
    return run_jump($ffw_let$, [env_2, {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(binding_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(binding_0)), id_3)), ["tail"]: {$: "Nil"}})), ["tail"]: bodyenv_0}, pending_1, {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(binding_0)), id_3, run_loop($qt$(binding_0)), {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})), ["tail"]: built_1}, next_0, stack_0]);
  } else {
    const built_2 = frame_0["built"];
    return run_jump($ffw_done$, [run_loop($kt$("Let", "", 0, 1, run_loop($ffw_reverse_onto$(built_2, {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})))), next_0, stack_0]);
  }
}

function $ffw_let_tail$(env_0, bodyenv_0, term_0, tail_0, built_0, next_0, stack_0) {
  if (tail_0.$ === "Nil") {
    return run_jump($ffw_walk$, [term_0, bodyenv_0, next_0, {$: "Con", ["head"]: {$: "FFLetBody", ["built"]: built_0}, ["tail"]: stack_0}]);
  } else {
    const head_0 = tail_0["head"];
    const rest_0 = tail_0["tail"];
    return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), env_0, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFLetValue", ["env"]: env_0, ["bodyenv"]: bodyenv_0, ["id"]: next_0, ["binding"]: term_0, ["pending"]: {$: "Con", ["head"]: head_0, ["tail"]: rest_0}, ["built"]: built_0}, ["tail"]: stack_0}]);
  }
}

function $ffd_frame$(frame_0, ctors_0, next_0, stack_0) {
  const definition_0 = frame_0["definition"];
  const pending_0 = frame_0["pending"];
  const built_0 = frame_0["built"];
  const typ_0 = frame_0["typ"];
  const value_0 = frame_0["value"];
  return run_jump($ffd_walk$, [pending_0, next_0, {$: "Con", ["head"]: {$: "KDef", ["name"]: run_loop($dn$(definition_0)), ["kind"]: run_loop($dk$(definition_0)), ["arity"]: run_loop($da$(definition_0)), ["templates"]: run_loop($dx$(definition_0)), ["typ"]: typ_0, ["value"]: value_0, ["ctors"]: ctors_0, ["native"]: run_loop($db$(definition_0)), ["unsafe"]: run_loop($du$(definition_0))}, ["tail"]: built_0}, stack_0]);
}

function $ffd_value$(definition_0, pending_0, built_0, stack_0, typ_0, result_0) {
  const value_0 = result_0["term"];
  const next_0 = result_0["next"];
  return run_jump($ffd_walk$, [run_loop($dc$(definition_0)), next_0, {$: "Nil"}, {$: "Con", ["head"]: {$: "FFDefFrame", ["definition"]: definition_0, ["pending"]: pending_0, ["built"]: built_0, ["typ"]: typ_0, ["value"]: value_0}, ["tail"]: stack_0}]);
}

function $dg_report$(r_0, name_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($ct$(r_0)))), "DTrace")), run_clo((x_0) => {
  const x_1 = run_loop($qt$(run_loop($ct$(r_0))));
  return {$: "DDiagnostic", ["expected"]: run_loop($dg_as_expr$(run_loop($kid$(run_loop($ct$(r_0)), 0)))), ["observed"]: run_loop($dg_as_expr$(run_loop($kid$(run_loop($ct$(r_0)), 1)))), ["has_observed"]: (x_1 === 1), ["context"]: run_loop($ks$(run_loop($kid$(run_loop($ct$(r_0)), 2)))), ["definition"]: run_loop($nm$(run_loop($ct$(r_0)))), ["span"]: {$: "DNoSpan"}, ["note"]: "", ["trail"]: run_loop($ks$(run_loop($kid$(run_loop($ct$(r_0)), 4))))};
}), run_clo((x_2) => {
  return run_jump($dg_no_report$, [name_0, run_loop($ce$(r_0))]);
})]);
}

function $check_definition_type$(book_0, d_0, e_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_1) => {
  return run_jump($bad$, [run_loop($check_adt_declaration$(e_0, d_0))]);
}), run_clo((x_2) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")), run_clo((x_3) => {
  return r_0;
}), run_clo((x_4) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Foreign")), run_clo((x_5) => {
  return run_jump($bad$, [run_loop($check_foreign$(book_0, d_0))]);
}), run_clo((x_6) => {
  return run_jump($check_template_definition$, [book_0, d_0, run_loop($dt$(d_0)), run_loop($dv$(d_0)), run_loop($ref$(run_loop($dn$(d_0)))), run_loop($dx$(d_0))]);
})]);
})]);
})]);
}), run_clo((x_7) => {
  return r_0;
})]);
}

function $signature_fill_mode$(d_0, fill_0) {
  const x_0 = run_loop($du$(d_0));
  const x_1 = run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($dk$(fill_0)), "Def")), run_loop($Bool$not$(run_loop($String$eq$(run_loop($tg$(run_loop($dv$(fill_0)))), "Absent")))))), run_loop($du$(fill_0))));
  return {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($dt$(d_0)), ["value"]: run_loop($dv$(d_0)), ["ctors"]: run_loop($dc$(d_0)), ["native"]: run_loop($db$(d_0)), ["unsafe"]: (x_0 || x_1)};
}

function $constructor_exists$(ds_0, name_0) {
  if (ds_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    const x_0 = run_loop($Bool$not$(run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(run_loop($dc$(h_0)), name_0)))), "Absent"))));
    const x_1 = run_loop($constructor_exists$(rest_0, name_0));
    return (x_0 || x_1);
  }
}

function $dg_padding$(n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  const x_2 = run_loop($dg_padding$(((n_0 - 1) >>> 0)));
  return (" " + x_2);
})]);
}

function $dg_units$(c_0) {
  const x_0 = run_loop($Char$to_u32$(c_0));
  return run_jump($kc$, [(x_0 > 65535), run_clo((x_1) => {
  return 2;
}), run_clo((x_2) => {
  return 1;
})]);
}

function $dg_snippet_at$(lines_0, at_0) {
  const x_0 = run_loop($dg_lines_count$(lines_0));
  const x_1 = ((at_0 + 1) >>> 0);
  return run_jump($dg_snippet_lines$, [lines_0, at_0, run_loop($kc$((x_0 < x_1), run_clo((x_2) => {
  return run_jump($dg_lines_count$, [lines_0]);
}), run_clo((x_3) => {
  return ((at_0 + 1) >>> 0);
}))), 1]);
}

function $String$lines$(s_0) {
  return run_jump($String$split$, [s_0, "\n"]);
}

function $dg_line_at$(s_0, offset_0, line_0) {
  if (s_0 === "") {
    return line_0;
  } else {
    const c_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const rest_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    const x_0 = run_loop($dg_units$(c_0));
    return run_jump($kc$, [(offset_0 < x_0), run_clo((x_1) => {
    return line_0;
}), run_clo((x_2) => {
    const x_3 = run_loop($dg_units$(c_0));
    return run_jump($dg_line_at$, [rest_0, ((offset_0 - x_3) >>> 0), run_loop($kc$(run_loop($Char$is_eq$(c_0, "\n")), run_clo((x_4) => {
    return ((line_0 + 1) >>> 0);
}), run_clo((x_5) => {
    return line_0;
})))]);
})]);
  }
}

function $dg_span_fields$(s_0, b0_0, e0_0, b_0) {
  if (b_0.$ === "DNoSpan") {
    return false;
  } else {
    const t_0 = b_0["source"];
    const b1_0 = b_0["begin"];
    const e1_0 = b_0["end"];
    return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($String$eq$(s_0, t_0)), (b0_0 === b1_0))), (e0_0 === e1_0)]);
  }
}

function $fp_loaded_module$(book_0, source_0, all_0, definition_0) {
  return run_jump($f_choose$, [run_loop($f_choose$(all_0, run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  return run_jump($fp_loaded_has$, [book_0, definition_0]);
}))), run_clo((x_2) => {
  return run_jump($fp_loaded_defs$, [book_0, {$: "FPSource", ["source"]: run_loop($f_source_text$(source_0)), ["tokens"]: run_loop($f_lex$(run_loop($f_source_text$(source_0)), 1, 0, 0, {$: "Nil"}))}, all_0, definition_0]);
}), run_clo((x_3) => {
  return {$: "Nil"};
})]);
}

function $fp_loaded_take$(book_0, count_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const head_0 = book_0["head"];
    const tail_0 = book_0["tail"];
    return run_jump($f_choose$, [(count_0 === 0), run_clo((x_0) => {
    return {$: "Nil"};
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: head_0, ["tail"]: run_loop($fp_loaded_take$(tail_0, ((count_0 - 1) >>> 0)))};
})]);
  }
}

function $fp_loaded_drop$(book_0, count_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const head_0 = book_0["head"];
    const tail_0 = book_0["tail"];
    return run_jump($f_choose$, [(count_0 === 0), run_clo((x_0) => {
    return {$: "Con", ["head"]: head_0, ["tail"]: tail_0};
}), run_clo((x_1) => {
    return run_jump($fp_loaded_drop$, [tail_0, ((count_0 - 1) >>> 0)]);
})]);
  }
}

function $cp$(e_0) {
  const book_0 = e_0["book"];
  const name_0 = e_0["name"];
  const lhs_0 = e_0["lhs"];
  const pending_0 = e_0["pending"];
  const quantities_0 = e_0["quantities"];
  const unsafe_0 = e_0["unsafe"];
  return pending_0;
}

function $kapply$(fn_0, x_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($strip$(fn_0)))), "Lam")), run_clo((x_1) => {
  return run_jump($subst$, [run_loop($kid$(run_loop($strip$(fn_0)), 0)), run_loop($ix$(run_loop($strip$(fn_0)))), x_0]);
}), run_clo((x_2) => {
  return run_jump($app$, [fn_0, x_0]);
})]);
}

function $tele_fill_head$(book_0, tel_0, h_0, rest_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
  return run_jump($tele_fill$, [book_0, run_loop($subst$(run_loop($kid$(tel_0, 1)), run_loop($ix$(tel_0)), h_0)), rest_0]);
}), run_clo((x_1) => {
  return run_jump($atom$, ["Error"]);
})]);
}

function $mat_lhs$(e_0, name_0, tel_0, n_0) {
  const x_0 = run_loop($cp$(e_0));
  return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
  return e_0;
}), run_clo((x_2) => {
  const x_3 = run_loop($cp$(e_0));
  const x_4 = ((x_3 - 1) >>> 0);
  return {$: "KEnv", ["book"]: run_loop($cb$(e_0)), ["name"]: run_loop($cn$(e_0)), ["lhs"]: run_loop($lhs_ext$(run_loop($cl$(e_0)), name_0, tel_0, n_0, {$: "Nil"})), ["pending"]: ((x_4 + n_0) >>> 0), ["quantities"]: run_loop($cq$(e_0)), ["unsafe"]: run_loop($cu$(e_0))};
})]);
}

function $mat_goal$(book_0, goal_0, tel_0, n_0, name_0, xs_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return run_jump($subst$, [run_loop($kid$(goal_0, 1)), run_loop($ix$(goal_0)), run_loop($kt$("Ctr", name_0, 0, 0, run_loop($norm_join$(xs_0, {$: "Nil"}))))]);
}), run_clo((x_1) => {
  return run_jump($mat_goal_head$, [book_0, goal_0, run_loop($wnf$(book_0, tel_0)), n_0, name_0, xs_0]);
})]);
}

function $all$(q_0, name_0, id_0, a_0, b_0) {
  return run_jump($kt$, ["All", name_0, id_0, q_0, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}

function $core_rebuild$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($core_apply$, [run_loop($kid$(t_0, 0)), run_loop($kid$(t_0, 1))]);
}), run_clo((x_1) => {
  return t_0;
})]);
}

function $subst_terms$(ts_0, id_0, v_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($subst$(h_0, id_0, v_0)), ["tail"]: run_loop($subst_terms$(t_0, id_0, v_0))};
  }
}

function $descend_go$(a_0, p_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(p_0)), "Var")), run_clo((x_0) => {
  const x_1 = run_loop($ix$(a_0));
  const x_2 = run_loop($ix$(p_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Var")), (x_1 === x_2))), run_clo((x_3) => {
  return 1;
}), run_clo((x_4) => {
  return 2;
})]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(p_0)), "Ctr")), run_clo((x_6) => {
  const x_7 = run_loop($terms_len$(run_loop($ks$(a_0))));
  const x_8 = run_loop($terms_len$(run_loop($ks$(p_0))));
  return run_jump($descend_ctr$, [a_0, p_0, run_loop($kc$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Ctr")), run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(p_0)))))), (x_7 === x_8))), run_clo((x_9) => {
  return run_jump($descend_fields$, [run_loop($ks$(a_0)), run_loop($ks$(p_0)), 1]);
}), run_clo((x_10) => {
  return 2;
})))]);
}), run_clo((x_11) => {
  return 2;
})]);
})]);
}

function $strip$(t_0) {
  return run_jump($core_force$, [t_0]);
}

function $template_arg_head$(e_0, ty_0, sp_0, n_0) {
  if (sp_0.$ === "Nil") {
    return run_jump($bad$, ["template requires all closed comptime arguments"]);
  } else {
    const h_0 = sp_0["head"];
    const t_0 = sp_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
    return run_jump($template_arg_done$, [e_0, ty_0, h_0, t_0, n_0, run_loop($check$(e_0, {$: "Nil"}, h_0, 0, run_loop($kid$(ty_0, 0))))]);
}), run_clo((x_1) => {
    return run_jump($bad$, ["invalid template telescope"]);
})]);
  }
}

function $tele_check_after_head$(e_0, ctx_0, tel_0, h_0, rest_0, dem_0, checked_head_0) {
  return run_jump($kc$, [run_loop($core_subst_stable$(run_loop($kid$(tel_0, 1)))), run_clo((x_0) => {
  return run_jump($tele_check_done$, [checked_head_0, run_loop($tele_check_static$(e_0, ctx_0, run_loop($kid$(tel_0, 1)), rest_0, dem_0))]);
}), run_clo((x_1) => {
  return run_jump($tele_check_done$, [checked_head_0, run_loop($tele_check_legacy$(e_0, ctx_0, run_loop($subst$(run_loop($kid$(tel_0, 1)), run_loop($ix$(tel_0)), h_0)), rest_0, dem_0))]);
})]);
}

function $ka_lam$(e_0, ctx_0, t_0, ty_0) {
  const x_0 = run_loop($qt$(t_0));
  const x_1 = run_loop($qt$(ty_0));
  return run_jump($kt$, ["Lam", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($kc$(run_loop($Bool$and$((x_0 === 2), (x_1 === 1))), run_clo((x_2) => {
  return 2;
}), run_clo((x_3) => {
  return run_jump($qt$, [ty_0]);
}))), {$: "Con", ["head"]: run_loop($annotate$(e_0, run_loop($ctx_bind$(ctx_0, run_loop($ix$(t_0)), run_loop($qt$(ty_0)), run_loop($nm$(t_0)), run_loop($kid$(ty_0, 0)))), run_loop($kid$(t_0, 0)), run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), run_loop($var$(run_loop($nm$(t_0)), run_loop($ix$(t_0)))))))), ["tail"]: {$: "Nil"}}]);
}

function $ka_spine_eligible$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($ka_spine_eligible$, [run_loop($kid$(t_0, 0))]);
}), run_clo((x_1) => {
  const x_2 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ref"));
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Var"));
  return (x_2 || x_3);
})]);
}

function $ka_app_spine$(e_0, ctx_0, t_0) {
  return run_jump($ka_app_spine_finish$, [e_0, ctx_0, run_loop($kid$(t_0, 1)), run_loop($ka_spine$(e_0, ctx_0, run_loop($kid$(t_0, 0))))]);
}

function $ka_app$(e_0, ctx_0, t_0, fty_0) {
  return run_jump($app$, [run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 0)), fty_0)), run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 1)), run_loop($kid$(fty_0, 0))))]);
}

function $ka_type$(e_0, ctx_0, t_0) {
  return run_jump($ka_type_node$, [e_0, ctx_0, run_loop($core_beta$(t_0))]);
}

function $ka_args_cached$(e_0, ctx_0, tel_0, xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($ka_args_cached_head$, [e_0, ctx_0, run_loop($wnf$(run_loop($cb$(e_0)), tel_0)), h_0, rest_0]);
  }
}

function $ka_mat$(e_0, ctx_0, t_0, ty_0, a_0) {
  return run_jump($ka_mat_ctr$, [e_0, ctx_0, t_0, ty_0, a_0, run_loop($lookup$(run_loop($dc$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(a_0)))))), run_loop($nm$(t_0))))]);
}

function $ka_let$(e_0, outer_0, ctx_0, xs_0, ty_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(h_0)), "Bind")), run_clo((x_0) => {
    return run_jump($ka_let_head$, [e_0, outer_0, ctx_0, h_0, rest_0, ty_0, run_loop($ka_type$(e_0, outer_0, run_loop($kid$(h_0, 0))))]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, h_0, ty_0)), ["tail"]: {$: "Nil"}};
})]);
  }
}

function $ka_rwt$(e_0, ctx_0, t_0, eq_0) {
  return run_jump($kt$, ["Rwt", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 0)), eq_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 2)), run_loop($kapply$(run_loop($kapply$(run_loop($kid$(t_0, 1)), run_loop($kid$(eq_0, 0)))), run_loop($atom$("Rfl")))))), ["tail"]: {$: "Nil"}}}}]);
}

function $U32$show$fin$(g_0, acc_0, n_0, z_0) {
  if (z_0) {
    return acc_0;
  } else {
    const x_0 = (10 === 0 ? n_0 : n_0 % 10);
    return run_jump($U32$show$go$, [g_0, (10 === 0 ? 0 : (n_0 / 10) >>> 0), (char_new(((48 + x_0) >>> 0)) + acc_0)]);
  }
}

function $kp_float_show$(n_0) {
  const x_0 = run_loop($kp_float$(n_0));
  return run_jump($kp_float_text$, [f32_show(x_0)]);
}

function $kp_ctor_other$(t_0, p_0, env_0) {
  const x_0 = run_loop($kp_eq$(run_loop($nm$(t_0)), "Succ"));
  const x_1 = run_loop($kp_eq$(run_loop($nm$(t_0)), "Zero"));
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($kp_nat$, [t_0, 0n, p_0, env_0]);
}), run_clo((x_3) => {
  return run_jump($kp_ctor_char$, [run_loop($kp_char$(t_0, 39)), t_0, p_0, env_0]);
})]);
}

function $kp_word$(t_0, bit_0, left_0, acc_0) {
  return run_jump($kc$, [(left_0 === 0), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "WNil")), run_clo((x_1) => {
  return {$: "Some", ["value"]: acc_0};
}), run_clo((x_2) => {
  return {$: "None"};
})]);
}), run_clo((x_3) => {
  const x_4 = run_loop($terms_len$(run_loop($ks$(t_0))));
  const x_5 = run_loop($kp_is$(run_loop($kid$(t_0, 0)), "Ctr", "True"));
  const x_6 = run_loop($kp_is$(run_loop($kid$(t_0, 0)), "Ctr", "False"));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($kp_is$(t_0, "Ctr", "WCon")), (x_4 === 2))), (x_5 || x_6))), run_clo((x_7) => {
  return run_jump($kp_word$, [run_loop($kid$(t_0, 1)), ((bit_0 << 1) >>> 0), ((left_0 - 1) >>> 0), run_loop($kc$(run_loop($kp_is$(run_loop($kid$(t_0, 0)), "Ctr", "True")), run_clo((x_8) => {
  return ((acc_0 | bit_0) >>> 0);
}), run_clo((x_9) => {
  return acc_0;
})))]);
}), run_clo((x_10) => {
  return {$: "None"};
})]);
})]);
}

function $kp_rewrite_motive$(e_0, m_0, env_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_eq$(run_loop($tg$(m_0)), "Lam")), run_loop($kp_eq$(run_loop($tg$(run_loop($kid$(m_0, 0)))), "Lam")))), run_clo((x_0) => {
  const x_4 = run_loop($kp_go$(run_loop($kid$(run_loop($kid$(m_0, 0)), 0)), 2, run_loop($kp_bind$(run_loop($kp_bind$(env_0, m_0)), run_loop($kid$(m_0, 0))))));
  const x_5 = run_loop($kp_go$(e_0, 2, env_0));
  const x_6 = (" : " + x_4);
  const x_7 = run_loop($kc$(run_loop($kp_eq$(run_loop($nm$(run_loop($kid$(m_0, 0)))), "")), run_clo((x_1) => {
  return "";
}), run_clo((x_2) => {
  const x_3 = run_loop($nm$(run_loop($kid$(m_0, 0))));
  return (x_3 + "@");
})));
  const x_8 = (x_5 + x_6);
  return (x_7 + x_8);
}), run_clo((x_9) => {
  const x_10 = run_loop($kp_go$(m_0, 2, env_0));
  const x_11 = run_loop($kp_go$(e_0, 2, env_0));
  const x_12 = (" : " + x_10);
  return (x_11 + x_12);
})]);
}

function $kp_let_names$(ts_0) {
  if (ts_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($terms_len$(rest_0));
    return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
    return "";
}), run_clo((x_2) => {
    const x_3 = run_loop($terms_len$(rest_0));
    const x_7 = run_loop($nm$(h_0));
    const x_8 = run_loop($kc$((x_3 === 1), run_clo((x_4) => {
    return "";
}), run_clo((x_5) => {
    const x_6 = run_loop($kp_let_names$(rest_0));
    return (" " + x_6);
})));
    const x_9 = run_loop($kp_quant$(run_loop($qt$(h_0))));
    const x_10 = (x_7 + x_8);
    return (x_9 + x_10);
})]);
  }
}

function $kp_let_vals$(ts_0, env_0) {
  if (ts_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($terms_len$(rest_0));
    return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
    return "";
}), run_clo((x_2) => {
    const x_3 = run_loop($terms_len$(rest_0));
    const x_7 = run_loop($kp_go$(run_loop($kid$(h_0, 0)), 2, env_0));
    const x_8 = run_loop($kc$((x_3 === 1), run_clo((x_4) => {
    return "";
}), run_clo((x_5) => {
    const x_6 = run_loop($kp_let_vals$(rest_0, env_0));
    return (" " + x_6);
})));
    return (x_7 + x_8);
})]);
  }
}

function $kp_let_body$(ts_0, env_0) {
  if (ts_0.$ === "Nil") {
    return "<missing let body>";
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($terms_len$(rest_0));
    return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
    return run_jump($kp_go$, [h_0, 0, env_0]);
}), run_clo((x_2) => {
    return run_jump($kp_let_body$, [rest_0, run_loop($kp_bind$(env_0, h_0))]);
})]);
  }
}

function $sp_memo$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return memo_0;
}

function $sp_serial$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return serial_0;
}

function $sp_fresh$(st_0) {
  const book_0 = st_0["book"];
  const memo_0 = st_0["memo"];
  const serial_0 = st_0["serial"];
  const fresh_0 = st_0["fresh"];
  const error_0 = st_0["error"];
  const templates_0 = st_0["templates"];
  return fresh_0;
}

function $sp_head$(st_0, head_0, xs_0, ctx_0, owner_0, depth_0, d_0) {
  const x_0 = run_loop($dx$(d_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(run_loop($strip$(head_0)))), "Ref")), (x_0 > 0))), run_clo((x_1) => {
  return run_jump($sp_template$, [st_0, d_0, xs_0, ctx_0, owner_0, depth_0]);
}), run_clo((x_2) => {
  return run_jump($sp_regular_head$, [st_0, head_0, xs_0, ctx_0, owner_0, depth_0]);
})]);
}

function $sp_single$(t_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_state$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Nil"}}, ["removed"]: run_loop($rm$(t_0))}};
}

function $sp_match_type$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0, a_0) {
  return run_jump($sp_match_ctor$, [st_0, t_0, ctx_0, goal_0, owner_0, depth_0, a_0, run_loop($lookup$(run_loop($dc$(run_loop($lookup$(run_loop($sp_book$(st_0)), run_loop($nm$(a_0)))))), run_loop($nm$(t_0))))]);
}

function $sp_ctor_done$(t_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_states$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($sp_values$(r_0)), ["removed"]: run_loop($rm$(t_0))}};
}

function $sp_args$(st_0, xs_0, ctx_0, ty_0, owner_0, depth_0) {
  if (xs_0.$ === "Nil") {
    return {$: "KSpecTerms", ["state"]: st_0, ["terms"]: {$: "Nil"}};
  } else {
    const x_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($sp_arg_head$, [st_0, x_0, rest_0, ctx_0, run_loop($wnf$(run_loop($sp_book$(st_0)), ty_0)), owner_0, depth_0]);
  }
}

function $sp_fail$(st_0, err_0) {
  return {$: "KSpecState", ["book"]: run_loop($sp_book$(st_0)), ["memo"]: run_loop($sp_memo$(st_0)), ["serial"]: run_loop($sp_serial$(st_0)), ["fresh"]: run_loop($sp_fresh$(st_0)), ["error"]: run_loop($kc$(run_loop($String$eq$(run_loop($sp_error$(st_0)), "")), run_clo((x_0) => {
  return err_0;
}), run_clo((x_1) => {
  return run_jump($sp_error$, [st_0]);
}))), ["templates"]: run_loop($sp_templates$(st_0))};
}

function $sp_let_binding$(st_0, h_0, rest_0, outer_0, ctx_0, goal_0, owner_0, depth_0, ty_0) {
  const x_0 = run_loop($qt$(h_0));
  return run_jump($sp_let_bound$, [h_0, rest_0, outer_0, ctx_0, goal_0, owner_0, depth_0, ty_0, run_loop($kc$((x_0 === 0), run_clo((x_1) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: run_loop($kid$(h_0, 0))};
}), run_clo((x_2) => {
  return run_jump($sp_term$, [st_0, run_loop($kid$(h_0, 0)), outer_0, ty_0, owner_0, depth_0]);
})))]);
}

function $sp_type$(st_0, t_0, ctx_0, owner_0) {
  return run_jump($cy$, [run_loop($infer$({$: "KEnv", ["book"]: run_loop($sp_book$(st_0)), ["name"]: owner_0, ["lhs"]: run_loop($ref$(owner_0)), ["pending"]: 0, ["quantities"]: {$: "Nil"}, ["unsafe"]: true}, ctx_0, t_0, 0, {$: "Nil"}))]);
}

function $sp_let_body$(r_0) {
  return {$: "KSpecTerms", ["state"]: run_loop($sp_state$(r_0)), ["terms"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Nil"}}};
}

function $sp_rewrite_type$(st_0, t_0, ctx_0, owner_0, depth_0, eq_0) {
  return run_jump($sp_rewrite_done$, [t_0, run_loop($sp_term$(st_0, run_loop($kid$(t_0, 2)), ctx_0, run_loop($app$(run_loop($app$(run_loop($kid$(t_0, 1)), run_loop($kid$(eq_0, 0)))), run_loop($atom$("Rfl")))), owner_0, depth_0))]);
}

function $book_final_seen$(seen_0, name_0, hash_0) {
  return run_jump($String$eq$, [run_loop($dk$(run_loop($index_find$(seen_0, name_0, hash_0, 32)))), "$final.seen"]);
}

function $g_term$(r_0) {
  const state_0 = r_0["state"];
  const term_0 = r_0["term"];
  return term_0;
}

function $g_snf_open$(book_0, st_0, t_0, stack_0, fresh_0) {
  return run_jump($g_snf_children$, [book_0, st_0, t_0, {$: "Nil"}, run_loop($ks$(t_0)), stack_0, fresh_0]);
}

function $g_state$(r_0) {
  const state_0 = r_0["state"];
  const term_0 = r_0["term"];
  return state_0;
}

function $norm_rebind$(t_0, fresh_0) {
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: fresh_0, ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($kc$(run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_0) => {
  return {$: "Con", ["head"]: run_loop($subst$(run_loop($kid$(t_0, 0)), run_loop($ix$(t_0)), run_loop($var$(run_loop($nm$(t_0)), fresh_0)))), ["tail"]: {$: "Nil"}};
}), run_clo((x_1) => {
  return {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($subst$(run_loop($kid$(t_0, 1)), run_loop($ix$(t_0)), run_loop($var$(run_loop($nm$(t_0)), fresh_0)))), ["tail"]: {$: "Nil"}}};
}))), ["removed"]: run_loop($rm$(t_0))};
}

function $g_eval$(book_0, st_0, t_0, args_0, pending_0, fallback_0, stack_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "GCell")), run_clo((x_0) => {
  return run_jump($g_cell$, [book_0, st_0, t_0, args_0, pending_0, fallback_0, stack_0, run_loop($g_get$(run_loop($g_heap$(st_0)), run_loop($ix$(t_0))))]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_2) => {
  return run_jump($g_app$, [book_0, run_loop($kid$(t_0, 0)), args_0, pending_0, fallback_0, stack_0, run_loop($g_share$(st_0, run_loop($kid$(t_0, 1))))]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_4) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(t_0, 0)), args_0, pending_0, fallback_0, stack_0]);
}), run_clo((x_5) => {
  const x_6 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), (x_6 > 0))), run_clo((x_7) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(t_0, 0)), args_0, pending_0, fallback_0, stack_0]);
}), run_clo((x_8) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Let")), run_clo((x_9) => {
  return run_jump($g_let$, [book_0, st_0, run_loop($ks$(t_0)), {$: "Nil"}, args_0, pending_0, fallback_0, stack_0]);
}), run_clo((x_10) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_11) => {
  return run_jump($g_ref$, [book_0, st_0, t_0, args_0, stack_0, run_loop($lookup$(book_0, run_loop($nm$(t_0))))]);
}), run_clo((x_12) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Min")), run_clo((x_13) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(t_0, 0)), {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Con", ["head"]: {$: "GMinA", ["other"]: run_loop($kid$(t_0, 1)), ["args"]: args_0}, ["tail"]: stack_0}]);
}), run_clo((x_14) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rwt")), run_clo((x_15) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(t_0, 0)), {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Con", ["head"]: {$: "GRewrite", ["original"]: t_0, ["args"]: args_0, ["pending"]: pending_0, ["fallback"]: fallback_0}, ["tail"]: stack_0}]);
}), run_clo((x_16) => {
  return run_jump($g_args$, [book_0, st_0, t_0, args_0, pending_0, fallback_0, stack_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $norm_min_right$(a_0, b_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(b_0)), "Qua")), run_clo((x_0) => {
  const x_1 = run_loop($qt$(b_0));
  return run_jump($kc$, [(x_1 === 2), run_clo((x_2) => {
  return a_0;
}), run_clo((x_3) => {
  const x_4 = run_loop($qt$(b_0));
  return run_jump($kc$, [run_loop($Bool$and$((x_4 === 1), run_loop($Bool$not$(run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")))))), run_clo((x_5) => {
  return run_jump($kt$, ["Min", "", 0, 0, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_6) => {
  return b_0;
})]);
})]);
}), run_clo((x_7) => {
  return run_jump($kt$, ["Min", "", 0, 0, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
})]);
}

function $norm_stuck$(t_0, x_0, args_0, left_0, fallback_0) {
  return run_jump($kc$, [(left_0 === 0), run_clo((x_1) => {
  return run_jump($norm_apply$, [run_loop($app$(t_0, x_0)), args_0]);
}), run_clo((x_2) => {
  return fallback_0;
})]);
}

function $norm_exact_names$(as_0, bs_0) {
  if (as_0.$ === "Nil") {
    if (bs_0.$ === "Nil") {
      return true;
    } else {
      return false;
    }
  } else {
    const a_0 = as_0["head"];
    const ar_0 = as_0["tail"];
    if (bs_0.$ === "Con") {
      const b_0 = bs_0["head"];
      const br_0 = bs_0["tail"];
      return run_jump($kc$, [run_loop($String$eq$(a_0, b_0)), run_clo((x_0) => {
      return run_jump($norm_exact_names$, [ar_0, br_0]);
}), run_clo((x_1) => {
      return false;
})]);
    } else {
      return false;
    }
  }
}

function $norm_cmp_test$(book_0, yes_0, rest_0, alts_0) {
  return run_jump($kc$, [yes_0, run_clo((x_0) => {
  return run_jump($norm_cmp_loop$, [book_0, rest_0, alts_0]);
}), run_clo((x_1) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
}

function $norm_cmp_kind$(book_0, a_0, b_0, g_0, h_0, fresh_0, rest_0, alts_0) {
  const x_0 = run_loop($qt$(g_0));
  const x_1 = run_loop($qt$(h_0));
  const x_2 = run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(g_0)), "Qua")), (x_0 === 2)));
  const x_3 = run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(h_0)), "Qua")), run_loop($Bool$not$((x_1 === 2)))));
  return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($norm_cmp_loop$, [book_0, rest_0, alts_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(g_0)), "Min")), run_clo((x_6) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($kid$(g_0, 0)), ["tail"]: {$: "Nil"}})), ["b"]: b_0, ["le"]: true, ["fresh"]: fresh_0}, ["tail"]: {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($kid$(g_0, 1)), ["tail"]: {$: "Nil"}})), ["b"]: b_0, ["le"]: true, ["fresh"]: fresh_0}, ["tail"]: rest_0}}, alts_0]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(h_0)), "Min")), run_clo((x_8) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: a_0, ["b"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($kid$(h_0, 0)), ["tail"]: {$: "Nil"}})), ["le"]: true, ["fresh"]: fresh_0}, ["tail"]: rest_0}, {$: "Con", ["head"]: {$: "KNormAlt", ["todo"]: {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: a_0, ["b"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($kid$(h_0, 1)), ["tail"]: {$: "Nil"}})), ["le"]: true, ["fresh"]: fresh_0}, ["tail"]: rest_0}}, ["tail"]: alts_0}]);
}), run_clo((x_9) => {
  return run_jump($norm_cmp_loop$, [book_0, {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: g_0, ["b"]: h_0, ["le"]: true, ["fresh"]: fresh_0}, ["tail"]: rest_0}, alts_0]);
})]);
})]);
})]);
}

function $norm_removed$(as_0, bs_0, le_0) {
  return run_jump($kc$, [le_0, run_clo((x_0) => {
  return run_jump($norm_subset$, [as_0, bs_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($norm_names_len$(as_0));
  const x_3 = run_loop($norm_names_len$(bs_0));
  return run_jump($Bool$and$, [(x_2 === x_3), run_loop($norm_subset$(as_0, bs_0))]);
})]);
}

function $norm_cmp_fields$(book_0, as_0, bs_0, fresh_0, rest_0, alts_0) {
  const x_0 = run_loop($terms_len$(as_0));
  const x_1 = run_loop($terms_len$(bs_0));
  return run_jump($kc$, [(x_0 === x_1), run_clo((x_2) => {
  return run_jump($norm_cmp_loop$, [book_0, run_loop($norm_cmp_zip$(as_0, bs_0, fresh_0, rest_0)), alts_0]);
}), run_clo((x_3) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
}

function $norm_cmp_plain$(book_0, a_0, b_0, fresh_0, rest_0, alts_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(a_0)), "Ref"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(a_0)), "Hol"));
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($norm_cmp_test$, [book_0, run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(b_0)))), rest_0, alts_0]);
}), run_clo((x_3) => {
  const x_4 = run_loop($String$eq$(run_loop($tg$(a_0)), "Ctr"));
  const x_5 = run_loop($String$eq$(run_loop($tg$(a_0)), "Mat"));
  return run_jump($kc$, [(x_4 || x_5), run_clo((x_6) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($nm$(a_0)), run_loop($nm$(b_0)))), run_clo((x_7) => {
  return run_jump($norm_cmp_fields$, [book_0, run_loop($ks$(a_0)), run_loop($ks$(b_0)), fresh_0, rest_0, alts_0]);
}), run_clo((x_8) => {
  return run_jump($norm_cmp_fail$, [book_0, alts_0]);
})]);
}), run_clo((x_9) => {
  const x_10 = run_loop($String$eq$(run_loop($tg$(a_0)), "App"));
  const x_11 = run_loop($String$eq$(run_loop($tg$(a_0)), "Min"));
  const x_12 = (x_10 || x_11);
  const x_13 = run_loop($String$eq$(run_loop($tg$(a_0)), "Eql"));
  const x_14 = (x_12 || x_13);
  const x_15 = run_loop($String$eq$(run_loop($tg$(a_0)), "Rwt"));
  return run_jump($kc$, [(x_14 || x_15), run_clo((x_16) => {
  return run_jump($norm_cmp_fields$, [book_0, run_loop($ks$(a_0)), run_loop($ks$(b_0)), fresh_0, rest_0, alts_0]);
}), run_clo((x_17) => {
  const x_18 = run_loop($String$eq$(run_loop($tg$(a_0)), "Qnt"));
  const x_19 = run_loop($String$eq$(run_loop($tg$(a_0)), "Rfl"));
  const x_20 = (x_18 || x_19);
  const x_21 = run_loop($String$eq$(run_loop($tg$(a_0)), "Efq"));
  return run_jump($norm_cmp_test$, [book_0, (x_20 || x_21), rest_0, alts_0]);
})]);
})]);
})]);
}

function $exact_terms_head$(h_0, rest_0, b_0) {
  if (b_0.$ === "Nil") {
    return false;
  } else {
    const x_0 = b_0["head"];
    const xs_0 = b_0["tail"];
    return run_jump($Bool$and$, [run_loop($exact_term$(h_0, x_0)), run_loop($exact_terms$(rest_0, xs_0))]);
  }
}

function $exact_names_empty$(b_0) {
  if (b_0.$ === "Nil") {
    return true;
  } else {
    const h_0 = b_0["head"];
    const rest_0 = b_0["tail"];
    return false;
  }
}

function $exact_names_head$(h_0, rest_0, b_0) {
  if (b_0.$ === "Nil") {
    return false;
  } else {
    const x_0 = b_0["head"];
    const xs_0 = b_0["tail"];
    return run_jump($Bool$and$, [run_loop($String$eq$(h_0, x_0)), run_loop($exact_names$(rest_0, xs_0))]);
  }
}

function $kr_refs_list$(terms_0, todo_0) {
  if (terms_0.$ === "Nil") {
    return todo_0;
  } else {
    const h_0 = terms_0["head"];
    const rest_0 = terms_0["tail"];
    return run_jump($kr_refs$, [h_0, run_loop($kr_refs_list$(rest_0, todo_0))]);
  }
}

function $kr_push$(name_0, names_0) {
  return run_jump($kc$, [run_loop($has_name$(names_0, name_0)), run_clo((x_0) => {
  return names_0;
}), run_clo((x_1) => {
  return {$: "Con", ["head"]: name_0, ["tail"]: names_0};
})]);
}

function $fpe_message$(source_0, error_0, observed_0) {
  const x_0 = run_loop($fpe_snippet$(run_loop($String$lines$(source_0)), run_loop($ix$(error_0))));
  const x_1 = ("\nLocation:" + x_0);
  const x_2 = (observed_0 + x_1);
  const x_3 = run_loop($nm$(run_loop($kid$(error_0, 0))));
  const x_4 = ("\n- observed : " + x_2);
  const x_5 = (x_3 + x_4);
  return ("Error:\n- expected : " + x_5);
}

function $f_import$(ts_0, book_0, imports_0) {
  return run_jump($f_import_path$, [ts_0, "", book_0, imports_0]);
}

function $f_valid_name$(s_0) {
  const x_0 = run_loop($Char$is_alpha$(run_loop($f_head$(s_0))));
  const x_1 = run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "_"));
  return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$and$((x_0 || x_1), run_loop($f_name_chars$(s_0)))), run_loop($Bool$not$(run_loop($f_reserved$(s_0)))))), run_loop($Bool$not$(run_loop($String$ends_with$(s_0, "."))))]);
}

function $f_find$(name_0, book_0) {
  if (book_0.$ === "Nil") {
    return {$: "KDef", ["name"]: name_0, ["kind"]: "Missing", ["arity"]: 0, ["templates"]: 0, ["typ"]: run_loop($atom$("Absent")), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: false};
  } else {
    const d_0 = book_0["head"];
    const ds_0 = book_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(name_0, run_loop($f_dn$(d_0)))), run_clo((x_0) => {
    return d_0;
}), run_clo((x_1) => {
    return run_jump($f_find$, [name_0, ds_0]);
})]);
  }
}

function $f_law_base$(name_0, ts_0, book_0, imports_0, clauses_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "for"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "exs"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_law_clause$, [name_0, run_loop($f_eq$(run_loop($f_tx$(ts_0)), "exs")), run_loop($f_tl$(ts_0)), book_0, imports_0, clauses_0]);
}), run_clo((x_3) => {
  return run_jump($f_law_end$, [name_0, run_loop($f_expr$(ts_0, 0)), book_0, imports_0, run_loop($List$reverse$(clauses_0))]);
})]);
}

function $f_def_prior$(name_0, p_0, book_0, imports_0, unsafe_0, old_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($dk$(old_0)), "Missing")), run_clo((x_0) => {
  return run_jump($f_def_base$, [name_0, p_0, book_0, imports_0, unsafe_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($f_len$(run_loop($ks$(run_loop($f_pn$(p_0))))));
  const x_3 = run_loop($dx$(old_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($dk$(old_0)), "Def")), run_loop($f_eq$(run_loop($tg$(run_loop($dv$(old_0)))), "Absent")))), run_loop($f_bare_params$(run_loop($ks$(run_loop($f_pn$(p_0)))))))), (x_2 >= x_3))), run_clo((x_4) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(run_loop($f_pr$(p_0)))), ":")), run_clo((x_5) => {
  return run_jump($f_def_base$, [name_0, p_0, book_0, imports_0, unsafe_0]);
}), run_clo((x_6) => {
  return run_jump($f_result$, [book_0, run_loop($f_pn$(run_loop($f_err$(run_loop($f_pr$(p_0)), "expected : (a definition filling a law has no return annotation)")))), imports_0]);
})]);
}), run_clo((x_7) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", "a definition must uniquely fill its law with plain parameter names", 0, 0, {$: "Nil"})), imports_0]);
})]);
})]);
}

function $f_tele_at$(ts_0, end_0, acc_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), end_0)), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Tele", "", 0, 0, run_loop($List$reverse$(acc_0)))), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_1) => {
  return run_jump($f_validate_param$, [ts_0, end_0, acc_0]);
})]);
}

function $f_type_named$(name_0, ts_0, book_0, imports_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<>")), run_clo((x_0) => {
  return run_jump($f_type_params$, [name_0, {$: "FParsed", ["term"]: run_loop($kt$("Tele", "", 0, 0, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))}, book_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_type_base$, [name_0, ts_0, book_0, imports_0]);
})]);
}

function $fpe_legacy$(ts_0, legacy_0, expected_0) {
  return {$: "FParsed", ["term"]: run_loop($kt$("Error", legacy_0, run_loop($f_line$(ts_0)), run_loop($f_col$(ts_0)), {$: "Con", ["head"]: run_loop($kt$("ParseExpected", expected_0, 0, 0, {$: "Nil"})), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("ParseToken", run_loop($f_tx$(ts_0)), 0, 0, {$: "Nil"})), ["tail"]: {$: "Nil"}}})), ["rest"]: {$: "Nil"}};
}

function $fpe_source_render$(legacy_0, error_0, source_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(source_0)), "ParseSource")), run_clo((x_0) => {
  return run_jump($fpe_render$, [run_loop($nm$(source_0)), error_0]);
}), run_clo((x_1) => {
  return legacy_0;
})]);
}

function $fpe_unique_source$(path_0, sources_0, found_0) {
  if (sources_0.$ === "Nil") {
    return found_0;
  } else {
    const head_0 = sources_0["head"];
    const tail_0 = sources_0["tail"];
    return run_jump($f_choose$, [run_loop($String$eq$(path_0, run_loop($f_source_path$(head_0)))), run_clo((x_0) => {
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(found_0)), "Absent")), run_clo((x_1) => {
    return run_jump($fpe_unique_source$, [path_0, tail_0, run_loop($kt$("ParseSource", run_loop($f_source_text$(head_0)), 0, 0, {$: "Nil"}))]);
}), run_clo((x_2) => {
    return run_jump($atom$, ["Ambiguous"]);
})]);
}), run_clo((x_3) => {
    return run_jump($fpe_unique_source$, [path_0, tail_0, found_0]);
})]);
  }
}

function $fpe_owner_path$(done_0, index_0) {
  if (done_0.$ === "Nil") {
    return "";
  } else {
    const head_0 = done_0["head"];
    const tail_0 = done_0["tail"];
    const x_0 = run_loop($ix$(head_0));
    return run_jump($f_choose$, [(index_0 < x_0), run_clo((x_1) => {
    return run_jump($nm$, [head_0]);
}), run_clo((x_2) => {
    const x_3 = run_loop($ix$(head_0));
    return run_jump($fpe_owner_path$, [tail_0, ((index_0 - x_3) >>> 0)]);
})]);
  }
}

function $fpe_find_next$(error_0, rest_0, index_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(error_0)), "Absent")), run_clo((x_0) => {
  return run_jump($fpe_find$, [rest_0, ((index_0 + 1) >>> 0)]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["ParseOwner", "", index_0, 0, {$: "Con", ["head"]: error_0, ["tail"]: {$: "Nil"}}]);
})]);
}

function $fpe_def$(d_0) {
  return run_jump($fpe_defs_next$, [run_loop($fpe_terms$({$: "Con", ["head"]: run_loop($dt$(d_0)), ["tail"]: {$: "Con", ["head"]: run_loop($dv$(d_0)), ["tail"]: {$: "Nil"}}})), run_loop($dc$(d_0))]);
}

function $f_graph_fresh_hashed$(rest_0, done_0, d_0, hash_0) {
  return run_jump($f_graph_fresh_name$, [rest_0, done_0, d_0, hash_0, run_loop($index_find$(done_0, run_loop($dn$(d_0)), hash_0, 32))]);
}

function $f_error_def_next$(err_0, ctors_0, rest_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_error_defs_more$, [run_loop($f_error_defs$(ctors_0)), rest_0]);
}), run_clo((x_1) => {
  return err_0;
})]);
}

function $f_error_terms$(ts_0) {
  if (ts_0.$ === "Nil") {
    return "";
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($f_error_more$, [run_loop($f_error_term$(t_0)), rest_0]);
  }
}

function $f_graph_imports$(s_0, ns_0, book_0, allimports_0, imports_0, sources_0, g_0, stack_0) {
  if (imports_0.$ === "Nil") {
    return run_jump($f_graph_finish$, [s_0, ns_0, book_0, run_loop($f_graph_aliases$(allimports_0, ns_0)), g_0]);
  } else {
    const im_0 = imports_0["head"];
    const rest_0 = imports_0["tail"];
    return run_jump($f_graph_imports$, [s_0, ns_0, book_0, allimports_0, rest_0, sources_0, run_loop($f_graph_load$(run_loop($f_import_pathname$(im_0, s_0, sources_0)), run_loop($f_import_namespace$(im_0, ns_0)), sources_0, g_0, stack_0)), stack_0]);
  }
}

function $f_defs_append$(xs_0, ys_0) {
  if (xs_0.$ === "Nil") {
    return ys_0;
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return {$: "Con", ["head"]: x_0, ["tail"]: run_loop($f_defs_append$(xt_0, ys_0))};
  }
}

function $fs_book$(seed_0) {
  const path_0 = seed_0["path"];
  const book_0 = seed_0["book"];
  return book_0;
}

function $f_graph_count_defs$(book_0, count_0) {
  if (book_0.$ === "Nil") {
    return count_0;
  } else {
    const head_0 = book_0["head"];
    const tail_0 = book_0["tail"];
    return run_jump($f_graph_count_defs$, [tail_0, ((count_0 + 1) >>> 0)]);
  }
}

function $fs_imports$(s_0, ns_0, book_0, allimports_0, imports_0, sources_0, g_0, stack_0, seed_0) {
  if (imports_0.$ === "Nil") {
    return run_jump($f_graph_finish$, [s_0, ns_0, book_0, run_loop($f_graph_aliases$(allimports_0, ns_0)), g_0]);
  } else {
    const im_0 = imports_0["head"];
    const rest_0 = imports_0["tail"];
    return run_jump($fs_imports$, [s_0, ns_0, book_0, allimports_0, rest_0, sources_0, run_loop($fs_load$(run_loop($f_import_pathname$(im_0, s_0, sources_0)), run_loop($f_import_namespace$(im_0, ns_0)), sources_0, g_0, stack_0, seed_0)), stack_0, seed_0]);
  }
}

function $ffw_reverse_onto$(items_0, onto_0) {
  if (items_0.$ === "Nil") {
    return onto_0;
  } else {
    const head_0 = items_0["head"];
    const tail_0 = items_0["tail"];
    return run_jump($ffw_reverse_onto$, [tail_0, {$: "Con", ["head"]: head_0, ["tail"]: onto_0}]);
  }
}

function $dg_as_expr$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "DText")), run_clo((x_0) => {
  return {$: "DText", ["text"]: run_loop($nm$(t_0))};
}), run_clo((x_1) => {
  return {$: "DTerm", ["term"]: t_0};
})]);
}

function $check_adt_declaration$(e_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($tele_tip$(run_loop($cb$(e_0)), run_loop($dt$(d_0)))))), "Typ")), run_clo((x_0) => {
  return run_jump($check_ctors$, [e_0, d_0, run_loop($dc$(d_0)), run_loop($dt$(d_0))]);
}), run_clo((x_1) => {
  return "datatype declaration must return a kind";
})]);
}

function $check_foreign$(book_0, d_0) {
  const x_0 = run_loop($dx$(d_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$((x_0 === 0), run_loop($String$eq$(run_loop($tg$(run_loop($foreign_head$(run_loop($foreign_tip$(run_loop($dt$(d_0)))))))), "Ref")))), run_loop($String$eq$(run_loop($nm$(run_loop($foreign_head$(run_loop($foreign_tip$(run_loop($dt$(d_0)))))))), "IO")))), run_loop($String$eq$(run_loop($dk$(run_loop($lookup$(book_0, "IO")))), "Def")))), run_loop($db$(run_loop($lookup$(book_0, "IO")))))), run_clo((x_1) => {
  return "";
}), run_clo((x_2) => {
  return "foreign definition must return base IO directly";
})]);
}

function $check_template_definition$(book_0, d_0, ty_0, body_0, lhs_0, n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return run_jump($check$, [{$: "KEnv", ["book"]: book_0, ["name"]: run_loop($dn$(d_0)), ["lhs"]: lhs_0, ["pending"]: run_loop($self_pending$(d_0, body_0)), ["quantities"]: run_loop($tele_quantities$(book_0, run_loop($dt$(d_0)), run_loop($da$(d_0)))), ["unsafe"]: run_loop($du$(d_0))}, {$: "Nil"}, body_0, 1, ty_0]);
}), run_clo((x_1) => {
  return run_jump($check_template_binder$, [book_0, d_0, run_loop($wnf$(book_0, ty_0)), body_0, lhs_0, n_0]);
})]);
}

function $dg_snippet_lines$(lines_0, at_0, end_0, line_0) {
  if (lines_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = lines_0["head"];
    const rest_0 = lines_0["tail"];
    return run_jump($kc$, [(line_0 > end_0), run_clo((x_0) => {
    return "";
}), run_clo((x_1) => {
    const x_2 = ((line_0 + 1) >>> 0);
    const x_11 = run_loop($kc$((x_2 < at_0), run_clo((x_3) => {
    return "";
}), run_clo((x_4) => {
    const x_7 = run_loop($kc$((line_0 === at_0), run_clo((x_5) => {
    return ">| ";
}), run_clo((x_6) => {
    return " | ";
})));
    const x_8 = run_loop($dg_lpad$(run_loop($U32$show$(line_0)), run_loop($dg_width$(run_loop($U32$show$(end_0))))));
    const x_9 = (x_7 + h_0);
    const x_10 = (x_8 + x_9);
    return ("\n" + x_10);
})));
    const x_12 = run_loop($dg_snippet_lines$(rest_0, at_0, end_0, ((line_0 + 1) >>> 0)));
    return (x_11 + x_12);
})]);
  }
}

function $dg_lines_count$(lines_0) {
  if (lines_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = lines_0["head"];
    const rest_0 = lines_0["tail"];
    const x_0 = run_loop($dg_lines_count$(rest_0));
    return ((1 + x_0) >>> 0);
  }
}

function $String$split$(s_0, sep_0) {
  if (s_0 === "") {
    return {$: "Con", ["head"]: "", ["tail"]: {$: "Nil"}};
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return run_jump($String$split$fin$, [h_0, run_loop($String$split$(t_0, sep_0)), run_loop($Char$is_eq$(h_0, sep_0))]);
  }
}

function $fp_loaded_has$(book_0, definition_0) {
  if (book_0.$ === "Nil") {
    return false;
  } else {
    const head_0 = book_0["head"];
    const tail_0 = book_0["tail"];
    return run_jump($f_choose$, [run_loop($String$eq$(run_loop($dn$(head_0)), definition_0)), run_clo((x_0) => {
    return true;
}), run_clo((x_1) => {
    return run_jump($fp_loaded_has$, [tail_0, definition_0]);
})]);
  }
}

function $fp_loaded_defs$(book_0, source_0, all_0, definition_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const head_0 = book_0["head"];
    const tail_0 = book_0["tail"];
    const x_0 = run_loop($String$eq$(run_loop($dn$(head_0)), definition_0));
    return run_jump($List$append$, [run_loop($f_choose$((all_0 || x_0), run_clo((x_1) => {
    return run_jump($fp_def$, [head_0, source_0]);
}), run_clo((x_2) => {
    return {$: "Nil"};
}))), run_loop($fp_loaded_defs$(tail_0, source_0, all_0, definition_0))]);
  }
}

function $lhs_ext$(lhs_0, name_0, tel_0, n_0, xs_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return run_jump($kapply$, [lhs_0, run_loop($kt$("Ctr", name_0, 0, 0, xs_0))]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Lam", run_loop($nm$(tel_0)), run_loop($ix$(tel_0)), run_loop($qt$(tel_0)), {$: "Con", ["head"]: run_loop($lhs_ext$(lhs_0, name_0, run_loop($kid$(tel_0, 1)), ((n_0 - 1) >>> 0), run_loop($norm_join$(xs_0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(tel_0)), run_loop($ix$(tel_0)))), ["tail"]: {$: "Nil"}})))), ["tail"]: {$: "Nil"}}]);
})]);
}

function $mat_goal_head$(book_0, goal_0, tel_0, n_0, name_0, xs_0) {
  const x_0 = run_loop($qt$(tel_0));
  return run_jump($all$, [run_loop($kc$((x_0 === 0), run_clo((x_1) => {
  return 0;
}), run_clo((x_2) => {
  const x_3 = run_loop($qt$(tel_0));
  return run_jump($kc$, [(x_3 === 1), run_clo((x_4) => {
  return run_jump($qt$, [goal_0]);
}), run_clo((x_5) => {
  return run_jump($qadd$, [run_loop($qt$(goal_0)), run_loop($qt$(goal_0))]);
})]);
}))), run_loop($nm$(tel_0)), run_loop($ix$(tel_0)), run_loop($kid$(tel_0, 0)), run_loop($mat_goal$(book_0, goal_0, run_loop($kid$(tel_0, 1)), ((n_0 - 1) >>> 0), name_0, run_loop($norm_join$(xs_0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(tel_0)), run_loop($ix$(tel_0)))), ["tail"]: {$: "Nil"}}))))]);
}

function $descend_ctr$(a_0, p_0, ord_0) {
  return run_jump($kc$, [(ord_0 === 2), run_clo((x_0) => {
  return run_jump($descend_sub$, [a_0, run_loop($ks$(p_0))]);
}), run_clo((x_1) => {
  return ord_0;
})]);
}

function $descend_fields$(a_0, p_0, ord_0) {
  if (a_0.$ === "Nil") {
    return ord_0;
  } else {
    const h_0 = a_0["head"];
    const t_0 = a_0["tail"];
    return run_jump($kc$, [(ord_0 === 2), run_clo((x_0) => {
    return 2;
}), run_clo((x_1) => {
    const x_2 = run_loop($descend$(1, h_0, run_loop($terms_at$(p_0, 0))));
    return run_jump($descend_fields$, [t_0, run_loop($terms_tail$(p_0)), run_loop($kc$((x_2 === 1), run_clo((x_3) => {
    return ord_0;
}), run_clo((x_4) => {
    return run_jump($descend$, [1, h_0, run_loop($terms_at$(p_0, 0))]);
})))]);
})]);
  }
}

function $core_force$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_0) => {
  return run_jump($core_force$, [run_loop($kid$(t_0, 0))]);
}), run_clo((x_1) => {
  const x_2 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), (x_2 > 0))), run_clo((x_3) => {
  return run_jump($core_force$, [run_loop($kid$(t_0, 0))]);
}), run_clo((x_4) => {
  return t_0;
})]);
})]);
}

function $template_arg_done$(e_0, ty_0, h_0, rest_0, n_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($template_args$, [e_0, run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), h_0)), rest_0, ((n_0 - 1) >>> 0)]);
}), run_clo((x_1) => {
  return run_jump($bad$, ["template argument is open or ill-typed"]);
})]);
}

function $core_subst_stable$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return run_jump($kc$, [run_loop($String$eq$(tag_0, "Var")), run_clo((x_0) => {
  return false;
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($core_subst_stable_terms$(kids_0)), run_clo((x_2) => {
  return run_jump($kc$, [run_loop($String$eq$(tag_0, "App")), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$eq$(name_0, "")), (id_0 === 0))), (quant_0 === 0))), run_clo((x_4) => {
  return run_jump($core_subst_stable_app$, [kids_0, removed_0]);
}), run_clo((x_5) => {
  return false;
})]);
}), run_clo((x_6) => {
  return true;
})]);
}), run_clo((x_7) => {
  return false;
})]);
})]);
}

function $tele_check_done$(a_0, b_0) {
  return run_jump($both$, [a_0, b_0, run_loop($ct$(b_0)), run_loop($cy$(b_0)), false]);
}

function $tele_check_static$(e_0, ctx_0, tel_0, args_0, dem_0) {
  if (args_0.$ === "Nil") {
    return run_jump($ok$, [run_loop($atom$("Args")), tel_0, {$: "Nil"}]);
  } else {
    const h_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
    return run_jump($tele_check_done$, [run_loop($check$(e_0, ctx_0, h_0, run_loop($qdem$(run_loop($qt$(tel_0)), dem_0)), run_loop($kid$(tel_0, 0)))), run_loop($tele_check_static$(e_0, ctx_0, run_loop($kid$(tel_0, 1)), rest_0, dem_0))]);
}), run_clo((x_1) => {
    return run_jump($tele_check$, [e_0, ctx_0, tel_0, {$: "Con", ["head"]: h_0, ["tail"]: rest_0}, dem_0]);
})]);
  }
}

function $tele_check_legacy$(e_0, ctx_0, tel_0, args_0, dem_0) {
  if (args_0.$ === "Nil") {
    return run_jump($ok$, [run_loop($atom$("Args")), tel_0, {$: "Nil"}]);
  } else {
    const h_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($tele_check_legacy_head$, [e_0, ctx_0, run_loop($wnf$(run_loop($cb$(e_0)), tel_0)), h_0, rest_0, dem_0]);
  }
}

function $ka_app_spine_finish$(e_0, ctx_0, arg_0, r_0) {
  const node_0 = r_0["node"];
  const ty_0 = r_0["typ"];
  return run_jump($ka_app_spine_root$, [e_0, ctx_0, arg_0, node_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}

function $ka_spine$(e_0, ctx_0, t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($ka_spine_finish$, [e_0, ctx_0, run_loop($kid$(t_0, 1)), run_loop($ka_spine$(e_0, ctx_0, run_loop($kid$(t_0, 0))))]);
}), run_clo((x_1) => {
  return {$: "KAnnotatedSpine", ["node"]: t_0, ["typ"]: run_loop($ka_type$(e_0, ctx_0, t_0))};
})]);
}

function $ka_type_node$(e_0, ctx_0, t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Var")), run_clo((x_0) => {
  return run_jump($kid$, [run_loop($ctx_get$(ctx_0, run_loop($ix$(t_0)))), 0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_2) => {
  return run_jump($dt$, [run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(t_0))))]);
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Ann")), run_clo((x_4) => {
  return run_jump($kid$, [t_0, 1]);
}), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_6) => {
  return run_jump($ka_type_app$, [e_0, t_0, run_loop($wnf$(run_loop($cb$(e_0)), run_loop($ka_type$(e_0, ctx_0, run_loop($kid$(t_0, 0))))))]);
}), run_clo((x_7) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "ADT")), run_clo((x_8) => {
  return run_jump($tele_fill$, [run_loop($cb$(e_0)), run_loop($dt$(run_loop($lookup$(run_loop($cb$(e_0)), run_loop($nm$(t_0)))))), run_loop($ks$(t_0))]);
}), run_clo((x_9) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Eql")), run_clo((x_10) => {
  return run_jump($typ$, [2]);
}), run_clo((x_11) => {
  const x_12 = run_loop($String$eq$(run_loop($tg$(t_0)), "Qua"));
  const x_13 = run_loop($String$eq$(run_loop($tg$(t_0)), "Min"));
  return run_jump($kc$, [(x_12 || x_13), run_clo((x_14) => {
  return run_jump($atom$, ["Qnt"]);
}), run_clo((x_15) => {
  const x_16 = run_loop($String$eq$(run_loop($tg$(t_0)), "Typ"));
  const x_17 = run_loop($String$eq$(run_loop($tg$(t_0)), "Qnt"));
  const x_18 = (x_16 || x_17);
  const x_19 = run_loop($String$eq$(run_loop($tg$(t_0)), "All"));
  return run_jump($kc$, [(x_18 || x_19), run_clo((x_20) => {
  return run_jump($typ$, [1]);
}), run_clo((x_21) => {
  return run_jump($atom$, ["Error"]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $ka_args_cached_head$(e_0, ctx_0, tel_0, h_0, rest_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
  return run_jump($ka_args_after_head$, [e_0, ctx_0, tel_0, h_0, rest_0, run_loop($annotate$(e_0, ctx_0, h_0, run_loop($kid$(tel_0, 0))))]);
}), run_clo((x_1) => {
  return run_jump($ka_args_head$, [e_0, ctx_0, tel_0, h_0, rest_0]);
})]);
}

function $ka_mat_ctr$(e_0, ctx_0, t_0, ty_0, a_0, c_0) {
  return run_jump($kt$, ["Mat", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 0)), run_loop($mat_goal$(run_loop($cb$(e_0)), ty_0, run_loop($tele_fill$(run_loop($cb$(e_0)), run_loop($dt$(c_0)), run_loop($ks$(a_0)))), run_loop($da$(c_0)), run_loop($nm$(t_0)), {$: "Nil"})))), ["tail"]: {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, run_loop($kid$(t_0, 1)), run_loop($all$(run_loop($qt$(ty_0)), run_loop($nm$(ty_0)), run_loop($ix$(ty_0)), {$: "KTerm", ["tag"]: run_loop($tg$(a_0)), ["name"]: run_loop($nm$(a_0)), ["id"]: run_loop($ix$(a_0)), ["quant"]: run_loop($qt$(a_0)), ["kids"]: run_loop($ks$(a_0)), ["removed"]: {$: "Con", ["head"]: run_loop($nm$(t_0)), ["tail"]: run_loop($rm$(a_0))}}, run_loop($kid$(ty_0, 1)))))), ["tail"]: {$: "Nil"}}}]);
}

function $ka_let_head$(e_0, outer_0, ctx_0, h_0, rest_0, ty_0, vty_0) {
  return {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(h_0)), run_loop($ix$(h_0)), run_loop($qt$(h_0)), {$: "Con", ["head"]: run_loop($annotate$(e_0, outer_0, run_loop($kid$(h_0, 0)), vty_0)), ["tail"]: {$: "Nil"}})), ["tail"]: run_loop($ka_let$(e_0, outer_0, run_loop($ctx_bind$(ctx_0, run_loop($ix$(h_0)), run_loop($qt$(h_0)), run_loop($nm$(h_0)), vty_0)), run_loop($subst_terms$(rest_0, run_loop($ix$(h_0)), run_loop($kt$("Var", run_loop($nm$(h_0)), run_loop($ix$(h_0)), 0, {$: "Con", ["head"]: run_loop($kid$(h_0, 0)), ["tail"]: {$: "Nil"}})))), ty_0))};
}

function $kp_float_text$(s_0) {
  const x_0 = run_loop($String$contains$(s_0, "."));
  const x_1 = run_loop($String$contains$(s_0, "n"));
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return s_0;
}), run_clo((x_3) => {
  return run_jump($kp_float_point$, [s_0]);
})]);
}

function $kp_float$(n_0) {
  const w_0 = u32_to_word(n_0);
  return f32_from_bits(word_to_u32(w_0));
}

function $kp_nat$(t_0, n_0, p_0, env_0) {
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "Zero")), run_clo((x_0) => {
  const x_1 = run_loop($Nat$show$(n_0));
  return (x_1 + "n");
}), run_clo((x_2) => {
  const x_3 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_is$(t_0, "Ctr", "Succ")), (x_3 === 1))), run_clo((x_4) => {
  return run_jump($kp_nat$, [run_loop($kid$(t_0, 0)), nat_chk(n_0 + 1n), p_0, env_0]);
}), run_clo((x_5) => {
  const x_6 = run_loop($kp_go$(t_0, 2, env_0));
  const x_7 = run_loop($Nat$show$(n_0));
  const x_8 = ("n+" + x_6);
  return run_jump($kp_par$, [(x_7 + x_8), (p_0 > 2)]);
})]);
})]);
}

function $kp_ctor_char$(c_0, t_0, p_0, env_0) {
  if (c_0.$ === "Some") {
    const s_0 = c_0["value"];
    const x_0 = (s_0 + "'");
    return ("'" + x_0);
  } else {
    return run_jump($kp_ctor_string$, [run_loop($kp_string$(t_0)), t_0, p_0, env_0]);
  }
}

function $kp_char$(t_0, quote_0) {
  const x_0 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_is$(t_0, "Ctr", "Chr")), (x_0 === 1))), run_clo((x_1) => {
  return run_jump($kp_char_num$, [run_loop($kp_number$(run_loop($kid$(t_0, 0)))), quote_0]);
}), run_clo((x_2) => {
  return {$: "None"};
})]);
}

function $sp_template$(st_0, d_0, xs_0, ctx_0, owner_0, depth_0) {
  const x_0 = run_loop($terms_len$(xs_0));
  const x_1 = run_loop($dx$(d_0));
  return run_jump($kc$, [(x_0 < x_1), run_clo((x_2) => {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, "template requires all closed comptime arguments")), ["term"]: run_loop($norm_apply$(run_loop($ref$(run_loop($dn$(d_0)))), xs_0))};
}), run_clo((x_3) => {
  return run_jump($sp_template_args$, [st_0, d_0, run_loop($sp_take$(xs_0, run_loop($dx$(d_0)))), run_loop($sp_drop$(xs_0, run_loop($dx$(d_0)))), ctx_0, owner_0, depth_0]);
})]);
}

function $sp_regular_head$(st_0, head_0, xs_0, ctx_0, owner_0, depth_0) {
  return run_jump($sp_regular_done$, [xs_0, ctx_0, owner_0, depth_0, run_loop($sp_type$(st_0, head_0, ctx_0, owner_0)), run_loop($kc$(run_loop($String$eq$(run_loop($tg$(head_0)), "Ref")), run_clo((x_0) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: head_0};
}), run_clo((x_1) => {
  return run_jump($sp_term$, [st_0, head_0, ctx_0, run_loop($sp_type$(st_0, head_0, ctx_0, owner_0)), owner_0, depth_0]);
})))]);
}

function $sp_match_ctor$(st_0, t_0, ctx_0, goal_0, owner_0, depth_0, a_0, ctr_0) {
  return run_jump($sp_match_hit$, [t_0, ctx_0, goal_0, owner_0, depth_0, a_0, run_loop($sp_term$(st_0, run_loop($kid$(t_0, 0)), ctx_0, run_loop($mat_goal$(run_loop($sp_book$(st_0)), goal_0, run_loop($tele_fill$(run_loop($sp_book$(st_0)), run_loop($dt$(ctr_0)), run_loop($ks$(a_0)))), run_loop($da$(ctr_0)), run_loop($nm$(t_0)), {$: "Nil"})), owner_0, depth_0))]);
}

function $sp_states$(r_0) {
  const state_0 = r_0["state"];
  const terms_0 = r_0["terms"];
  return state_0;
}

function $sp_values$(r_0) {
  const state_0 = r_0["state"];
  const terms_0 = r_0["terms"];
  return terms_0;
}

function $sp_arg_head$(st_0, x_0, rest_0, ctx_0, ty_0, owner_0, depth_0) {
  const x_1 = run_loop($qt$(ty_0));
  return run_jump($sp_arg_done$, [x_0, rest_0, ctx_0, ty_0, owner_0, depth_0, run_loop($kc$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), (x_1 === 0))), run_clo((x_2) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: x_0};
}), run_clo((x_3) => {
  return run_jump($sp_term$, [st_0, x_0, ctx_0, run_loop($kid$(ty_0, 0)), owner_0, depth_0]);
})))]);
}

function $sp_let_bound$(h_0, rest_0, outer_0, ctx_0, goal_0, owner_0, depth_0, ty_0, r_0) {
  return run_jump($sp_cons$, [{$: "KTerm", ["tag"]: run_loop($tg$(h_0)), ["name"]: run_loop($nm$(h_0)), ["id"]: run_loop($ix$(h_0)), ["quant"]: run_loop($qt$(h_0)), ["kids"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Nil"}}, ["removed"]: run_loop($rm$(h_0))}, run_loop($sp_let$(run_loop($sp_state$(r_0)), rest_0, outer_0, run_loop($ctx_bind$(ctx_0, run_loop($ix$(h_0)), run_loop($qt$(h_0)), run_loop($nm$(h_0)), ty_0)), goal_0, owner_0, depth_0))]);
}

function $sp_rewrite_done$(t_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_state$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Nil"}}}}, ["removed"]: run_loop($rm$(t_0))}};
}

function $g_snf_children$(book_0, st_0, parent_0, done_0, todo_0, stack_0, fresh_0) {
  if (todo_0.$ === "Nil") {
    return run_jump($g_snf_return$, [book_0, st_0, {$: "KTerm", ["tag"]: run_loop($tg$(parent_0)), ["name"]: run_loop($nm$(parent_0)), ["id"]: run_loop($ix$(parent_0)), ["quant"]: run_loop($qt$(parent_0)), ["kids"]: run_loop($List$reverse$(done_0)), ["removed"]: run_loop($rm$(parent_0))}, stack_0, fresh_0]);
  } else {
    const h_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($g_snf_go$, [book_0, st_0, h_0, {$: "Con", ["head"]: {$: "KNormFrame", ["parent"]: parent_0, ["done"]: done_0, ["todo"]: rest_0}, ["tail"]: stack_0}, fresh_0]);
  }
}

function $g_cell$(book_0, st_0, t_0, args_0, pending_0, fallback_0, stack_0, cell_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(cell_0)), "GValue")), run_clo((x_0) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(cell_0, 0)), args_0, pending_0, fallback_0, stack_0]);
}), run_clo((x_1) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(cell_0, 0)), {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Con", ["head"]: {$: "GFill", ["id"]: run_loop($ix$(t_0)), ["args"]: args_0, ["pending"]: pending_0, ["fallback"]: fallback_0}, ["tail"]: stack_0}]);
})]);
}

function $g_get$(heap_0, id_0) {
  if (heap_0.$ === "GEmpty") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const value_0 = heap_0["value"];
    const left_0 = heap_0["left"];
    const right_0 = heap_0["right"];
    return run_jump($kc$, [(id_0 === 0), run_clo((x_0) => {
    return value_0;
}), run_clo((x_1) => {
    const x_2 = ((id_0 & 1) >>> 0);
    return run_jump($kc$, [(x_2 === 0), run_clo((x_3) => {
    return run_jump($g_get$, [left_0, ((id_0 >>> 1) >>> 0)]);
}), run_clo((x_4) => {
    return run_jump($g_get$, [right_0, ((id_0 >>> 1) >>> 0)]);
})]);
})]);
  }
}

function $g_heap$(st_0) {
  const heap_0 = st_0["heap"];
  const next_0 = st_0["next"];
  return heap_0;
}

function $g_app$(book_0, fn_0, args_0, pending_0, fallback_0, stack_0, r_0) {
  return run_jump($g_eval$, [book_0, run_loop($g_state$(r_0)), fn_0, {$: "Con", ["head"]: run_loop($g_term$(r_0)), ["tail"]: args_0}, pending_0, fallback_0, stack_0]);
}

function $g_share$(st_0, t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "GCell")), run_clo((x_0) => {
  return {$: "GResult", ["state"]: st_0, ["term"]: t_0};
}), run_clo((x_1) => {
  const x_2 = run_loop($g_next$(st_0));
  return {$: "GResult", ["state"]: {$: "GState", ["heap"]: run_loop($g_put$(run_loop($g_heap$(st_0)), run_loop($g_next$(st_0)), run_loop($kt$("GThunk", "", 0, 0, {$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}})))), ["next"]: ((x_2 + 1) >>> 0)}, ["term"]: run_loop($kt$("GCell", "", run_loop($g_next$(st_0)), 0, {$: "Nil"}))};
})]);
}

function $g_let$(book_0, st_0, ts_0, bindings_0, args_0, pending_0, fallback_0, stack_0) {
  if (ts_0.$ === "Nil") {
    return run_jump($g_return$, [book_0, st_0, run_loop($atom$("Absent")), stack_0]);
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(h_0)), "Bind")), run_clo((x_0) => {
    return run_jump($g_let_shared$, [book_0, h_0, rest_0, bindings_0, args_0, pending_0, fallback_0, stack_0, run_loop($g_share$(st_0, run_loop($kid$(h_0, 0))))]);
}), run_clo((x_1) => {
    return run_jump($g_eval$, [book_0, st_0, run_loop($g_let_sub$(h_0, bindings_0)), args_0, pending_0, fallback_0, stack_0]);
})]);
  }
}

function $g_ref$(book_0, st_0, t_0, args_0, stack_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($dk$(d_0)), "ADT")), run_clo((x_0) => {
  const x_1 = run_loop($da$(d_0));
  return run_jump($g_return$, [book_0, st_0, run_loop($norm_apply$(run_loop($kc$((x_1 === 0), run_clo((x_2) => {
  return run_jump($kt$, ["ADT", run_loop($nm$(t_0)), 0, 0, {$: "Nil"}]);
}), run_clo((x_3) => {
  return t_0;
}))), args_0)), stack_0]);
}), run_clo((x_4) => {
  const x_5 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent"));
  const x_6 = run_loop($String$eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Foreign"));
  const x_7 = run_loop($da$(d_0));
  const x_8 = run_loop($terms_len$(args_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$((x_5 || x_6))), (x_7 <= x_8))), run_clo((x_9) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($dv$(d_0)), args_0, run_loop($da$(d_0)), run_loop($norm_apply$(t_0, args_0)), stack_0]);
}), run_clo((x_10) => {
  return run_jump($g_return$, [book_0, st_0, run_loop($norm_apply$(t_0, args_0)), stack_0]);
})]);
})]);
}

function $g_args$(book_0, st_0, t_0, args_0, pending_0, fallback_0, stack_0) {
  if (args_0.$ === "Nil") {
    return run_jump($g_return$, [book_0, st_0, t_0, stack_0]);
  } else {
    const x_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_1) => {
    return run_jump($g_eval$, [book_0, st_0, run_loop($subst$(run_loop($kid$(t_0, 0)), run_loop($ix$(t_0)), x_0)), rest_0, run_loop($norm_dec$(pending_0)), fallback_0, stack_0]);
}), run_clo((x_2) => {
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_3) => {
    return run_jump($g_eval$, [book_0, st_0, x_0, {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Con", ["head"]: {$: "GMatch", ["arm"]: t_0, ["raw"]: x_0, ["args"]: rest_0, ["pending"]: pending_0, ["fallback"]: fallback_0}, ["tail"]: stack_0}]);
}), run_clo((x_4) => {
    return run_jump($g_return$, [book_0, st_0, run_loop($kc$(run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(t_0)), "Efq")), (pending_0 > 0))), run_clo((x_5) => {
    return fallback_0;
}), run_clo((x_6) => {
    return run_jump($norm_apply$, [t_0, {$: "Con", ["head"]: x_0, ["tail"]: rest_0}]);
}))), stack_0]);
})]);
})]);
  }
}

function $norm_subset$(as_0, bs_0) {
  if (bs_0.$ === "Nil") {
    return true;
  } else {
    const h_0 = bs_0["head"];
    const t_0 = bs_0["tail"];
    return run_jump($Bool$and$, [run_loop($has_name$(as_0, h_0)), run_loop($norm_subset$(as_0, t_0))]);
  }
}

function $norm_names_len$(names_0) {
  if (names_0.$ === "Nil") {
    return 0;
  } else {
    const h_0 = names_0["head"];
    const rest_0 = names_0["tail"];
    const x_0 = run_loop($norm_names_len$(rest_0));
    return ((1 + x_0) >>> 0);
  }
}

function $norm_cmp_zip$(as_0, bs_0, fresh_0, rest_0) {
  if (as_0.$ === "Con") {
    const a_0 = as_0["head"];
    const ar_0 = as_0["tail"];
    if (bs_0.$ === "Con") {
      const b_0 = bs_0["head"];
      const br_0 = bs_0["tail"];
      return {$: "Con", ["head"]: {$: "KNormCmp", ["a"]: a_0, ["b"]: b_0, ["le"]: false, ["fresh"]: fresh_0}, ["tail"]: run_loop($norm_cmp_zip$(ar_0, br_0, fresh_0, rest_0))};
    } else {
      return rest_0;
    }
  } else {
    return rest_0;
  }
}

function $fpe_snippet$(lines_0, at_0) {
  const x_0 = run_loop($fpe_lines_count$(lines_0));
  const x_1 = ((at_0 + 1) >>> 0);
  return run_jump($fpe_snippet_lines$, [lines_0, at_0, run_loop($f_choose$((x_0 < x_1), run_clo((x_2) => {
  return run_jump($fpe_lines_count$, [lines_0]);
}), run_clo((x_3) => {
  return ((at_0 + 1) >>> 0);
}))), 1]);
}

function $f_import_path$(ts_0, path_0, book_0, imports_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "as")), run_clo((x_0) => {
  return run_jump($f_import_alias$, [ts_0, path_0, book_0, imports_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "\n"));
  const x_3 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<eof>"));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($f_choose$, [run_loop($f_eq$(path_0, "Base")), run_clo((x_5) => {
  return run_jump($f_tops$, [ts_0, book_0, {$: "Con", ["head"]: run_loop($kt$("Import", path_0, 0, 0, {$: "Nil"})), ["tail"]: imports_0}, false]);
}), run_clo((x_6) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", "a module import requires as followed by an alias", 0, 0, {$: "Nil"})), imports_0]);
})]);
}), run_clo((x_7) => {
  const x_8 = run_loop($f_tx$(ts_0));
  return run_jump($f_import_path$, [run_loop($f_tl$(ts_0)), (path_0 + x_8), book_0, imports_0]);
})]);
})]);
}

function $Char$is_alpha$(c_0) {
  const x_0 = run_loop($Char$is_upper$(c_0));
  const x_1 = run_loop($Char$is_lower$(c_0));
  return (x_0 || x_1);
}

function $f_name_chars$(s_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  return run_jump($Bool$and$, [run_loop($f_ident$(run_loop($f_head$(s_0)))), run_loop($f_name_chars$(run_loop($f_tail$(s_0))))]);
})]);
}

function $f_reserved$(s_0) {
  const x_0 = run_loop($f_eq$(s_0, "def"));
  const x_1 = run_loop($f_eq$(s_0, "type"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(s_0, "law"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(s_0, "match"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($f_eq$(s_0, "case"));
  const x_8 = (x_6 || x_7);
  const x_9 = run_loop($f_eq$(s_0, "do"));
  const x_10 = (x_8 || x_9);
  const x_11 = run_loop($f_eq$(s_0, "return"));
  const x_12 = (x_10 || x_11);
  const x_13 = run_loop($f_eq$(s_0, "for"));
  const x_14 = (x_12 || x_13);
  const x_15 = run_loop($f_eq$(s_0, "exs"));
  const x_16 = (x_14 || x_15);
  const x_17 = run_loop($f_eq$(s_0, "where"));
  const x_18 = (x_16 || x_17);
  const x_19 = run_loop($f_eq$(s_0, "is"));
  const x_20 = (x_18 || x_19);
  const x_21 = run_loop($f_eq$(s_0, "import"));
  const x_22 = (x_20 || x_21);
  const x_23 = run_loop($f_eq$(s_0, "Type"));
  const x_24 = (x_22 || x_23);
  const x_25 = run_loop($f_eq$(s_0, "Data"));
  const x_26 = (x_24 || x_25);
  const x_27 = run_loop($f_eq$(s_0, "Kind"));
  const x_28 = (x_26 || x_27);
  const x_29 = run_loop($f_eq$(s_0, "Quant"));
  return (x_28 || x_29);
}

function $f_dn$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return name_0;
}

function $f_law_clause$(name_0, exi_0, ts_0, book_0, imports_0, clauses_0) {
  const x_0 = run_loop($f_templates$(clauses_0));
  const x_1 = run_loop($f_len$(clauses_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$not$(exi_0)), run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")))), (x_0 < x_1))), run_clo((x_2) => {
  return run_jump($f_result$, [book_0, run_loop($f_pn$(run_loop($fpe_error$(ts_0, "expected a plain clause (only leading clauses take ~)", "a plain clause (only leading clauses take ~)")))), imports_0]);
}), run_clo((x_3) => {
  return run_jump($f_law_type$, [name_0, run_loop($kt$(run_loop($f_choose$(exi_0, run_clo((x_4) => {
  return "Exists";
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), run_clo((x_6) => {
  return "Template";
}), run_clo((x_7) => {
  return "Bind";
})]);
}))), run_loop($f_tx$(run_loop($f_unmark$(ts_0)))), run_loop($f_atid$(ts_0)), run_loop($f_quant$(ts_0)), {$: "Nil"})), run_loop($f_expr$(run_loop($f_tl$(run_loop($f_tl$(run_loop($f_unmark$(ts_0)))))), 0)), book_0, imports_0, clauses_0]);
})]);
}

function $f_law_end$(name_0, p_0, book_0, imports_0, clauses_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, ty_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_tops$, [ts_0, {$: "Con", ["head"]: {$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: run_loop($f_law_arity$(clauses_0)), ["templates"]: run_loop($f_templates$(clauses_0)), ["typ"]: run_loop($f_law_bind$(clauses_0, ty_0)), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: false}, ["tail"]: book_0}, imports_0, false]);
})]);
}

function $f_expr$(ts_0, min_0) {
  return run_jump($f_grow$, [run_loop($f_atom$(run_loop($f_skip$(ts_0)))), min_0]);
}

function $f_def_base$(name_0, p_0, book_0, imports_0, unsafe_0) {
  const pars_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(pars_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, pars_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "->")), run_clo((x_2) => {
  return run_jump($f_def_type$, [name_0, run_loop($ks$(pars_0)), run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), book_0, imports_0, unsafe_0]);
}), run_clo((x_3) => {
  return run_jump($f_def_type$, [name_0, run_loop($ks$(pars_0)), {$: "FParsed", ["term"]: run_loop($f_dt$(run_loop($f_find$(name_0, book_0)))), ["rest"]: ts_0}, book_0, imports_0, unsafe_0]);
})]);
})]);
}

function $f_bare_params$(params_0) {
  if (params_0.$ === "Nil") {
    return true;
  } else {
    const p_0 = params_0["head"];
    const rest_0 = params_0["tail"];
    return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(run_loop($kid$(p_0, 0)))), "Qnt")), run_loop($Bool$not$(run_loop($f_eq$(run_loop($tg$(p_0)), "Template")))))), run_loop($f_bare_params$(rest_0))]);
  }
}

function $f_len$(xs_0) {
  if (xs_0.$ === "Nil") {
    return 0;
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    const x_1 = run_loop($f_len$(xt_0));
    return ((1 + x_1) >>> 0);
  }
}

function $f_pr$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return ts_0;
}

function $f_validate_param$(ts_0, end_0, acc_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), run_loop($Bool$not$(run_loop($f_eq$(end_0, ")")))))), run_clo((x_0) => {
  return run_jump($f_err$, [ts_0, "~ is only allowed on def or law template parameters"]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($f_valid_name$(run_loop($f_tx$(run_loop($f_unmark$(ts_0)))))))), run_clo((x_2) => {
  return run_jump($f_err$, [ts_0, "reserved parameter name"]);
}), run_clo((x_3) => {
  const x_4 = run_loop($f_templates$(acc_0));
  const x_5 = run_loop($f_len$(acc_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), (x_4 < x_5))), run_clo((x_6) => {
  return run_jump($f_err$, [ts_0, "only leading parameters may use ~"]);
}), run_clo((x_7) => {
  return run_jump($f_tele_binder$, [run_loop($f_tx$(run_loop($f_unmark$(ts_0)))), run_loop($f_atid$(ts_0)), run_loop($f_quant$(ts_0)), run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), run_loop($f_tl$(run_loop($f_unmark$(ts_0)))), end_0, acc_0]);
})]);
})]);
})]);
}

function $f_type_params$(name_0, p_0, book_0, imports_0) {
  const pars_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(pars_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, pars_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_type_kind$, [name_0, run_loop($ks$(pars_0)), run_loop($f_expect$(run_loop($f_expr$(run_loop($f_pr$(run_loop($f_expect$({$: "FParsed", ["term"]: pars_0, ["rest"]: ts_0}, "is")))), 0)), ":")), book_0, imports_0]);
})]);
}

function $f_type_base$(name_0, ts_0, book_0, imports_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<-"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_type_params$, [name_0, run_loop($f_tele$(run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<-")), run_clo((x_3) => {
  const x_4 = run_loop($f_col$(ts_0));
  return {$: "Con", ["head"]: {$: "FToken", ["text"]: "-", ["f_line"]: run_loop($f_line$(ts_0)), ["f_col"]: ((x_4 + 1) >>> 0), ["f_kind"]: 0}, ["tail"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_5) => {
  return run_jump($f_tl$, [ts_0]);
}))), ">", {$: "Nil"})), book_0, imports_0]);
}), run_clo((x_6) => {
  return run_jump($f_type_params$, [name_0, {$: "FParsed", ["term"]: run_loop($kt$("Tele", "", 0, 0, {$: "Nil"})), ["rest"]: ts_0}, book_0, imports_0]);
})]);
}

function $fpe_defs_next$(error_0, rest_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(error_0)), "Absent")), run_clo((x_0) => {
  return run_jump($fpe_defs$, [rest_0]);
}), run_clo((x_1) => {
  return error_0;
})]);
}

function $fpe_terms$(ts_0) {
  if (ts_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const head_0 = ts_0["head"];
    const tail_0 = ts_0["tail"];
    return run_jump($fpe_terms_next$, [run_loop($fpe_term$(head_0)), tail_0]);
  }
}

function $f_graph_fresh_name$(rest_0, done_0, d_0, hash_0, old_0) {
  const x_0 = run_loop($Bool$not$(run_loop($db$(old_0))));
  const x_1 = run_loop($db$(d_0));
  const x_2 = run_loop($f_eq$(run_loop($dk$(old_0)), "Absent"));
  const x_3 = run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($dk$(old_0)), "Def")), run_loop($f_eq$(run_loop($dk$(d_0)), "Def")))), run_loop($f_eq$(run_loop($tg$(run_loop($dv$(old_0)))), "Absent")))), run_loop($Bool$not$(run_loop($f_eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Absent")))))), (x_0 || x_1)));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($f_graph_fresh_names$, [rest_0, run_loop($index_set$(done_0, d_0, hash_0, 32))]);
}), run_clo((x_5) => {
  const x_6 = run_loop($dn$(d_0));
  const x_7 = (x_6 + ")");
  return ("expected a fresh name (duplicate declaration: " + x_7);
})]);
}

function $f_error_defs_more$(err_0, rest_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_error_defs$, [rest_0]);
}), run_clo((x_1) => {
  return err_0;
})]);
}

function $f_error_more$(err_0, rest_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_error_terms$, [rest_0]);
}), run_clo((x_1) => {
  return err_0;
})]);
}

function $f_error_term$(t_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Error")), run_clo((x_0) => {
  return run_jump($nm$, [t_0]);
}), run_clo((x_1) => {
  return run_jump($f_error_terms$, [run_loop($ks$(t_0))]);
})]);
}

function $f_graph_finish$(s_0, ns_0, book_0, imports_0, g_0) {
  const prior_0 = g_0["book"];
  const err_0 = g_0["error"];
  const done_0 = g_0["done"];
  return run_jump($f_graph_finish_alias$, [s_0, ns_0, run_loop($f_alias_defs$(book_0, imports_0)), imports_0, prior_0, err_0, done_0]);
}

function $f_graph_aliases$(imports_0, ns_0) {
  if (imports_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const im_0 = imports_0["head"];
    const rest_0 = imports_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Import", run_loop($f_import_namespace$(im_0, ns_0)), 0, 0, run_loop($ks$(im_0)))), ["tail"]: run_loop($f_graph_aliases$(rest_0, ns_0))};
  }
}

function $f_import_pathname$(im_0, s_0, sources_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($nm$(im_0)), "Base")), run_clo((x_0) => {
  return run_jump($f_source_path$, [run_loop($f_source$("Base", sources_0))]);
}), run_clo((x_1) => {
  return run_jump($f_path_normal$, [run_loop($f_path_join$(run_loop($f_path_dir$(run_loop($f_source_path$(s_0)))), run_loop($nm$(im_0))))]);
})]);
}

function $f_import_namespace$(im_0, ns_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($nm$(im_0)), "Base")), run_clo((x_0) => {
  return "";
}), run_clo((x_1) => {
  return run_jump($f_strip_bend$, [run_loop($f_path_normal$(run_loop($f_path_join$(run_loop($f_path_dir$(ns_0)), run_loop($nm$(im_0))))))]);
})]);
}

function $tele_tip$(book_0, t_0) {
  return run_jump($tele_tip_head$, [book_0, run_loop($wnf$(book_0, t_0))]);
}

function $check_ctors$(e_0, d_0, ctrs_0, kind_0) {
  if (ctrs_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ctrs_0["head"];
    const t_0 = ctrs_0["tail"];
    return run_jump($check_ctors_next$, [e_0, d_0, t_0, kind_0, run_loop($check_ctor_tel$(e_0, d_0, run_loop($dt$(h_0)), kind_0, run_loop($da$(d_0)), run_loop($da$(h_0)), {$: "Nil"}, {$: "Nil"}))]);
  }
}

function $foreign_head$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "App")), run_clo((x_0) => {
  return run_jump($foreign_head$, [run_loop($kid$(t_0, 0))]);
}), run_clo((x_1) => {
  return t_0;
})]);
}

function $foreign_tip$(t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(run_loop($strip$(t_0)))), "All")), run_clo((x_0) => {
  return run_jump($foreign_tip$, [run_loop($kid$(run_loop($strip$(t_0)), 1))]);
}), run_clo((x_1) => {
  return run_jump($strip$, [t_0]);
})]);
}

function $self_pending$(d_0, body_0) {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($Bool$not$(run_loop($du$(d_0)))), run_loop($contains_self$({$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}, run_loop($dn$(d_0)))))), run_clo((x_0) => {
  const x_1 = run_loop($da$(d_0));
  const x_2 = run_loop($dx$(d_0));
  return ((x_1 - x_2) >>> 0);
}), run_clo((x_3) => {
  return 0;
})]);
}

function $tele_quantities$(book_0, ty_0, n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return {$: "Nil"};
}), run_clo((x_1) => {
  return run_jump($tele_quantities_head$, [book_0, run_loop($wnf$(book_0, ty_0)), n_0]);
})]);
}

function $check_template_binder$(book_0, d_0, ty_0, body_0, lhs_0, n_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
  const x_1 = run_loop($nm$(ty_0));
  const x_2 = run_loop($U32$show$(run_loop($ix$(ty_0))));
  const x_3 = (x_1 + x_2);
  const x_4 = run_loop($dn$(d_0));
  const x_5 = ("~" + x_3);
  return run_jump($check_template_open$, [book_0, d_0, ty_0, body_0, lhs_0, n_0, (x_4 + x_5)]);
}), run_clo((x_6) => {
  return run_jump($bad$, ["template telescope is too short"]);
})]);
}

function $dg_lpad$(s_0, width_0) {
  const x_0 = run_loop($dg_width$(s_0));
  const x_4 = run_loop($dg_padding$(run_loop($kc$((width_0 > x_0), run_clo((x_1) => {
  const x_2 = run_loop($dg_width$(s_0));
  return ((width_0 - x_2) >>> 0);
}), run_clo((x_3) => {
  return 0;
})))));
  return (x_4 + s_0);
}

function $String$split$fin$(c_0, r_0, cut_0) {
  if (!cut_0) {
    return run_jump($String$split$push$, [c_0, r_0]);
  } else {
    return {$: "Con", ["head"]: "", ["tail"]: r_0};
  }
}

function $fp_def$(d_0, source_0) {
  return run_jump($List$append$, [run_loop($fp_term$(run_loop($dt$(d_0)), run_loop($dn$(d_0)), source_0, {$: "Con", ["head"]: 0, ["tail"]: {$: "Nil"}})), run_loop($List$append$(run_loop($fp_term$(run_loop($dv$(d_0)), run_loop($dn$(d_0)), source_0, {$: "Con", ["head"]: 1, ["tail"]: {$: "Nil"}})), run_loop($fp_ctors$(run_loop($dc$(d_0)), run_loop($dn$(d_0)), source_0, 0))))]);
}

function $descend_sub$(a_0, ps_0) {
  if (ps_0.$ === "Nil") {
    return 2;
  } else {
    const h_0 = ps_0["head"];
    const t_0 = ps_0["tail"];
    const x_0 = run_loop($descend$(1, a_0, h_0));
    return run_jump($kc$, [(x_0 === 2), run_clo((x_1) => {
    return run_jump($descend_sub$, [a_0, t_0]);
}), run_clo((x_2) => {
    return 0;
})]);
  }
}

function $core_subst_stable_terms$(ts_0) {
  if (ts_0.$ === "Nil") {
    return true;
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($kc$, [run_loop($core_subst_stable$(h_0)), run_clo((x_0) => {
    return run_jump($core_subst_stable_terms$, [rest_0]);
}), run_clo((x_1) => {
    return false;
})]);
  }
}

function $core_subst_stable_app$(kids_0, removed_0) {
  if (removed_0.$ === "Con") {
    const h_0 = removed_0["head"];
    const rest_0 = removed_0["tail"];
    return false;
  } else {
    return run_jump($core_subst_stable_app_kids$, [kids_0]);
  }
}

function $tele_check_legacy_head$(e_0, ctx_0, tel_0, h_0, rest_0, dem_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
  return run_jump($tele_check_done$, [run_loop($check$(e_0, ctx_0, h_0, run_loop($qdem$(run_loop($qt$(tel_0)), dem_0)), run_loop($kid$(tel_0, 0)))), run_loop($tele_check_legacy$(e_0, ctx_0, run_loop($subst$(run_loop($kid$(tel_0, 1)), run_loop($ix$(tel_0)), h_0)), rest_0, dem_0))]);
}), run_clo((x_1) => {
  return run_jump($bad$, ["too many telescope arguments"]);
})]);
}

function $ka_app_spine_root$(e_0, ctx_0, arg_0, node_0, fty_0) {
  return run_jump($app$, [run_loop($ka_wrap$(node_0, fty_0)), run_loop($annotate$(e_0, ctx_0, arg_0, run_loop($kid$(fty_0, 0))))]);
}

function $ka_spine_finish$(e_0, ctx_0, arg_0, r_0) {
  const node_0 = r_0["node"];
  const ty_0 = r_0["typ"];
  return run_jump($ka_spine_step$, [e_0, ctx_0, arg_0, node_0, run_loop($wnf$(run_loop($cb$(e_0)), ty_0))]);
}

function $ka_type_app$(e_0, t_0, fty_0) {
  return run_jump($subst$, [run_loop($kid$(fty_0, 1)), run_loop($ix$(fty_0)), run_loop($kid$(t_0, 1))]);
}

function $ka_args_after_head$(e_0, ctx_0, tel_0, h_0, rest_0, annotated_0) {
  return run_jump($kc$, [run_loop($core_subst_stable$(run_loop($kid$(tel_0, 1)))), run_clo((x_0) => {
  return {$: "Con", ["head"]: annotated_0, ["tail"]: run_loop($ka_args_static$(e_0, ctx_0, run_loop($kid$(tel_0, 1)), rest_0))};
}), run_clo((x_1) => {
  return {$: "Con", ["head"]: annotated_0, ["tail"]: run_loop($ka_args$(e_0, ctx_0, run_loop($subst$(run_loop($kid$(tel_0, 1)), run_loop($ix$(tel_0)), h_0)), rest_0))};
})]);
}

function $ka_args_head$(e_0, ctx_0, tel_0, h_0, rest_0) {
  return {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, h_0, run_loop($kid$(tel_0, 0)))), ["tail"]: run_loop($ka_args$(e_0, ctx_0, run_loop($subst$(run_loop($kid$(tel_0, 1)), run_loop($ix$(tel_0)), h_0)), rest_0))};
}

function $String$contains$(s_0, p_0) {
  if (s_0 === "") {
    return run_jump($String$is_empty$, [p_0]);
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    return run_jump($String$contains$if$, [t_0, p_0, run_loop($String$starts_with$((h_0 + t_0), p_0))]);
  }
}

function $kp_float_point$(s_0) {
  if (s_0 === "") {
    return ".0";
  } else {
    const h_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(0, 2) : s_0[0]);
    const t_0 = (s_0.codePointAt(0) > 0xFFFF ? s_0.slice(2) : s_0.slice(1));
    const x_0 = run_loop($Char$to_u32$(h_0));
    return run_jump($kc$, [(x_0 === 101), run_clo((x_1) => {
    return (".0e" + t_0);
}), run_clo((x_2) => {
    const x_3 = run_loop($Char$show$(h_0));
    const x_4 = run_loop($kp_float_point$(t_0));
    return (x_3 + x_4);
})]);
  }
}

function $Nat$show$(n_0) {
  const m_0 = n_0;
  return run_jump($Nat$show$fin$, [m_0, "", run_loop($Nat$show$put$(nat_divmod(m_0, 10n)))]);
}

function $kp_ctor_string$(s_0, t_0, p_0, env_0) {
  if (s_0.$ === "Some") {
    const x_0 = s_0["value"];
    const x_1 = (x_0 + "\"");
    return ("\"" + x_1);
  } else {
    const x_2 = run_loop($kp_eq$(run_loop($nm$(t_0)), "Con"));
    const x_3 = run_loop($kp_eq$(run_loop($nm$(t_0)), "Nil"));
    return run_jump($kc$, [(x_2 || x_3), run_clo((x_4) => {
    return run_jump($kp_list$, [run_loop($kp_chain$(t_0, "Con", 2, {$: "Nil"})), p_0, env_0]);
}), run_clo((x_5) => {
    return run_jump($kc$, [run_loop($kp_eq$(run_loop($nm$(t_0)), "Tuple")), run_clo((x_6) => {
    return run_jump($kp_tuple$, [run_loop($kp_chain$(t_0, "Tuple", 2, {$: "Nil"})), env_0]);
}), run_clo((x_7) => {
    return run_jump($kp_ctor_array$, [run_loop($kp_array$(t_0)), t_0, env_0]);
})]);
})]);
  }
}

function $kp_string$(t_0) {
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "SNil")), run_clo((x_0) => {
  return {$: "Some", ["value"]: ""};
}), run_clo((x_1) => {
  const x_2 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_is$(t_0, "Ctr", "SCon")), (x_2 === 2))), run_clo((x_3) => {
  return run_jump($kp_append$, [run_loop($kp_char$(run_loop($kid$(t_0, 0)), 34)), run_loop($kp_string$(run_loop($kid$(t_0, 1))))]);
}), run_clo((x_4) => {
  return {$: "None"};
})]);
})]);
}

function $kp_char_num$(n_0, quote_0) {
  if (n_0.$ === "None") {
    return {$: "None"};
  } else {
    const x_0 = n_0["value"];
    return {$: "Some", ["value"]: run_loop($kp_escape$(x_0, quote_0))};
  }
}

function $sp_template_args$(st_0, d_0, closed_0, rest_0, ctx_0, owner_0, depth_0) {
  return run_jump($sp_template_checked$, [st_0, d_0, closed_0, rest_0, ctx_0, owner_0, depth_0, run_loop($template_args$({$: "KEnv", ["book"]: run_loop($sp_book$(st_0)), ["name"]: owner_0, ["lhs"]: run_loop($ref$(owner_0)), ["pending"]: 0, ["quantities"]: {$: "Nil"}, ["unsafe"]: run_loop($du$(d_0))}, run_loop($dt$(d_0)), closed_0, run_loop($dx$(d_0))))]);
}

function $sp_take$(ts_0, n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return {$: "Nil"};
}), run_clo((x_1) => {
  return run_jump($sp_take_next$, [ts_0, n_0]);
})]);
}

function $sp_drop$(ts_0, n_0) {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
  return ts_0;
}), run_clo((x_1) => {
  return run_jump($sp_drop_next$, [ts_0, n_0]);
})]);
}

function $sp_regular_done$(xs_0, ctx_0, owner_0, depth_0, ty_0, r_0) {
  return run_jump($sp_apply_result$, [run_loop($sp_value$(r_0)), run_loop($sp_args$(run_loop($sp_state$(r_0)), xs_0, ctx_0, ty_0, owner_0, depth_0))]);
}

function $sp_match_hit$(t_0, ctx_0, goal_0, owner_0, depth_0, a_0, r_0) {
  return run_jump($sp_pair$, [t_0, run_loop($sp_value$(r_0)), run_loop($sp_term$(run_loop($sp_state$(r_0)), run_loop($kid$(t_0, 1)), ctx_0, run_loop($all$(run_loop($qt$(goal_0)), run_loop($nm$(goal_0)), run_loop($ix$(goal_0)), {$: "KTerm", ["tag"]: run_loop($tg$(a_0)), ["name"]: run_loop($nm$(a_0)), ["id"]: run_loop($ix$(a_0)), ["quant"]: run_loop($qt$(a_0)), ["kids"]: run_loop($ks$(a_0)), ["removed"]: {$: "Con", ["head"]: run_loop($nm$(t_0)), ["tail"]: run_loop($rm$(a_0))}}, run_loop($kid$(goal_0, 1)))), owner_0, depth_0))]);
}

function $sp_arg_done$(raw_0, rest_0, ctx_0, ty_0, owner_0, depth_0, r_0) {
  return run_jump($sp_cons$, [run_loop($sp_value$(r_0)), run_loop($sp_args$(run_loop($sp_state$(r_0)), rest_0, ctx_0, run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), raw_0)), owner_0, depth_0))]);
}

function $sp_cons$(h_0, r_0) {
  return {$: "KSpecTerms", ["state"]: run_loop($sp_states$(r_0)), ["terms"]: {$: "Con", ["head"]: h_0, ["tail"]: run_loop($sp_values$(r_0))}};
}

function $g_snf_return$(book_0, st_0, t_0, stack_0, fresh_0) {
  if (stack_0.$ === "Nil") {
    return t_0;
  } else {
    const _t_0 = stack_0["head"];
    const parent_0 = _t_0["parent"];
    const done_0 = _t_0["done"];
    const todo_0 = _t_0["todo"];
    const rest_0 = stack_0["tail"];
    return run_jump($g_snf_children$, [book_0, st_0, parent_0, {$: "Con", ["head"]: t_0, ["tail"]: done_0}, todo_0, rest_0, fresh_0]);
  }
}

function $g_put$(heap_0, id_0, value_0) {
  if (heap_0.$ === "GEmpty") {
    return run_jump($g_put_node$, [run_loop($atom$("Absent")), {$: "GEmpty"}, {$: "GEmpty"}, id_0, value_0]);
  } else {
    const old_0 = heap_0["value"];
    const left_0 = heap_0["left"];
    const right_0 = heap_0["right"];
    return run_jump($g_put_node$, [old_0, left_0, right_0, id_0, value_0]);
  }
}

function $g_next$(st_0) {
  const heap_0 = st_0["heap"];
  const next_0 = st_0["next"];
  return next_0;
}

function $g_return$(book_0, st_0, t_0, stack_0) {
  if (stack_0.$ === "Nil") {
    return {$: "GResult", ["state"]: st_0, ["term"]: t_0};
  } else {
    const frame_0 = stack_0["head"];
    const rest_0 = stack_0["tail"];
    return run_jump($g_resume$, [book_0, st_0, t_0, frame_0, rest_0]);
  }
}

function $g_let_shared$(book_0, h_0, rest_0, bindings_0, args_0, pending_0, fallback_0, stack_0, r_0) {
  return run_jump($g_let$, [book_0, run_loop($g_state$(r_0)), rest_0, {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(h_0)), run_loop($ix$(h_0)), run_loop($qt$(h_0)), {$: "Con", ["head"]: run_loop($g_term$(r_0)), ["tail"]: {$: "Nil"}})), ["tail"]: bindings_0}, args_0, pending_0, fallback_0, stack_0]);
}

function $g_let_sub$(t_0, bindings_0) {
  if (bindings_0.$ === "Nil") {
    return t_0;
  } else {
    const h_0 = bindings_0["head"];
    const rest_0 = bindings_0["tail"];
    return run_jump($g_let_sub$, [run_loop($subst$(t_0, run_loop($ix$(h_0)), run_loop($kid$(h_0, 0)))), rest_0]);
  }
}

function $fpe_snippet_lines$(lines_0, at_0, end_0, line_0) {
  if (lines_0.$ === "Nil") {
    return "";
  } else {
    const head_0 = lines_0["head"];
    const tail_0 = lines_0["tail"];
    return run_jump($f_choose$, [(line_0 > end_0), run_clo((x_0) => {
    return "";
}), run_clo((x_1) => {
    const x_2 = ((line_0 + 1) >>> 0);
    const x_13 = run_loop($f_choose$((x_2 < at_0), run_clo((x_3) => {
    return "";
}), run_clo((x_4) => {
    const x_5 = run_loop($U32$show$(end_0));
    const x_6 = BigInt([...x_5].length);
    const x_9 = run_loop($f_choose$((line_0 === at_0), run_clo((x_7) => {
    return ">| ";
}), run_clo((x_8) => {
    return " | ";
})));
    const x_10 = run_loop($fpe_pad$(run_loop($U32$show$(line_0)), Number(x_6 & 0xFFFFFFFFn)));
    const x_11 = (x_9 + head_0);
    const x_12 = (x_10 + x_11);
    return ("\n" + x_12);
})));
    const x_14 = run_loop($fpe_snippet_lines$(tail_0, at_0, end_0, ((line_0 + 1) >>> 0)));
    return (x_13 + x_14);
})]);
  }
}

function $fpe_lines_count$(lines_0) {
  if (lines_0.$ === "Nil") {
    return 0;
  } else {
    const head_0 = lines_0["head"];
    const tail_0 = lines_0["tail"];
    const x_0 = run_loop($fpe_lines_count$(tail_0));
    return ((1 + x_0) >>> 0);
  }
}

function $f_import_alias$(ts_0, path_0, book_0, imports_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($String$ends_with$(path_0, ".bend")), run_loop($f_alias_valid$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))))), run_clo((x_0) => {
  return run_jump($f_tops$, [run_loop($f_tl$(run_loop($f_tl$(ts_0)))), book_0, {$: "Con", ["head"]: run_loop($kt$("Import", path_0, 0, 0, {$: "Con", ["head"]: run_loop($kt$("Alias", run_loop($f_tx$(run_loop($f_tl$(ts_0)))), 0, 0, {$: "Nil"})), ["tail"]: {$: "Nil"}})), ["tail"]: imports_0}, false]);
}), run_clo((x_1) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", "an import requires a .bend path and a valid alias", 0, 0, {$: "Nil"})), imports_0]);
})]);
}

function $Char$is_upper$(c_0) {
  const x_0 = c_0.codePointAt(0);
  return run_jump($Bool$and$, [(x_0 >= 65), (x_0 <= 90)]);
}

function $Char$is_lower$(c_0) {
  const x_0 = c_0.codePointAt(0);
  return run_jump($Bool$and$, [(x_0 >= 97), (x_0 <= 122)]);
}

function $f_templates$(pars_0) {
  if (pars_0.$ === "Nil") {
    return 0;
  } else {
    const p_0 = pars_0["head"];
    const ps_0 = pars_0["tail"];
    const x_2 = run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(p_0)), "Template")), run_clo((x_0) => {
    return 1;
}), run_clo((x_1) => {
    return 0;
})));
    const x_3 = run_loop($f_templates$(ps_0));
    return ((x_2 + x_3) >>> 0);
  }
}

function $f_law_type$(name_0, binder_0, p_0, book_0, imports_0, clauses_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, ty_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(ts_0)))), "where")), run_clo((x_2) => {
  return run_jump($f_law_where$, [name_0, binder_0, ty_0, run_loop($f_expr$(run_loop($f_tl$(run_loop($f_skip$(ts_0)))), 0)), book_0, imports_0, clauses_0]);
}), run_clo((x_3) => {
  return run_jump($f_law$, [name_0, run_loop($f_skip$(ts_0)), book_0, imports_0, {$: "Con", ["head"]: run_loop($kt$(run_loop($tg$(binder_0)), run_loop($nm$(binder_0)), run_loop($ix$(binder_0)), run_loop($qt$(binder_0)), {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}})), ["tail"]: clauses_0}]);
})]);
})]);
}

function $f_unmark$(ts_0) {
  const x_0 = run_loop($f_quant$(ts_0));
  return run_jump($f_choose$, [(x_0 === 1), run_clo((x_1) => {
  return ts_0;
}), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
})]);
}

function $f_atid$(ts_0) {
  const x_0 = run_loop($f_line$(ts_0));
  const x_1 = (Math.imul(x_0, 65536) >>> 0);
  const x_2 = run_loop($f_col$(ts_0));
  return ((x_1 + x_2) >>> 0);
}

function $f_quant$(ts_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "-"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return 0;
}), run_clo((x_3) => {
  const x_4 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "+"));
  const x_5 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "+bind"));
  return run_jump($f_choose$, [(x_4 || x_5), run_clo((x_6) => {
  return 2;
}), run_clo((x_7) => {
  return 1;
})]);
})]);
}

function $f_law_arity$(clauses_0) {
  if (clauses_0.$ === "Nil") {
    return 0;
  } else {
    const c_0 = clauses_0["head"];
    const rest_0 = clauses_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(c_0)), "Exists")), run_clo((x_0) => {
    return 0;
}), run_clo((x_1) => {
    const x_2 = run_loop($f_law_arity$(rest_0));
    return ((1 + x_2) >>> 0);
})]);
  }
}

function $f_law_bind$(clauses_0, ty_0) {
  if (clauses_0.$ === "Nil") {
    return ty_0;
  } else {
    const c_0 = clauses_0["head"];
    const cs_0 = clauses_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(c_0)), "Exists")), run_clo((x_0) => {
    return run_jump($f_app$, [run_loop($kt$("Ref", "Exists", 0, 1, {$: "Nil"})), {$: "Con", ["head"]: run_loop($kid$(c_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Lam", run_loop($nm$(c_0)), run_loop($ix$(c_0)), 1, {$: "Con", ["head"]: run_loop($f_law_bind$(cs_0, ty_0)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_1) => {
    return run_jump($kt$, ["All", run_loop($nm$(c_0)), run_loop($ix$(c_0)), run_loop($qt$(c_0)), {$: "Con", ["head"]: run_loop($kid$(c_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($f_law_bind$(cs_0, ty_0)), ["tail"]: {$: "Nil"}}}]);
})]);
  }
}

function $f_grow$(p_0, min_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  const x_0 = run_loop($f_prec$(run_loop($f_tx$(run_loop($f_skip$(ts_0))))));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(ts_0)))), "%"));
  const x_2 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(ts_0)))), "-"));
  const x_3 = run_loop($f_col$(run_loop($f_skip$(ts_0))));
  const x_4 = run_loop($f_col$(run_loop($f_tl$(run_loop($f_skip$(ts_0))))));
  const x_5 = ((x_3 + 1) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "\n")), (x_0 > 0))), run_loop($Bool$not$(run_loop($Bool$and$((x_1 || x_2), (x_4 === x_5))))))), run_clo((x_6) => {
  return run_jump($f_grow_base$, [{$: "FParsed", ["term"]: n_0, ["rest"]: run_loop($f_skip$(ts_0))}, min_0]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "!")), run_clo((x_8) => {
  return run_jump($f_bang$, [n_0, ts_0, min_0]);
}), run_clo((x_9) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "[")), run_clo((x_10) => {
  return run_jump($f_index$, [n_0, run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), "]")), min_0]);
}), run_clo((x_11) => {
  return run_jump($f_grow_base$, [{$: "FParsed", ["term"]: n_0, ["rest"]: ts_0}, min_0]);
})]);
})]);
})]);
}

function $f_atom$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), run_clo((x_0) => {
  return run_jump($f_template_expr$, [run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "do")), run_clo((x_2) => {
  return run_jump($f_do_start$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "%")), run_clo((x_4) => {
  return run_jump($f_rewrite$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_5) => {
  return run_jump($f_atom_base$, [ts_0]);
})]);
})]);
})]);
}

function $f_def_type$(name_0, pars_0, p_0, book_0, imports_0, unsafe_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Absent")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, run_loop($kt$("Error", ("definition without return type needs a law: " + name_0), 0, 0, {$: "Nil"})), imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(run_loop($f_tl$(ts_0)))))), "import")), run_clo((x_2) => {
  return run_jump($f_foreign$, [name_0, pars_0, run_loop($f_def_signature$(name_0, pars_0, ty_0, book_0)), run_loop($f_skip$(run_loop($f_tl$(ts_0)))), book_0, imports_0, unsafe_0, {$: "Nil"}]);
}), run_clo((x_3) => {
  return run_jump($f_def_body$, [name_0, pars_0, run_loop($f_def_signature$(name_0, pars_0, ty_0, book_0)), run_loop($f_body$(run_loop($f_pr$(run_loop($f_expect$({$: "FParsed", ["term"]: ty_0, ["rest"]: ts_0}, ":")))))), book_0, imports_0, unsafe_0]);
})]);
})]);
}

function $f_dt$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return typ_0;
}

function $f_tele_binder$(name_0, id_0, q_0, temp_0, ts_0, end_0, acc_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_0) => {
  return run_jump($f_tele_type$, [name_0, id_0, q_0, temp_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), end_0, acc_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Bool$and$((q_0 === 1), run_loop($Bool$not$(temp_0)))), run_clo((x_2) => {
  return run_jump($f_tele_type$, [name_0, id_0, 0, temp_0, {$: "FParsed", ["term"]: run_loop($atom$("Qnt")), ["rest"]: ts_0}, end_0, acc_0]);
}), run_clo((x_3) => {
  return run_jump($f_err$, [ts_0, "expected : (a marked parameter requires its type)"]);
})]);
})]);
}

function $f_type_kind$(name_0, pars_0, p_0, book_0, imports_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, ty_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_type_ctors$, [name_0, pars_0, ty_0, run_loop($f_skip$(ts_0)), book_0, imports_0, {$: "Nil"}]);
})]);
}

function $f_expect$(p_0, s_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  const x_0 = run_loop($f_eq$(run_loop($tg$(n_0)), "Error"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), s_0));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_3) => {
  const x_4 = run_loop($f_eq$(s_0, ")"));
  const x_5 = run_loop($f_eq$(s_0, "}"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($f_eq$(s_0, "]"));
  return run_jump($f_choose$, [(x_6 || x_7), run_clo((x_8) => {
  const x_9 = (s_0 + "'");
  return run_jump($fpe_error$, [ts_0, ("expected " + s_0), ("'" + x_9)]);
}), run_clo((x_10) => {
  return run_jump($f_err$, [ts_0, ("expected " + s_0)]);
})]);
})]);
}

function $fpe_defs$(ds_0) {
  if (ds_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const head_0 = ds_0["head"];
    const tail_0 = ds_0["tail"];
    return run_jump($fpe_defs_next$, [run_loop($fpe_def$(head_0)), tail_0]);
  }
}

function $fpe_terms_next$(error_0, rest_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(error_0)), "Absent")), run_clo((x_0) => {
  return run_jump($fpe_terms$, [rest_0]);
}), run_clo((x_1) => {
  return error_0;
})]);
}

function $fpe_term$(t_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($String$is_empty$(run_loop($nm$(t_0)))), run_clo((x_1) => {
  return run_jump($atom$, ["Absent"]);
}), run_clo((x_2) => {
  return t_0;
})]);
}), run_clo((x_3) => {
  return run_jump($fpe_terms$, [run_loop($ks$(t_0))]);
})]);
}

function $f_graph_finish_alias$(s_0, ns_0, book_0, imports_0, prior_0, err_0, done_0) {
  return {$: "FGraph", ["book"]: run_loop($f_defs_append$(prior_0, run_loop($f_path_defs$(run_loop($f_module_defs$(book_0, {$: "Nil"}, run_loop($f_family_book$(prior_0)), ns_0, imports_0)), run_loop($f_path_dir$(run_loop($f_source_path$(s_0)))), run_loop($f_eq$(run_loop($f_source_name$(s_0)), "Base")))))), ["error"]: err_0, ["done"]: {$: "Con", ["head"]: run_loop($kt$("Loaded", run_loop($f_source_path$(s_0)), run_loop($f_graph_count_defs$(book_0, 0)), 0, {$: "Con", ["head"]: run_loop($ref$(ns_0)), ["tail"]: {$: "Nil"}})), ["tail"]: done_0}};
}

function $f_alias_defs$(ds_0, imports_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return {$: "Con", ["head"]: {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($f_alias_term$(run_loop($dt$(d_0)), imports_0)), ["value"]: run_loop($f_alias_term$(run_loop($dv$(d_0)), imports_0)), ["ctors"]: run_loop($f_alias_defs$(run_loop($dc$(d_0)), imports_0)), ["native"]: run_loop($db$(d_0)), ["unsafe"]: run_loop($du$(d_0))}, ["tail"]: run_loop($f_alias_defs$(rest_0, imports_0))};
  }
}

function $f_path_normal$(s_0) {
  return run_jump($f_path_parts$, [s_0, "", {$: "Nil"}, run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "/"))]);
}

function $f_path_join$(dir_0, path_0) {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(path_0)), "/")), run_clo((x_0) => {
  return path_0;
}), run_clo((x_1) => {
  return (dir_0 + path_0);
})]);
}

function $f_path_dir$(path_0) {
  return run_jump($f_path_scan$, [path_0, "", ""]);
}

function $f_strip_bend$(s_0) {
  return run_jump($String$reverse$, [run_loop($f_drop_chars$(run_loop($String$reverse$(s_0)), 5))]);
}

function $tele_tip_head$(book_0, t_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "All")), run_clo((x_0) => {
  return run_jump($tele_tip$, [book_0, run_loop($kid$(t_0, 1))]);
}), run_clo((x_1) => {
  return t_0;
})]);
}

function $check_ctors_next$(e_0, d_0, rest_0, kind_0, err_0) {
  return run_jump($kc$, [run_loop($String$eq$(err_0, "")), run_clo((x_0) => {
  return run_jump($check_ctors$, [e_0, d_0, rest_0, kind_0]);
}), run_clo((x_1) => {
  return err_0;
})]);
}

function $check_ctor_tel$(e_0, d_0, tel_0, kind_0, params_0, fields_0, ctx_0, args_0) {
  const x_0 = ((params_0 + fields_0) >>> 0);
  return run_jump($kc$, [(x_0 === 0), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($compare$(run_loop($cb$(e_0)), tel_0, run_loop($kt$("ADT", run_loop($dn$(d_0)), 0, 0, args_0)), false)), run_clo((x_2) => {
  return "";
}), run_clo((x_3) => {
  return "constructor result must apply family to its parameters";
})]);
}), run_clo((x_4) => {
  return run_jump($check_ctor_head$, [e_0, d_0, run_loop($wnf$(run_loop($cb$(e_0)), tel_0)), kind_0, params_0, fields_0, ctx_0, args_0]);
})]);
}

function $contains_self$(todo_0, name_0) {
  if (todo_0.$ === "Nil") {
    return false;
  } else {
    const h_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(h_0)), "Ref")), run_loop($String$eq$(run_loop($nm$(h_0)), name_0)))), run_clo((x_0) => {
    return true;
}), run_clo((x_1) => {
    return run_jump($contains_self$, [run_loop($norm_join$(run_loop($ks$(h_0)), rest_0)), name_0]);
})]);
  }
}

function $tele_quantities_head$(book_0, ty_0, n_0) {
  return {$: "Con", ["head"]: run_loop($qua$(run_loop($kc$(run_loop($String$eq$(run_loop($tg$(ty_0)), "All")), run_clo((x_0) => {
  return run_jump($qt$, [ty_0]);
}), run_clo((x_1) => {
  return 1;
}))))), ["tail"]: run_loop($tele_quantities$(book_0, run_loop($kid$(ty_0, 1)), ((n_0 - 1) >>> 0)))};
}

function $check_template_open$(book_0, d_0, ty_0, body_0, lhs_0, n_0, name_0) {
  return run_jump($check_template_definition$, [run_loop($book_put$(book_0, {$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: 0, ["templates"]: 0, ["typ"]: run_loop($kid$(ty_0, 0)), ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: true, ["unsafe"]: false})), d_0, run_loop($subst$(run_loop($kid$(ty_0, 1)), run_loop($ix$(ty_0)), run_loop($ref$(name_0)))), run_loop($kapply$(body_0, run_loop($ref$(name_0)))), run_loop($app$(lhs_0, run_loop($ref$(name_0)))), ((n_0 - 1) >>> 0)]);
}

function $String$split$push$(c_0, ps_0) {
  if (ps_0.$ === "Nil") {
    return {$: "Con", ["head"]: (c_0 + ""), ["tail"]: {$: "Nil"}};
  } else {
    const h_0 = ps_0["head"];
    const t_0 = ps_0["tail"];
    return {$: "Con", ["head"]: (c_0 + h_0), ["tail"]: t_0};
  }
}

function $fp_term$(t_0, definition_0, source_0, route_0) {
  return run_jump($List$append$, [run_loop($fp_origin$(t_0, definition_0, source_0, route_0)), run_loop($fp_children$(run_loop($ks$(t_0)), definition_0, source_0, route_0, 0))]);
}

function $fp_ctors$(ctors_0, definition_0, source_0, index_0) {
  if (ctors_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const ctor_0 = ctors_0["head"];
    const rest_0 = ctors_0["tail"];
    return run_jump($List$append$, [run_loop($fp_term$(run_loop($dt$(ctor_0)), definition_0, source_0, {$: "Con", ["head"]: 2, ["tail"]: {$: "Con", ["head"]: index_0, ["tail"]: {$: "Con", ["head"]: 0, ["tail"]: {$: "Nil"}}}})), run_loop($fp_ctors$(rest_0, definition_0, source_0, ((index_0 + 1) >>> 0)))]);
  }
}

function $core_subst_stable_app_kids$(kids_0) {
  if (kids_0.$ === "Nil") {
    return false;
  } else {
    const f_0 = kids_0["head"];
    const tail_0 = kids_0["tail"];
    return run_jump($core_subst_stable_app_tail$, [f_0, tail_0]);
  }
}

function $ka_spine_step$(e_0, ctx_0, arg_0, node_0, fty_0) {
  return {$: "KAnnotatedSpine", ["node"]: run_loop($ka_app_spine_root$(e_0, ctx_0, arg_0, node_0, fty_0)), ["typ"]: run_loop($subst$(run_loop($kid$(fty_0, 1)), run_loop($ix$(fty_0)), arg_0))};
}

function $ka_args_static$(e_0, ctx_0, tel_0, xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
    return {$: "Con", ["head"]: run_loop($annotate$(e_0, ctx_0, h_0, run_loop($kid$(tel_0, 0)))), ["tail"]: run_loop($ka_args_static$(e_0, ctx_0, run_loop($kid$(tel_0, 1)), rest_0))};
}), run_clo((x_1) => {
    return run_jump($ka_args_cached$, [e_0, ctx_0, tel_0, {$: "Con", ["head"]: h_0, ["tail"]: rest_0}]);
})]);
  }
}

function $ka_args$(e_0, ctx_0, tel_0, xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($ka_args_head$, [e_0, ctx_0, run_loop($wnf$(run_loop($cb$(e_0)), tel_0)), h_0, rest_0]);
  }
}

function $String$contains$if$(t_0, p_0, here_0) {
  if (!here_0) {
    return run_jump($String$contains$, [t_0, p_0]);
  } else {
    return true;
  }
}

function $Nat$show$fin$(g_0, acc_0, dq_0) {
  const d_0 = dq_0["fst"];
  const _t_0 = dq_0["snd"];
  if (_t_0 === 0n) {
    return (d_0 + acc_0);
  } else {
    const p_0 = (_t_0 - 1n);
    return run_jump($Nat$show$go$, [g_0, nat_chk(p_0 + 1n), (d_0 + acc_0)]);
  }
}

function $Nat$show$put$(qr_0) {
  const q_0 = qr_0["fst"];
  const r_0 = qr_0["snd"];
  const x_0 = nat_chk(48n + r_0);
  return {$: "Tuple", ["fst"]: char_new(Number(x_0 & 0xFFFFFFFFn)), ["snd"]: q_0};
}

function $kp_list$(chain_0, p_0, env_0) {
  const xs_0 = chain_0["items"];
  const t_0 = chain_0["tail"];
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "Nil")), run_clo((x_0) => {
  const x_1 = run_loop($kp_join$(run_loop($kp_each$(xs_0, 1, env_0)), ", "));
  const x_2 = (x_1 + "]");
  return ("[" + x_2);
}), run_clo((x_3) => {
  const x_4 = run_loop($kp_go$(t_0, 2, env_0));
  const x_5 = run_loop($kp_join$(run_loop($kp_each$(xs_0, 3, env_0)), " <> "));
  const x_6 = (" <> " + x_4);
  return run_jump($kp_par$, [(x_5 + x_6), (p_0 > 2)]);
})]);
}

function $kp_chain$(t_0, name_0, arity_0, acc_0) {
  const x_0 = run_loop($terms_len$(run_loop($ks$(t_0))));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($kp_is$(t_0, "Ctr", name_0)), (x_0 === arity_0))), run_clo((x_1) => {
  return run_jump($kp_chain$, [run_loop($kid$(t_0, ((arity_0 - 1) >>> 0))), name_0, arity_0, {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: acc_0}]);
}), run_clo((x_2) => {
  return {$: "KPChain", ["items"]: run_loop($List$reverse$(acc_0)), ["tail"]: t_0};
})]);
}

function $kp_tuple$(chain_0, env_0) {
  const xs_0 = chain_0["items"];
  const t_0 = chain_0["tail"];
  const x_0 = run_loop($kp_go$(t_0, 1, env_0));
  const x_1 = (x_0 + ")");
  const x_2 = run_loop($kp_join$(run_loop($kp_each$(xs_0, 1, env_0)), ", "));
  const x_3 = (", " + x_1);
  const x_4 = (x_2 + x_3);
  return ("(" + x_4);
}

function $kp_ctor_array$(a_0, t_0, env_0) {
  if (a_0.$ === "Some") {
    const xs_0 = a_0["value"];
    const x_0 = run_loop($kp_join$(run_loop($kp_each$(xs_0, 1, env_0)), ", "));
    const x_1 = (x_0 + "]");
    return ("[" + x_1);
  } else {
    const x_2 = run_loop($kp_join$(run_loop($kp_each$(run_loop($ks$(t_0)), 1, env_0)), ", "));
    const x_3 = (x_2 + "}");
    const x_4 = run_loop($nm$(t_0));
    const x_5 = ("{" + x_3);
    return (x_4 + x_5);
  }
}

function $kp_array$(t_0) {
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "ALeaf")), run_clo((x_0) => {
  return {$: "Some", ["value"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}}};
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($kp_is$(t_0, "Ctr", "ANode")), run_clo((x_2) => {
  return run_jump($kp_array_join$, [run_loop($kp_array$(run_loop($kid$(t_0, 0)))), run_loop($kp_array$(run_loop($kid$(t_0, 1))))]);
}), run_clo((x_3) => {
  return {$: "None"};
})]);
})]);
}

function $kp_append$(a_0, b_0) {
  if (a_0.$ === "Some") {
    const x_0 = a_0["value"];
    if (b_0.$ === "Some") {
      const y_0 = b_0["value"];
      return {$: "Some", ["value"]: (x_0 + y_0)};
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $kp_escape$(n_0, quote_0) {
  return run_jump($kc$, [(n_0 === 10), run_clo((x_0) => {
  return "\\n";
}), run_clo((x_1) => {
  return run_jump($kc$, [(n_0 === 9), run_clo((x_2) => {
  return "\\t";
}), run_clo((x_3) => {
  return run_jump($kc$, [(n_0 === 13), run_clo((x_4) => {
  return "\\r";
}), run_clo((x_5) => {
  return run_jump($kc$, [(n_0 === 0), run_clo((x_6) => {
  return "\\0";
}), run_clo((x_7) => {
  return run_jump($kc$, [(n_0 === 92), run_clo((x_8) => {
  return "\\\\";
}), run_clo((x_9) => {
  return run_jump($kc$, [(n_0 === quote_0), run_clo((x_10) => {
  const x_11 = run_loop($Char$show$(run_loop($Char$from_u32$(n_0))));
  return ("\\" + x_11);
}), run_clo((x_12) => {
  const x_13 = (n_0 < 32);
  const x_14 = (n_0 === 127);
  const x_15 = (x_13 || x_14);
  const x_16 = run_loop($Bool$and$((n_0 >= 55296), (n_0 <= 57343)));
  const x_17 = (x_15 || x_16);
  const x_18 = (n_0 > 1114111);
  return run_jump($kc$, [(x_17 || x_18), run_clo((x_19) => {
  const x_20 = run_loop($kp_hex$(n_0));
  const x_21 = (x_20 + "}");
  return ("\\u{" + x_21);
}), run_clo((x_22) => {
  return run_jump($Char$show$, [run_loop($Char$from_u32$(n_0))]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $sp_template_checked$(st_0, d_0, closed_0, rest_0, ctx_0, owner_0, depth_0, checked_0) {
  return run_jump($kc$, [run_loop($good$(checked_0)), run_clo((x_0) => {
  return run_jump($sp_template_key$, [st_0, d_0, closed_0, rest_0, ctx_0, owner_0, depth_0, run_loop($sp_keys$(closed_0))]);
}), run_clo((x_1) => {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, run_loop($ce$(checked_0)))), ["term"]: run_loop($norm_apply$(run_loop($ref$(run_loop($dn$(d_0)))), run_loop($norm_join$(closed_0, rest_0))))};
})]);
}

function $sp_take_next$(ts_0, n_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($sp_take$(rest_0, ((n_0 - 1) >>> 0)))};
  }
}

function $sp_drop_next$(ts_0, n_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($sp_drop$, [rest_0, ((n_0 - 1) >>> 0)]);
  }
}

function $sp_apply_result$(head_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_states$(r_0)), ["term"]: run_loop($norm_apply$(head_0, run_loop($sp_values$(r_0))))};
}

function $sp_pair$(t_0, h_0, r_0) {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_state$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: {$: "Con", ["head"]: h_0, ["tail"]: {$: "Con", ["head"]: run_loop($sp_value$(r_0)), ["tail"]: {$: "Nil"}}}, ["removed"]: run_loop($rm$(t_0))}};
}

function $g_put_node$(old_0, left_0, right_0, id_0, value_0) {
  return run_jump($kc$, [(id_0 === 0), run_clo((x_0) => {
  return {$: "GNode", ["value"]: value_0, ["left"]: left_0, ["right"]: right_0};
}), run_clo((x_1) => {
  const x_2 = ((id_0 & 1) >>> 0);
  return run_jump($kc$, [(x_2 === 0), run_clo((x_3) => {
  return {$: "GNode", ["value"]: old_0, ["left"]: run_loop($g_put$(left_0, ((id_0 >>> 1) >>> 0), value_0)), ["right"]: right_0};
}), run_clo((x_4) => {
  return {$: "GNode", ["value"]: old_0, ["left"]: left_0, ["right"]: run_loop($g_put$(right_0, ((id_0 >>> 1) >>> 0), value_0))};
})]);
})]);
}

function $g_resume$(book_0, st_0, t_0, frame_0, stack_0) {
  if (frame_0.$ === "GFill") {
    const id_0 = frame_0["id"];
    const args_0 = frame_0["args"];
    const pending_0 = frame_0["pending"];
    const fallback_0 = frame_0["fallback"];
    return run_jump($g_filled$, [book_0, id_0, args_0, pending_0, fallback_0, stack_0, run_loop($g_share_head$(st_0, t_0))]);
  } else if (frame_0.$ === "GMatch") {
    const arm_0 = frame_0["arm"];
    const raw_0 = frame_0["raw"];
    const args_1 = frame_0["args"];
    const pending_1 = frame_0["pending"];
    const fallback_1 = frame_0["fallback"];
    return run_jump($g_match$, [book_0, st_0, arm_0, arm_0, raw_0, t_0, args_1, pending_1, fallback_1, stack_0]);
  } else if (frame_0.$ === "GMinA") {
    const other_0 = frame_0["other"];
    const args_2 = frame_0["args"];
    return run_jump($g_min_left$, [book_0, st_0, t_0, other_0, args_2, stack_0]);
  } else if (frame_0.$ === "GMinB") {
    const other_1 = frame_0["other"];
    const args_3 = frame_0["args"];
    return run_jump($g_return$, [book_0, st_0, run_loop($norm_apply$(run_loop($norm_min_right$(other_1, t_0)), args_3)), stack_0]);
  } else {
    const original_0 = frame_0["original"];
    const args_4 = frame_0["args"];
    const pending_2 = frame_0["pending"];
    const fallback_2 = frame_0["fallback"];
    return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(t_0)), "Rfl")), run_clo((x_0) => {
    return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(original_0, 2)), args_4, pending_2, fallback_2, stack_0]);
}), run_clo((x_1) => {
    return run_jump($g_return$, [book_0, st_0, run_loop($norm_apply$(original_0, args_4)), stack_0]);
})]);
  }
}

function $fpe_pad$(text_0, width_0) {
  const x_0 = BigInt([...text_0].length);
  const x_1 = Number(x_0 & 0xFFFFFFFFn);
  return run_jump($f_choose$, [(x_1 < width_0), run_clo((x_2) => {
  return run_jump($fpe_pad$, [(" " + text_0), width_0]);
}), run_clo((x_3) => {
  return text_0;
})]);
}

function $f_alias_valid$(s_0) {
  const x_0 = run_loop($Char$is_alpha$(run_loop($f_head$(s_0))));
  const x_1 = run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "_"));
  return run_jump($Bool$and$, [run_loop($Bool$and$((x_0 || x_1), run_loop($f_alias_chars$(s_0)))), run_loop($Bool$not$(run_loop($f_reserved$(s_0))))]);
}

function $f_law_where$(name_0, binder_0, ty_0, p_0, book_0, imports_0, clauses_0) {
  const predicate_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_law_type$, [name_0, binder_0, {$: "FParsed", ["term"]: run_loop($f_app$(run_loop($ref$("Exists")), {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Lam", run_loop($nm$(binder_0)), run_loop($ix$(binder_0)), 1, {$: "Con", ["head"]: predicate_0, ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}}})), ["rest"]: ts_0}, book_0, imports_0, clauses_0]);
}

function $f_app$(f_0, xs_0) {
  if (xs_0.$ === "Nil") {
    return f_0;
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return run_jump($f_app$, [run_loop($kt$("App", "", 0, 1, {$: "Con", ["head"]: f_0, ["tail"]: {$: "Con", ["head"]: x_0, ["tail"]: {$: "Nil"}}})), xt_0]);
  }
}

function $f_prec$(s_0) {
  const x_0 = run_loop($f_eq$(s_0, "=>"));
  const x_1 = run_loop($f_eq$(s_0, "->"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return 1;
}), run_clo((x_3) => {
  const x_4 = run_loop($f_eq$(s_0, "&"));
  const x_5 = run_loop($f_eq$(s_0, "|"));
  return run_jump($f_choose$, [(x_4 || x_5), run_clo((x_6) => {
  return 2;
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "||")), run_clo((x_8) => {
  return 3;
}), run_clo((x_9) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "&&")), run_clo((x_10) => {
  return 4;
}), run_clo((x_11) => {
  const x_12 = run_loop($f_eq$(s_0, "<"));
  const x_13 = run_loop($f_eq$(s_0, ">op"));
  const x_14 = (x_12 || x_13);
  const x_15 = run_loop($f_eq$(s_0, "<="));
  const x_16 = (x_14 || x_15);
  const x_17 = run_loop($f_eq$(s_0, ">="));
  return run_jump($f_choose$, [(x_16 || x_17), run_clo((x_18) => {
  return 5;
}), run_clo((x_19) => {
  const x_20 = run_loop($f_eq$(s_0, "<>"));
  const x_21 = run_loop($f_eq$(s_0, "++"));
  const x_22 = (x_20 || x_21);
  const x_23 = run_loop($f_eq$(s_0, "<&>"));
  return run_jump($f_choose$, [(x_22 || x_23), run_clo((x_24) => {
  return 6;
}), run_clo((x_25) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".|.")), run_clo((x_26) => {
  return 7;
}), run_clo((x_27) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".^.")), run_clo((x_28) => {
  return 8;
}), run_clo((x_29) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".&.")), run_clo((x_30) => {
  return 9;
}), run_clo((x_31) => {
  const x_32 = run_loop($f_eq$(s_0, "<<"));
  const x_33 = run_loop($f_eq$(s_0, ">>op"));
  return run_jump($f_choose$, [(x_32 || x_33), run_clo((x_34) => {
  return 10;
}), run_clo((x_35) => {
  const x_36 = run_loop($f_eq$(s_0, "+"));
  const x_37 = run_loop($f_eq$(s_0, "-"));
  return run_jump($f_choose$, [(x_36 || x_37), run_clo((x_38) => {
  return 11;
}), run_clo((x_39) => {
  const x_40 = run_loop($f_eq$(s_0, "*"));
  const x_41 = run_loop($f_eq$(s_0, "/"));
  const x_42 = (x_40 || x_41);
  const x_43 = run_loop($f_eq$(s_0, "%"));
  return run_jump($f_choose$, [(x_42 || x_43), run_clo((x_44) => {
  return 12;
}), run_clo((x_45) => {
  return 0;
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_grow_base$(p_0, min_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  const x_2 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "("));
  const x_3 = run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<")), run_loop($Char$is_upper$(run_loop($f_head$(run_loop($nm$(n_0))))))));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($f_grow_args$, [n_0, run_loop($f_tx$(ts_0)), min_0, run_loop($f_args$(run_loop($f_tl$(ts_0)), run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "(")), run_clo((x_5) => {
  return ")";
}), run_clo((x_6) => {
  return ">";
}))), {$: "Nil"}))]);
}), run_clo((x_7) => {
  const x_8 = run_loop($f_prec$(run_loop($f_tx$(ts_0))));
  const x_9 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "%"));
  const x_10 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "-"));
  const x_11 = run_loop($f_col$(ts_0));
  const x_12 = run_loop($f_col$(run_loop($f_tl$(ts_0))));
  const x_13 = ((x_11 + 1) >>> 0);
  const x_14 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), ")"));
  const x_15 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "}"));
  const x_16 = (x_14 || x_15);
  const x_17 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), ","));
  const x_18 = (x_16 || x_17);
  const x_19 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), ":"));
  const x_20 = (x_18 || x_19);
  const x_21 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), ">"));
  const x_22 = (x_20 || x_21);
  const x_23 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "\n"));
  const x_24 = (x_22 || x_23);
  const x_25 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "->"));
  const x_26 = (x_24 || x_25);
  const x_27 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "<eof>"));
  const x_28 = (x_26 || x_27);
  const x_29 = run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "]"));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$((x_8 > min_0), run_loop($Bool$not$(run_loop($Bool$and$(run_loop($Bool$and$((x_9 || x_10), (x_12 === x_13))), run_loop($Char$is_alpha$(run_loop($f_head$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))))))))))), run_loop($Bool$not$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ">")))))), run_loop($Bool$not$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ">>")), (x_28 || x_29))))))), run_clo((x_30) => {
  const x_31 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=>"));
  const x_32 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "->"));
  const x_33 = (x_31 || x_32);
  const x_34 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<>"));
  const x_35 = (x_33 || x_34);
  const x_36 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "&"));
  const x_37 = (x_35 || x_36);
  const x_38 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "|"));
  return run_jump($f_binary$, [n_0, run_loop($f_tx$(ts_0)), min_0, run_loop($f_rhs$(run_loop($f_tl$(ts_0)), run_loop($f_tx$(ts_0)), run_loop($f_choose$((x_37 || x_38), run_clo((x_39) => {
  const x_40 = run_loop($f_prec$(run_loop($f_tx$(ts_0))));
  return ((x_40 - 1) >>> 0);
}), run_clo((x_41) => {
  return run_jump($f_prec$, [run_loop($f_tx$(ts_0))]);
})))))]);
}), run_clo((x_42) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
})]);
})]);
})]);
}

function $f_bang$(n_0, ts_0, min_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(n_0)), "Ref")), run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "(")))), run_clo((x_0) => {
  return run_jump($f_grow$, [{$: "FParsed", ["term"]: run_loop($kt$("Ref", run_loop($nm$(n_0)), run_loop($ix$(n_0)), 3, run_loop($ks$(n_0)))), ["rest"]: run_loop($f_tl$(ts_0))}, min_0]);
}), run_clo((x_1) => {
  return run_jump($f_err$, [ts_0, "! must follow a named definition and precede call parentheses"]);
})]);
}

function $f_index$(n_0, p_0, min_0) {
  const idx_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<-")), run_clo((x_0) => {
  return run_jump($f_index_value$, [n_0, idx_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 2)), min_0]);
}), run_clo((x_1) => {
  return run_jump($f_grow$, [{$: "FParsed", ["term"]: run_loop($f_app$(run_loop($ref$("Array.get")), {$: "Con", ["head"]: run_loop($ref$("U32")), ["tail"]: {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_namespace$(idx_0, run_loop($ref$("U32")))), ["tail"]: {$: "Nil"}}}})), ["rest"]: ts_0}, min_0]);
})]);
}

function $f_template_expr$(p_0) {
  const t_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("TemplateArg", "", 0, 0, {$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}})), ["rest"]: ts_0};
}

function $f_do_start$(ts_0) {
  return run_jump($f_do_named$, [run_loop($f_space$(ts_0))]);
}

function $f_rewrite$(ts_0) {
  return run_jump($f_rewrite_head$, [run_loop($f_expr$(ts_0, 0))]);
}

function $f_atom_base$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "(")), run_clo((x_0) => {
  return run_jump($f_group$, [run_loop($f_body$(run_loop($f_tl$(ts_0))))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "{")), run_clo((x_2) => {
  return run_jump($f_brace$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "[")), run_clo((x_4) => {
  return run_jump($f_array$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "@")), run_clo((x_6) => {
  return run_jump($f_all$, [run_loop($f_tl$(ts_0)), false]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "&")), run_clo((x_8) => {
  return run_jump($f_grade$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_9) => {
  const x_10 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "+"));
  const x_11 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "+bind"));
  return run_jump($f_choose$, [(x_10 || x_11), run_clo((x_12) => {
  return run_jump($f_mark$, [run_loop($f_atom$(run_loop($f_tl$(ts_0)))), 2]);
}), run_clo((x_13) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "?")), run_clo((x_14) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Hol", run_loop($f_tx$(run_loop($f_tl$(ts_0)))), 0, 0, {$: "Nil"})), ["rest"]: run_loop($f_tl$(run_loop($f_tl$(ts_0))))};
}), run_clo((x_15) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "\\")), run_clo((x_16) => {
  return run_jump($f_matcher$, [run_loop($f_tl$(run_loop($f_tl$(ts_0))))]);
}), run_clo((x_17) => {
  const x_18 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "Type"));
  const x_19 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "Data"));
  return run_jump($f_choose$, [(x_18 || x_19), run_clo((x_20) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: run_loop($kt$("Qua", "", 0, run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "Data")), run_clo((x_21) => {
  return 2;
}), run_clo((x_22) => {
  return 1;
}))), {$: "Nil"})), ["tail"]: {$: "Nil"}})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_23) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "Quant")), run_clo((x_24) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Qnt", "", 0, 0, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_25) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "Kind")), run_clo((x_26) => {
  return run_jump($f_kind_wrap$, [run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))), 0)), ")"))]);
}), run_clo((x_27) => {
  const x_28 = run_loop($f_kind_token$(ts_0));
  return run_jump($f_choose$, [(x_28 === 2), run_clo((x_29) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Literal", run_loop($f_tx$(ts_0)), 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_30) => {
  const x_31 = run_loop($f_kind_token$(ts_0));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_31 === 1), run_loop($Bool$not$(run_loop($f_reserved$(run_loop($f_tx$(ts_0)))))))), run_clo((x_32) => {
  return run_jump($f_atom_name$, [ts_0]);
}), run_clo((x_33) => {
  return run_jump($f_choose$, [run_loop($f_reserved$(run_loop($f_tx$(ts_0)))), run_clo((x_34) => {
  return run_jump($f_err$, [ts_0, "expected term"]);
}), run_clo((x_35) => {
  return run_jump($fpe_error$, [ts_0, "expected term", "a term"]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_foreign$(name_0, pars_0, ty_0, ts_0, book_0, imports_0, unsafe_0, paths_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "import")), run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($f_foreign_path_valid$(ts_0)), run_clo((x_1) => {
  return run_jump($f_foreign$, [name_0, pars_0, ty_0, run_loop($f_skip$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))))), book_0, imports_0, unsafe_0, {$: "Con", ["head"]: run_loop($kt$("Path", run_loop($f_unquote$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))), 0, 0, {$: "Nil"})), ["tail"]: paths_0}]);
}), run_clo((x_2) => {
  return run_jump($f_result$, [book_0, run_loop($fpe_foreign$(run_loop($f_space$(run_loop($f_tl$(ts_0)))))), imports_0]);
})]);
}), run_clo((x_3) => {
  return run_jump($f_tops$, [ts_0, run_loop($f_put$({$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: run_loop($f_len$(pars_0)), ["templates"]: 0, ["typ"]: ty_0, ["value"]: run_loop($kt$("Foreign", name_0, 0, 0, run_loop($List$reverse$(paths_0)))), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: unsafe_0}, book_0)), imports_0, false]);
})]);
}

function $f_def_signature$(name_0, pars_0, ty_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_dk$(run_loop($f_find$(name_0, book_0)))), "Missing")), run_clo((x_0) => {
  return run_jump($f_tbind$, [pars_0, ty_0]);
}), run_clo((x_1) => {
  return ty_0;
})]);
}

function $f_def_body$(name_0, pars_0, ty_0, p_0, book_0, imports_0, unsafe_0) {
  const body_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(body_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, body_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_tops$, [ts_0, run_loop($f_put$({$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: run_loop($f_len$(pars_0)), ["templates"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($f_dk$(run_loop($f_find$(name_0, book_0)))), "Missing")), run_clo((x_2) => {
  return run_jump($f_templates$, [pars_0]);
}), run_clo((x_3) => {
  return run_jump($f_dx$, [run_loop($f_find$(name_0, book_0))]);
}))), ["typ"]: ty_0, ["value"]: run_loop($kt$("Body", "", run_loop($fc_start$(pars_0, ty_0, body_0, run_loop($Bool$not$(run_loop($f_eq$(run_loop($f_dk$(run_loop($f_find$(name_0, book_0)))), "Missing")))))), 0, {$: "Con", ["head"]: run_loop($kt$("Params", "", 0, 0, pars_0)), ["tail"]: {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}})), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: unsafe_0}, book_0)), imports_0, false]);
})]);
}

function $f_body$(ts_0) {
  return run_jump($f_body_context$, [ts_0, 0]);
}

function $f_tele_type$(name_0, id_0, q_0, temp_0, p_0, end_0, acc_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: ty_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_tele$, [run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
}), run_clo((x_3) => {
  return ts_0;
}))), end_0, {$: "Con", ["head"]: run_loop($kt$(run_loop($f_choose$(temp_0, run_clo((x_4) => {
  return "Template";
}), run_clo((x_5) => {
  return "Bind";
}))), name_0, id_0, q_0, {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}})), ["tail"]: acc_0}]);
})]);
}

function $f_type_ctors$(name_0, pars_0, ty_0, ts_0, book_0, imports_0, ctors_0) {
  const x_0 = run_loop($f_col$(ts_0));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_0 > 0), run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "{")))), run_clo((x_1) => {
  const x_2 = run_loop($Bool$not$(run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(run_loop($f_tx$(ts_0)), ctors_0)))), "Missing"))));
  const x_3 = run_loop($Bool$not$(run_loop($f_eq$(run_loop($dk$(run_loop($f_ctor_lookup$(run_loop($f_tx$(ts_0)), book_0)))), "Missing"))));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  const x_5 = run_loop($f_tx$(ts_0));
  const x_6 = (x_5 + ")");
  const x_7 = run_loop($f_tx$(ts_0));
  const x_8 = (x_7 + ")");
  return run_jump($f_result$, [book_0, run_loop($f_pn$(run_loop($fpe_fresh$(ts_0, ("expected a fresh constructor name (duplicate declaration: " + x_6), ("a fresh constructor name (duplicate declaration: " + x_8))))), imports_0]);
}), run_clo((x_9) => {
  return run_jump($f_type_ctor$, [name_0, pars_0, ty_0, run_loop($f_tx$(ts_0)), run_loop($f_tele$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))), "}", {$: "Nil"})), book_0, imports_0, ctors_0]);
})]);
}), run_clo((x_10) => {
  return run_jump($f_tops$, [ts_0, {$: "Con", ["head"]: {$: "KDef", ["name"]: name_0, ["kind"]: "ADT", ["arity"]: run_loop($f_len$(pars_0)), ["templates"]: 0, ["typ"]: run_loop($f_tbind$(pars_0, ty_0)), ["value"]: run_loop($atom$("Absent")), ["ctors"]: run_loop($List$reverse$(ctors_0)), ["native"]: false, ["unsafe"]: false}, ["tail"]: book_0}, imports_0, false]);
})]);
}

function $f_path_defs$(ds_0, dir_0, native_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    const x_2 = run_loop($db$(d_0));
    return {$: "Con", ["head"]: {$: "KDef", ["name"]: run_loop($dn$(d_0)), ["kind"]: run_loop($dk$(d_0)), ["arity"]: run_loop($da$(d_0)), ["templates"]: run_loop($dx$(d_0)), ["typ"]: run_loop($dt$(d_0)), ["value"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(run_loop($dv$(d_0)))), "Foreign")), run_clo((x_0) => {
    return run_jump($f_path_term$, [run_loop($dv$(d_0)), dir_0]);
}), run_clo((x_1) => {
    return run_jump($dv$, [d_0]);
}))), ["ctors"]: run_loop($f_path_defs$(run_loop($dc$(d_0)), dir_0, native_0)), ["native"]: (native_0 || x_2), ["unsafe"]: run_loop($du$(d_0))}, ["tail"]: run_loop($f_path_defs$(rest_0, dir_0, native_0))};
  }
}

function $f_module_defs$(todo_0, visible_0, scope_0, ns_0, imports_0) {
  if (todo_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = todo_0["head"];
    const rest_0 = todo_0["tail"];
    const x_0 = run_loop($dx$(d_0));
    const x_1 = run_loop($f_eq$(run_loop($dk$(d_0)), "ADT"));
    const x_2 = (x_0 > 0);
    return run_jump($f_module_def$, [d_0, rest_0, {$: "Con", ["head"]: d_0, ["tail"]: visible_0}, run_loop($f_choose$((x_1 || x_2), run_clo((x_3) => {
    return {$: "Con", ["head"]: d_0, ["tail"]: scope_0};
}), run_clo((x_4) => {
    return scope_0;
}))), ns_0, imports_0]);
  }
}

function $f_family_book$(book_0) {
  if (book_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = book_0["head"];
    const rest_0 = book_0["tail"];
    const x_0 = run_loop($dx$(d_0));
    const x_1 = run_loop($f_eq$(run_loop($dk$(d_0)), "ADT"));
    const x_2 = (x_0 > 0);
    return run_jump($f_choose$, [(x_1 || x_2), run_clo((x_3) => {
    return {$: "Con", ["head"]: d_0, ["tail"]: run_loop($f_family_book$(rest_0))};
}), run_clo((x_4) => {
    return run_jump($f_family_book$, [rest_0]);
})]);
  }
}

function $f_alias_term$(t_0, imports_0) {
  const x_0 = run_loop($f_eq$(run_loop($tg$(t_0)), "Ref"));
  const x_1 = run_loop($f_eq$(run_loop($tg$(t_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($tg$(t_0)), "Ctr"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(run_loop($tg$(t_0)), "Mat"));
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($f_choose$((x_4 || x_5), run_clo((x_6) => {
  return run_jump($f_alias$, [run_loop($nm$(t_0)), imports_0]);
}), run_clo((x_7) => {
  return run_jump($nm$, [t_0]);
}))), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_alias_terms$(run_loop($ks$(t_0)), imports_0)), ["removed"]: run_loop($rm$(t_0))};
}

function $f_path_parts$(s_0, part_0, parts_0, abs_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return run_jump($f_path_join_parts$, [run_loop($List$reverse$(run_loop($f_path_push$(part_0, parts_0)))), run_loop($f_choose$(abs_0, run_clo((x_1) => {
  return "/";
}), run_clo((x_2) => {
  return "";
})))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "/")), run_clo((x_4) => {
  return run_jump($f_path_parts$, [run_loop($f_tail$(s_0)), "", run_loop($f_path_push$(part_0, parts_0)), abs_0]);
}), run_clo((x_5) => {
  const x_6 = (run_loop($f_head$(s_0)) + "");
  return run_jump($f_path_parts$, [run_loop($f_tail$(s_0)), (part_0 + x_6), parts_0, abs_0]);
})]);
})]);
}

function $f_path_scan$(path_0, acc_0, dir_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(path_0)), run_clo((x_0) => {
  return dir_0;
}), run_clo((x_1) => {
  const x_2 = (run_loop($f_head$(path_0)) + "");
  return run_jump($f_path_scan$, [run_loop($f_tail$(path_0)), (acc_0 + x_2), run_loop($f_choose$(run_loop($Char$is_eq$(run_loop($f_head$(path_0)), "/")), run_clo((x_3) => {
  return (acc_0 + "/");
}), run_clo((x_4) => {
  return dir_0;
})))]);
})]);
}

function $f_drop_chars$(s_0, n_0) {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_0) => {
  return s_0;
}), run_clo((x_1) => {
  return run_jump($f_drop_chars$, [run_loop($f_tail$(s_0)), ((n_0 - 1) >>> 0)]);
})]);
}

function $check_ctor_head$(e_0, d_0, tel_0, kind_0, params_0, fields_0, ctx_0, args_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(tel_0)), "All")), run_clo((x_0) => {
  const x_1 = run_loop($qt$(tel_0));
  return run_jump($check_ctor_domain$, [e_0, d_0, tel_0, kind_0, params_0, fields_0, ctx_0, args_0, run_loop($check$(e_0, ctx_0, run_loop($kid$(tel_0, 0)), 0, run_loop($kc$(run_loop($Bool$and$((params_0 === 0), (x_1 === 1))), run_clo((x_2) => {
  return kind_0;
}), run_clo((x_3) => {
  return run_jump($typ$, [run_loop($qt$(tel_0))]);
})))))]);
}), run_clo((x_4) => {
  return "constructor telescope missing a binder";
})]);
}

function $fp_origin$(t_0, definition_0, source_0, route_0) {
  const text_0 = source_0["source"];
  const tokens_0 = source_0["tokens"];
  const x_0 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ref"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(t_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr"));
  const x_4 = run_loop($ix$(t_0));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_2 || x_3), (x_4 >= 65536))), run_clo((x_5) => {
  const x_6 = run_loop($ix$(t_0));
  const x_7 = run_loop($ix$(t_0));
  return run_jump($fp_at_token$, [t_0, definition_0, text_0, run_loop($fp_find_token$(tokens_0, (65536 === 0 ? 0 : (x_6 / 65536) >>> 0), (65536 === 0 ? x_7 : x_7 % 65536))), route_0]);
}), run_clo((x_8) => {
  return {$: "Nil"};
})]);
}

function $fp_children$(terms_0, definition_0, source_0, route_0, index_0) {
  if (terms_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const term_0 = terms_0["head"];
    const rest_0 = terms_0["tail"];
    return run_jump($List$append$, [run_loop($fp_term$(term_0, definition_0, source_0, run_loop($List$append$(route_0, {$: "Con", ["head"]: index_0, ["tail"]: {$: "Nil"}})))), run_loop($fp_children$(rest_0, definition_0, source_0, route_0, ((index_0 + 1) >>> 0)))]);
  }
}

function $core_subst_stable_app_tail$(f_0, tail_0) {
  if (tail_0.$ === "Nil") {
    return false;
  } else {
    const x_0 = tail_0["head"];
    const rest_0 = tail_0["tail"];
    return run_jump($core_subst_stable_app_last$, [f_0, x_0, rest_0]);
  }
}

function $Nat$show$go$(f_0, n_0, acc_0) {
  if (f_0 === 0n) {
    return acc_0;
  } else {
    const g_0 = (f_0 - 1n);
    return run_jump($Nat$show$fin$, [g_0, acc_0, run_loop($Nat$show$put$(nat_divmod(n_0, 10n)))]);
  }
}

function $kp_array_join$(a_0, b_0) {
  if (a_0.$ === "Some") {
    const x_0 = a_0["value"];
    if (b_0.$ === "Some") {
      const y_0 = b_0["value"];
      return {$: "Some", ["value"]: run_loop($List$append$(x_0, y_0))};
    } else {
      return {$: "None"};
    }
  } else {
    return {$: "None"};
  }
}

function $kp_hex$(n_0) {
  return run_jump($kc$, [(n_0 < 16), run_clo((x_0) => {
  return run_jump($kp_digit$, [n_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($kp_hex$((16 === 0 ? 0 : (n_0 / 16) >>> 0)));
  const x_3 = run_loop($kp_digit$((16 === 0 ? n_0 : n_0 % 16)));
  return (x_2 + x_3);
})]);
}

function $sp_template_key$(st_0, d_0, closed_0, rest_0, ctx_0, owner_0, depth_0, key_0) {
  const x_0 = run_loop($sp_len$(key_0));
  return run_jump($kc$, [(x_0 > 32768), run_clo((x_1) => {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, "a comptime argument must stop growing")), ["term"]: run_loop($ref$(run_loop($dn$(d_0))))};
}), run_clo((x_2) => {
  return run_jump($sp_template_inst$, [rest_0, ctx_0, owner_0, depth_0, run_loop($sp_instance$(st_0, d_0, closed_0, owner_0, depth_0, key_0, run_loop($sp_find$(run_loop($sp_memo$(st_0)), run_loop($dn$(d_0)), key_0))))]);
})]);
}

function $sp_keys$(ts_0) {
  if (ts_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($term_key$(h_0));
    const x_1 = run_loop($sp_keys$(rest_0));
    return (x_0 + x_1);
  }
}

function $g_filled$(book_0, id_0, args_0, pending_0, fallback_0, stack_0, r_0) {
  return run_jump($g_eval$, [book_0, run_loop($g_cache$(run_loop($g_state$(r_0)), id_0, run_loop($g_term$(r_0)))), run_loop($g_term$(r_0)), args_0, pending_0, fallback_0, stack_0]);
}

function $g_share_head$(st_0, t_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(t_0)), "Ctr"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(t_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Mat"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($String$eq$(run_loop($tg$(t_0)), "Eql"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($String$eq$(run_loop($tg$(t_0)), "Min"));
  const x_8 = (x_6 || x_7);
  const x_9 = run_loop($String$eq$(run_loop($tg$(t_0)), "Typ"));
  return run_jump($kc$, [(x_8 || x_9), run_clo((x_10) => {
  return run_jump($g_shared_head$, [t_0, run_loop($g_share_terms$(st_0, run_loop($ks$(t_0)), {$: "Nil"}))]);
}), run_clo((x_11) => {
  return {$: "GResult", ["state"]: st_0, ["term"]: t_0};
})]);
}

function $g_match$(book_0, st_0, arm_0, original_0, raw_0, x_0, args_0, pending_0, fallback_0, stack_0) {
  return run_jump($kc$, [run_loop($Bool$not$(run_loop($String$eq$(run_loop($tg$(x_0)), "Ctr")))), run_clo((x_1) => {
  return run_jump($g_return$, [book_0, st_0, run_loop($norm_stuck$(original_0, raw_0, args_0, pending_0, fallback_0)), stack_0]);
}), run_clo((x_2) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Ann")), run_clo((x_3) => {
  return run_jump($g_match$, [book_0, st_0, run_loop($kid$(arm_0, 0)), original_0, raw_0, x_0, args_0, pending_0, fallback_0, stack_0]);
}), run_clo((x_4) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Mat")), run_clo((x_5) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($nm$(arm_0)), run_loop($nm$(x_0)))), run_clo((x_6) => {
  return run_jump($g_eval$, [book_0, st_0, run_loop($kid$(arm_0, 0)), run_loop($norm_join$(run_loop($ks$(x_0)), args_0)), run_loop($kc$((pending_0 === 0), run_clo((x_7) => {
  return 0;
}), run_clo((x_8) => {
  const x_9 = run_loop($norm_dec$(pending_0));
  const x_10 = run_loop($terms_len$(run_loop($ks$(x_0))));
  return ((x_9 + x_10) >>> 0);
}))), fallback_0, stack_0]);
}), run_clo((x_11) => {
  return run_jump($g_match$, [book_0, st_0, run_loop($kid$(arm_0, 1)), original_0, raw_0, x_0, args_0, pending_0, fallback_0, stack_0]);
})]);
}), run_clo((x_12) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(arm_0)), "Efq")), run_clo((x_13) => {
  return run_jump($g_return$, [book_0, st_0, run_loop($norm_stuck$(original_0, raw_0, args_0, pending_0, fallback_0)), stack_0]);
}), run_clo((x_14) => {
  return run_jump($g_eval$, [book_0, st_0, arm_0, {$: "Con", ["head"]: x_0, ["tail"]: args_0}, pending_0, fallback_0, stack_0]);
})]);
})]);
})]);
})]);
}

function $g_min_left$(book_0, st_0, a_0, b_0, args_0, stack_0) {
  const x_0 = run_loop($qt$(a_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")), (x_0 === 2))), run_clo((x_1) => {
  return run_jump($g_eval$, [book_0, st_0, b_0, args_0, 0, run_loop($atom$("Absent")), stack_0]);
}), run_clo((x_2) => {
  const x_3 = run_loop($qt$(a_0));
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($tg$(a_0)), "Qua")), (x_3 === 0))), run_clo((x_4) => {
  return run_jump($g_return$, [book_0, st_0, run_loop($norm_apply$(a_0, args_0)), stack_0]);
}), run_clo((x_5) => {
  return run_jump($g_eval$, [book_0, st_0, b_0, {$: "Nil"}, 0, run_loop($atom$("Absent")), {$: "Con", ["head"]: {$: "GMinB", ["other"]: a_0, ["args"]: args_0}, ["tail"]: stack_0}]);
})]);
})]);
}

function $f_alias_chars$(s_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  const x_2 = run_loop($Char$is_alpha$(run_loop($f_head$(s_0))));
  const x_3 = run_loop($Char$is_digit$(run_loop($f_head$(s_0))));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "_"));
  return run_jump($Bool$and$, [(x_4 || x_5), run_loop($f_alias_chars$(run_loop($f_tail$(s_0))))]);
})]);
}

function $f_grow_args$(n_0, op_0, min_0, p_0) {
  const args_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(args_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: args_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_grow$, [{$: "FParsed", ["term"]: run_loop($f_choose$(run_loop($f_eq$(op_0, "(")), run_clo((x_2) => {
  return run_jump($kt$, ["Call", "", 0, 1, {$: "Con", ["head"]: n_0, ["tail"]: run_loop($ks$(args_0))}]);
}), run_clo((x_3) => {
  return run_jump($kt$, ["ADT", run_loop($nm$(n_0)), run_loop($ix$(n_0)), run_loop($qt$(n_0)), run_loop($ks$(args_0))]);
}))), ["rest"]: ts_0}, min_0]);
})]);
}

function $f_args$(ts_0, end_0, acc_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(end_0, ">")), run_loop($f_eq$(run_loop($f_tx$(ts_0)), ">>")))), run_clo((x_0) => {
  const x_1 = run_loop($f_col$(ts_0));
  return {$: "FParsed", ["term"]: run_loop($kt$("Args", "", 0, 1, run_loop($List$reverse$(acc_0)))), ["rest"]: {$: "Con", ["head"]: {$: "FToken", ["text"]: ">", ["f_line"]: run_loop($f_line$(ts_0)), ["f_col"]: ((x_1 + 1) >>> 0), ["f_kind"]: 0}, ["tail"]: run_loop($f_tl$(ts_0))}};
}), run_clo((x_2) => {
  return run_jump($f_args_base$, [ts_0, end_0, acc_0]);
})]);
}

function $f_binary$(a_0, op_0, min_0, p_0) {
  const b_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_grow$, [{$: "FParsed", ["term"]: run_loop($f_binary_plain$(a_0, op_0, b_0)), ["rest"]: ts_0}, min_0]);
}

function $f_rhs$(ts_0, op_0, min_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(op_0, "=>")), run_clo((x_0) => {
  return run_jump($f_body$, [ts_0]);
}), run_clo((x_1) => {
  return run_jump($f_expr$, [ts_0, min_0]);
})]);
}

function $f_index_value$(n_0, idx_0, p_0, min_0) {
  const v_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_grow$, [{$: "FParsed", ["term"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(n_0)), "Ref")), run_clo((x_0) => {
  return run_jump($kt$, ["Write", run_loop($nm$(n_0)), run_loop($ix$(n_0)), 1, {$: "Con", ["head"]: run_loop($f_app$(run_loop($ref$("Array.set")), {$: "Con", ["head"]: run_loop($ref$("U32")), ["tail"]: {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_namespace$(idx_0, run_loop($ref$("U32")))), ["tail"]: {$: "Con", ["head"]: v_0, ["tail"]: {$: "Nil"}}}}})), ["tail"]: {$: "Nil"}}]);
}), run_clo((x_1) => {
  return run_jump($f_app$, [run_loop($ref$("Array.set")), {$: "Con", ["head"]: run_loop($ref$("U32")), ["tail"]: {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_namespace$(idx_0, run_loop($ref$("U32")))), ["tail"]: {$: "Con", ["head"]: v_0, ["tail"]: {$: "Nil"}}}}}]);
}))), ["rest"]: ts_0}, min_0]);
}

function $f_namespace$(t_0, ty_0) {
  const x_0 = run_loop($f_eq$(run_loop($tg$(t_0)), "Local"));
  const x_1 = run_loop($f_eq$(run_loop($tg$(t_0)), "Parallel"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($kt$, [run_loop($tg$(t_0)), run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Con", ["head"]: run_loop($f_namespace$(run_loop($kid$(t_0, 2)), ty_0)), ["tail"]: {$: "Nil"}}}}]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(t_0)), "Ref")), run_loop($Char$is_eq$(run_loop($f_head$(run_loop($nm$(t_0)))), ".")))), run_clo((x_4) => {
  const x_5 = run_loop($nm$(run_loop($f_namespace_head$(ty_0))));
  const x_6 = run_loop($nm$(t_0));
  return run_jump($ref$, [(x_5 + x_6)]);
}), run_clo((x_7) => {
  const x_8 = run_loop($f_eq$(run_loop($tg$(t_0)), "App"));
  const x_9 = run_loop($f_eq$(run_loop($tg$(t_0)), "Call"));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_8 || x_9), run_loop($f_namespace_operator$(run_loop($f_namespace_head$(t_0)))))), run_clo((x_10) => {
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_namespace_terms$(run_loop($ks$(t_0)), ty_0)), ["removed"]: run_loop($rm$(t_0))};
}), run_clo((x_11) => {
  return t_0;
})]);
})]);
})]);
}

function $f_do_named$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_valid_name$(run_loop($f_tx$(ts_0)))), run_clo((x_0) => {
  return run_jump($f_do_parameters$, [run_loop($f_tx$(ts_0)), run_loop($f_space$(run_loop($f_tl$(ts_0))))]);
}), run_clo((x_1) => {
  return run_jump($f_err$, [ts_0, "expected a name"]);
})]);
}

function $f_space$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "\n")), run_clo((x_0) => {
  return run_jump($f_space$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_1) => {
  return ts_0;
})]);
}

function $f_rewrite_head$(p_0) {
  const e_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "@")), run_clo((x_0) => {
  return run_jump($f_rewrite_proof$, [run_loop($nm$(e_0)), run_loop($ix$(e_0)), run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), ":"))]);
}), run_clo((x_1) => {
  return run_jump($f_rewrite_proof$, ["", run_loop($ix$(e_0)), run_loop($f_expect$({$: "FParsed", ["term"]: e_0, ["rest"]: ts_0}, ":"))]);
})]);
}

function $f_group$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_0) => {
  return run_jump($f_tuple$, [n_0, run_loop($f_group$(run_loop($f_body$(run_loop($f_tl$(ts_0))))))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_2) => {
  return run_jump($f_group_namespace$, [n_0, run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), ")"))]);
}), run_clo((x_3) => {
  return run_jump($f_expect$, [{$: "FParsed", ["term"]: n_0, ["rest"]: ts_0}, ")"]);
})]);
})]);
}

function $f_brace$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "==")), run_clo((x_0) => {
  return run_jump($f_expect$, [{$: "FParsed", ["term"]: run_loop($kt$("Rfl", "", 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))}, "}"]);
}), run_clo((x_1) => {
  return run_jump($f_brace_left$, [run_loop($f_expr$(ts_0, 0))]);
})]);
}

function $f_array$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ";")), run_clo((x_0) => {
  return run_jump($f_err$, [ts_0, "expected term; a list does not use semicolon separators"]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "]")), run_clo((x_2) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Ctr", "Nil", 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_3) => {
  return run_jump($f_array_first$, [run_loop($f_expr$(ts_0, 0))]);
})]);
})]);
}

function $f_all$(ts_0, exi_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "~")), run_clo((x_0) => {
  return run_jump($f_err$, [ts_0, "~ is only allowed on leading def or law template parameters"]);
}), run_clo((x_1) => {
  return run_jump($f_all_domain$, [run_loop($f_tx$(run_loop($f_unmark$(ts_0)))), run_loop($f_atid$(ts_0)), run_loop($f_quant$(ts_0)), exi_0, run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(run_loop($f_tl$(run_loop($f_unmark$(ts_0)))))), 1)), "->"))]);
})]);
}

function $f_grade$(ts_0) {
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "0"));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "1"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "2"));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Qua", "", 0, run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "0")), run_clo((x_5) => {
  return 0;
}), run_clo((x_6) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "1")), run_clo((x_7) => {
  return 1;
}), run_clo((x_8) => {
  return 2;
})]);
}))), {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_9) => {
  return run_jump($f_all$, [ts_0, true]);
})]);
}

function $f_mark$(p_0, q_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  const x_0 = run_loop($f_eq$(run_loop($tg$(n_0)), "Ref"));
  const x_1 = run_loop($f_eq$(run_loop($tg$(n_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($tg$(n_0)), "Error"));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return {$: "FParsed", ["term"]: run_loop($kt$(run_loop($tg$(n_0)), run_loop($nm$(n_0)), run_loop($ix$(n_0)), q_0, run_loop($ks$(n_0)))), ["rest"]: ts_0};
}), run_clo((x_5) => {
  return run_jump($f_err$, [ts_0, "+ requires a binder or quantified datatype"]);
})]);
}

function $f_matcher$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "}")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Efq", "", 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
}), run_clo((x_1) => {
  return run_jump($f_matcher_head$, [run_loop($f_expr$(ts_0, 0))]);
})]);
}

function $f_kind_wrap$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Typ", "", 0, 0, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Nil"}})), ["rest"]: ts_0};
}

function $f_kind_token$(ts_0) {
  return run_jump($f_kind$, [ts_0]);
}

function $f_atom_name$(ts_0) {
  return run_jump($f_choose$, [run_loop($Char$is_digit$(run_loop($f_head$(run_loop($f_tx$(ts_0)))))), run_clo((x_0) => {
  const x_1 = run_loop($f_line$(ts_0));
  const x_2 = run_loop($f_line$(run_loop($f_tl$(ts_0))));
  const x_3 = run_loop($f_tx$(ts_0));
  const x_4 = BigInt([...x_3].length);
  const x_5 = run_loop($f_col$(ts_0));
  const x_6 = Number(x_4 & 0xFFFFFFFFn);
  const x_7 = run_loop($f_col$(run_loop($f_tl$(ts_0))));
  const x_8 = ((x_5 + x_6) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($Bool$and$(run_loop($String$ends_with$(run_loop($f_tx$(ts_0)), "n")), run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "+")))), (x_1 === x_2))), (x_7 === x_8))), run_clo((x_9) => {
  return run_jump($f_atom_nat_start$, [ts_0, run_loop($f_literal$(run_loop($f_tx$(ts_0))))]);
}), run_clo((x_10) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Literal", run_loop($f_tx$(ts_0)), run_loop($f_atid$(ts_0)), 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
})]);
}), run_clo((x_11) => {
  const x_12 = run_loop($f_line$(ts_0));
  const x_13 = run_loop($f_line$(run_loop($f_tl$(ts_0))));
  const x_14 = run_loop($f_tx$(ts_0));
  const x_15 = BigInt([...x_14].length);
  const x_16 = run_loop($f_col$(ts_0));
  const x_17 = Number(x_15 & 0xFFFFFFFFn);
  const x_18 = run_loop($f_col$(run_loop($f_tl$(ts_0))));
  const x_19 = ((x_16 + x_17) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))), "{")), (x_12 === x_13))), (x_18 === x_19))), run_clo((x_20) => {
  return run_jump($f_atom_constructor$, [run_loop($f_tx$(ts_0)), run_loop($f_atid$(ts_0)), run_loop($f_args$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))), "}", {$: "Nil"}))]);
}), run_clo((x_21) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Ref", run_loop($f_tx$(ts_0)), run_loop($f_atid$(ts_0)), 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))};
})]);
})]);
}

function $f_foreign_path_valid$(ts_0) {
  const x_0 = run_loop($f_kind$(run_loop($f_tl$(ts_0))));
  const x_1 = run_loop($String$ends_with$(run_loop($f_unquote$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))), ".c"));
  const x_2 = run_loop($String$ends_with$(run_loop($f_unquote$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))), ".js"));
  return run_jump($Bool$and$, [run_loop($Bool$and$((x_0 === 2), run_loop($Char$is_eq$(run_loop($f_head$(run_loop($f_tx$(run_loop($f_tl$(ts_0)))))), "\"")))), (x_1 || x_2)]);
}

function $f_unquote$(s_0) {
  return run_jump($f_unquote_chars$, [run_loop($f_tail$(s_0))]);
}

function $fpe_foreign$(ts_0) {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(run_loop($f_tx$(ts_0)))), "\"")), run_clo((x_0) => {
  return run_jump($kt$, ["Error", "foreign import requires a quoted .c or .js path", 0, 0, {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($f_pn$, [run_loop($fpe_legacy$(ts_0, "foreign import requires a quoted .c or .js path", "'\"'"))]);
})]);
}

function $f_put$(d_0, book_0) {
  return {$: "Con", ["head"]: d_0, ["tail"]: book_0};
}

function $f_dk$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return kind_0;
}

function $f_tbind$(pars_0, result_0) {
  if (pars_0.$ === "Nil") {
    return result_0;
  } else {
    const p_0 = pars_0["head"];
    const ps_0 = pars_0["tail"];
    return run_jump($kt$, ["All", run_loop($nm$(p_0)), run_loop($ix$(p_0)), run_loop($qt$(p_0)), {$: "Con", ["head"]: run_loop($kid$(p_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($f_tbind$(ps_0, result_0)), ["tail"]: {$: "Nil"}}}]);
  }
}

function $f_dx$(d_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const typ_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return templates_0;
}

function $fc_start$(pars_0, ty_0, body_0, filled_0) {
  const x_2 = run_loop($f_choose$(filled_0, run_clo((x_0) => {
  return run_jump($f_len$, [pars_0]);
}), run_clo((x_1) => {
  return run_jump($fc_term$, [ty_0, {$: "Nil"}]);
})));
  const x_3 = run_loop($fc_term$(body_0, pars_0));
  return ((x_2 + x_3) >>> 0);
}

function $f_body_context$(ts_0, outer_0) {
  return run_jump($f_body_context_at$, [run_loop($f_skip$(ts_0)), outer_0]);
}

function $f_ctor_lookup$(name_0, book_0) {
  if (book_0.$ === "Nil") {
    return run_jump($f_find$, [name_0, {$: "Nil"}]);
  } else {
    const d_0 = book_0["head"];
    const ds_0 = book_0["tail"];
    return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($dk$(d_0)), "Ctr")), run_loop($f_eq$(run_loop($dn$(d_0)), name_0)))), run_clo((x_0) => {
    return d_0;
}), run_clo((x_1) => {
    return run_jump($f_ctor_more$, [name_0, run_loop($f_ctor_lookup$(name_0, run_loop($dc$(d_0)))), ds_0]);
})]);
  }
}

function $fpe_fresh$(ts_0, legacy_0, expected_0) {
  const x_0 = run_loop($f_line$(ts_0));
  const x_1 = run_loop($f_line$(run_loop($f_tl$(ts_0))));
  const x_2 = run_loop($f_tx$(ts_0));
  const x_3 = BigInt([...x_2].length);
  const x_4 = run_loop($f_col$(ts_0));
  const x_5 = Number(x_3 & 0xFFFFFFFFn);
  const x_6 = run_loop($f_col$(run_loop($f_tl$(ts_0))));
  const x_7 = ((x_4 + x_5) >>> 0);
  return run_jump($f_choose$, [run_loop($Bool$and$((x_0 === x_1), (x_6 === x_7))), run_clo((x_8) => {
  return run_jump($fpe_error$, [run_loop($f_tl$(ts_0)), legacy_0, expected_0]);
}), run_clo((x_9) => {
  return run_jump($f_err$, [run_loop($f_tl$(ts_0)), legacy_0]);
})]);
}

function $f_type_ctor$(name_0, pars_0, ty_0, ctor_0, p_0, book_0, imports_0, ctors_0) {
  const fields_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(fields_0)), "Error")), run_clo((x_0) => {
  return run_jump($f_result$, [book_0, fields_0, imports_0]);
}), run_clo((x_1) => {
  return run_jump($f_type_ctors$, [name_0, pars_0, ty_0, run_loop($f_skip$(ts_0)), book_0, imports_0, {$: "Con", ["head"]: {$: "KDef", ["name"]: ctor_0, ["kind"]: "Ctr", ["arity"]: run_loop($f_len$(run_loop($ks$(fields_0)))), ["templates"]: 0, ["typ"]: run_loop($f_tbind$(pars_0, run_loop($f_tbind$(run_loop($ks$(fields_0)), run_loop($kt$("ADT", name_0, 0, 1, run_loop($f_param_refs$(pars_0)))))))), ["value"]: run_loop($kt$("Absent", ctor_0, 0, 0, {$: "Nil"})), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: false}, ["tail"]: ctors_0}]);
})]);
}

function $f_path_term$(t_0, dir_0) {
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(t_0)), "Path")), run_clo((x_0) => {
  return run_jump($f_path_join$, [dir_0, run_loop($nm$(t_0))]);
}), run_clo((x_1) => {
  return run_jump($nm$, [t_0]);
}))), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_path_terms$(run_loop($ks$(t_0)), dir_0)), ["removed"]: run_loop($rm$(t_0))};
}

function $f_module_def$(d_0, rest_0, visible_0, scope_0, ns_0, imports_0) {
  return {$: "Con", ["head"]: run_loop($f_choose$(run_loop($String$is_empty$(ns_0)), run_clo((x_0) => {
  return run_jump($f_elab_def$, [d_0, scope_0]);
}), run_clo((x_1) => {
  return run_jump($f_qual_def$, [run_loop($f_elab_def$(d_0, scope_0)), visible_0, ns_0, imports_0]);
}))), ["tail"]: run_loop($f_module_defs$(rest_0, visible_0, scope_0, ns_0, imports_0))};
}

function $f_alias$(name_0, imports_0) {
  if (imports_0.$ === "Nil") {
    return name_0;
  } else {
    const im_0 = imports_0["head"];
    const rest_0 = imports_0["tail"];
    const x_0 = run_loop($f_len$(run_loop($ks$(im_0))));
    const x_1 = run_loop($nm$(run_loop($kid$(im_0, 0))));
    return run_jump($f_choose$, [run_loop($Bool$and$((x_0 > 0), run_loop($f_prefix$(name_0, (x_1 + "."))))), run_clo((x_2) => {
    const x_3 = run_loop($nm$(run_loop($kid$(im_0, 0))));
    const x_4 = run_loop($f_drop_prefix$(name_0, (x_3 + ".")));
    const x_5 = run_loop($nm$(im_0));
    const x_6 = ("." + x_4);
    return (x_5 + x_6);
}), run_clo((x_7) => {
    return run_jump($f_alias$, [name_0, rest_0]);
})]);
  }
}

function $f_alias_terms$(ts_0, imports_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_alias_term$(t_0, imports_0)), ["tail"]: run_loop($f_alias_terms$(rest_0, imports_0))};
  }
}

function $f_path_join_parts$(parts_0, acc_0) {
  if (parts_0.$ === "Nil") {
    return acc_0;
  } else {
    const part_0 = parts_0["head"];
    const rest_0 = parts_0["tail"];
    const x_0 = run_loop($String$is_empty$(acc_0));
    const x_1 = run_loop($f_eq$(acc_0, "/"));
    const x_4 = run_loop($f_choose$((x_0 || x_1), run_clo((x_2) => {
    return "";
}), run_clo((x_3) => {
    return "/";
})));
    const x_5 = (x_4 + part_0);
    return run_jump($f_path_join_parts$, [rest_0, (acc_0 + x_5)]);
  }
}

function $f_path_push$(part_0, parts_0) {
  const x_0 = run_loop($String$is_empty$(part_0));
  const x_1 = run_loop($f_eq$(part_0, "."));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return parts_0;
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(part_0, "..")), run_clo((x_4) => {
  return run_jump($f_path_parent$, [parts_0]);
}), run_clo((x_5) => {
  return {$: "Con", ["head"]: part_0, ["tail"]: parts_0};
})]);
})]);
}

function $check_ctor_domain$(e_0, d_0, tel_0, kind_0, params_0, fields_0, ctx_0, args_0, r_0) {
  return run_jump($kc$, [run_loop($good$(r_0)), run_clo((x_0) => {
  return run_jump($check_ctor_tel$, [e_0, d_0, run_loop($kid$(tel_0, 1)), run_loop($kc$((params_0 === 0), run_clo((x_1) => {
  return kind_0;
}), run_clo((x_2) => {
  return run_jump($subst$, [run_loop($kid$(run_loop($wnf$(run_loop($cb$(e_0)), kind_0)), 1)), run_loop($ix$(run_loop($wnf$(run_loop($cb$(e_0)), kind_0)))), run_loop($var$(run_loop($nm$(tel_0)), run_loop($ix$(tel_0))))]);
}))), run_loop($kc$((params_0 === 0), run_clo((x_3) => {
  return 0;
}), run_clo((x_4) => {
  return ((params_0 - 1) >>> 0);
}))), run_loop($kc$((params_0 === 0), run_clo((x_5) => {
  return ((fields_0 - 1) >>> 0);
}), run_clo((x_6) => {
  return fields_0;
}))), run_loop($ctx_bind$(ctx_0, run_loop($ix$(tel_0)), run_loop($qt$(tel_0)), run_loop($nm$(tel_0)), run_loop($kid$(tel_0, 0)))), run_loop($kc$((params_0 === 0), run_clo((x_7) => {
  return args_0;
}), run_clo((x_8) => {
  return run_jump($norm_join$, [args_0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(tel_0)), run_loop($ix$(tel_0)))), ["tail"]: {$: "Nil"}}]);
})))]);
}), run_clo((x_9) => {
  return run_jump($ce$, [r_0]);
})]);
}

function $fp_at_token$(t_0, definition_0, text_0, tokens_0, route_0) {
  if (tokens_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const token_0 = tokens_0["head"];
    const rest_0 = tokens_0["tail"];
    return run_jump($fp_token_origin$, [t_0, definition_0, text_0, token_0, route_0]);
  }
}

function $fp_find_token$(tokens_0, line_0, column_0) {
  if (tokens_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const token_0 = tokens_0["head"];
    const rest_0 = tokens_0["tail"];
    const x_0 = run_loop($f_line$({$: "Con", ["head"]: token_0, ["tail"]: rest_0}));
    const x_1 = run_loop($f_col$({$: "Con", ["head"]: token_0, ["tail"]: rest_0}));
    return run_jump($f_choose$, [run_loop($Bool$and$((x_0 === line_0), (x_1 === column_0))), run_clo((x_2) => {
    return {$: "Con", ["head"]: token_0, ["tail"]: rest_0};
}), run_clo((x_3) => {
    return run_jump($fp_find_token$, [rest_0, line_0, column_0]);
})]);
  }
}

function $core_subst_stable_app_last$(f_0, x_0, rest_0) {
  if (rest_0.$ === "Con") {
    const h_0 = rest_0["head"];
    const tail_0 = rest_0["tail"];
    return false;
  } else {
    return run_jump($Bool$not$, [run_loop($String$eq$(run_loop($tg$(f_0)), "Lam"))]);
  }
}

function $kp_digit$(n_0) {
  return run_jump($Char$show$, [run_loop($Char$from_u32$(run_loop($kc$((n_0 < 10), run_clo((x_0) => {
  return ((n_0 + 48) >>> 0);
}), run_clo((x_1) => {
  return ((n_0 + 87) >>> 0);
})))))]);
}

function $sp_len$(s_0) {
  const x_0 = BigInt([...s_0].length);
  return Number(x_0 & 0xFFFFFFFFn);
}

function $sp_template_inst$(rest_0, ctx_0, owner_0, depth_0, r_0) {
  return run_jump($sp_apply_result$, [run_loop($sp_value$(r_0)), run_loop($sp_args$(run_loop($sp_state$(r_0)), rest_0, ctx_0, run_loop($dt$(run_loop($lookup$(run_loop($sp_book$(run_loop($sp_state$(r_0)))), run_loop($nm$(run_loop($sp_value$(r_0)))))))), owner_0, depth_0))]);
}

function $sp_instance$(st_0, d_0, xs_0, owner_0, depth_0, key_0, memo_0) {
  return run_jump($kc$, [run_loop($Bool$not$(run_loop($String$eq$(run_loop($sp_mname$(memo_0)), "")))), run_clo((x_0) => {
  return run_jump($kc$, [run_loop($Bool$and$(run_loop($sp_active$(memo_0)), run_loop($Bool$not$(run_loop($String$eq$(run_loop($sp_mname$(memo_0)), owner_0)))))), run_clo((x_1) => {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, "nondecreasing cross-instance template recursion")), ["term"]: run_loop($ref$(run_loop($sp_mname$(memo_0))))};
}), run_clo((x_2) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: run_loop($ref$(run_loop($sp_mname$(memo_0))))};
})]);
}), run_clo((x_3) => {
  return run_jump($kc$, [(depth_0 >= 64), run_clo((x_4) => {
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, "template instantiation exceeds 64 levels")), ["term"]: run_loop($ref$(run_loop($dn$(d_0))))};
}), run_clo((x_5) => {
  const x_6 = run_loop($U32$show$(run_loop($sp_serial$(st_0))));
  const x_7 = run_loop($dn$(d_0));
  const x_8 = ("~" + x_6);
  return run_jump($sp_mint$, [st_0, d_0, xs_0, ((depth_0 + 1) >>> 0), key_0, (x_7 + x_8)]);
})]);
})]);
}

function $sp_find$(ms_0, name_0, key_0) {
  if (ms_0.$ === "Nil") {
    return {$: "KSpecMemo", ["template"]: "", ["key"]: "", ["name"]: "", ["active"]: false};
  } else {
    const h_0 = ms_0["head"];
    const rest_0 = ms_0["tail"];
    return run_jump($kc$, [run_loop($Bool$and$(run_loop($String$eq$(run_loop($sp_mtemplate$(h_0)), name_0)), run_loop($String$eq$(run_loop($sp_mkey$(h_0)), key_0)))), run_clo((x_0) => {
    return h_0;
}), run_clo((x_1) => {
    return run_jump($sp_find$, [rest_0, name_0, key_0]);
})]);
  }
}

function $term_key$(t_0) {
  const x_0 = run_loop($sp_name_keys$(run_loop($rm$(t_0))));
  const x_1 = (x_0 + "]");
  const x_2 = run_loop($sp_keys$(run_loop($ks$(t_0))));
  const x_3 = ("][" + x_1);
  const x_4 = (x_2 + x_3);
  const x_5 = run_loop($U32$show$(run_loop($qt$(t_0))));
  const x_6 = ("[" + x_4);
  const x_7 = (x_5 + x_6);
  const x_8 = run_loop($U32$show$(run_loop($ix$(t_0))));
  const x_9 = (":" + x_7);
  const x_10 = run_loop($sp_key_string$(run_loop($nm$(t_0))));
  const x_11 = (x_8 + x_9);
  const x_12 = run_loop($sp_key_string$(run_loop($tg$(t_0))));
  const x_13 = (x_10 + x_11);
  return (x_12 + x_13);
}

function $g_cache$(st_0, id_0, t_0) {
  return {$: "GState", ["heap"]: run_loop($g_put$(run_loop($g_heap$(st_0)), id_0, run_loop($kt$("GValue", "", 0, 0, {$: "Con", ["head"]: t_0, ["tail"]: {$: "Nil"}})))), ["next"]: run_loop($g_next$(st_0))};
}

function $g_shared_head$(t_0, r_0) {
  return {$: "GResult", ["state"]: run_loop($g_states$(r_0)), ["term"]: {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($g_terms$(r_0)), ["removed"]: run_loop($rm$(t_0))}};
}

function $g_share_terms$(st_0, ts_0, done_0) {
  if (ts_0.$ === "Nil") {
    return {$: "GTerms", ["state"]: st_0, ["terms"]: run_loop($List$reverse$(done_0))};
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return run_jump($g_shared_term$, [rest_0, done_0, run_loop($g_share$(st_0, h_0))]);
  }
}

function $Char$is_digit$(c_0) {
  const x_0 = c_0.codePointAt(0);
  return run_jump($Bool$and$, [(x_0 >= 48), (x_0 <= 57)]);
}

function $f_args_base$(ts_0, end_0, acc_0) {
  const spaced_0 = run_loop($f_space$(ts_0));
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(spaced_0)), ";")), run_clo((x_0) => {
  return run_jump($fpe_error$, [spaced_0, run_loop($f_choose$(run_loop($f_eq$(end_0, "]")), run_clo((x_1) => {
  return "expected term; a list does not use semicolon separators";
}), run_clo((x_2) => {
  return "expected term; arguments do not use semicolon separators";
}))), "a term"]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(spaced_0)), end_0)), run_clo((x_4) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Args", "", 0, 1, run_loop($List$reverse$(acc_0)))), ["rest"]: run_loop($f_tl$(spaced_0))};
}), run_clo((x_5) => {
  return run_jump($f_arg_next$, [run_loop($f_expr$(spaced_0, 0)), end_0, acc_0]);
})]);
})]);
}

function $f_binary_plain$(a_0, op_0, b_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(op_0, "=>")), run_clo((x_0) => {
  return run_jump($f_lambda_valid$, [a_0, b_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(op_0, "->")), run_clo((x_2) => {
  return run_jump($kt$, ["All", "_", run_loop($ix$(a_0)), 1, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(op_0, "<>")), run_clo((x_4) => {
  return run_jump($kt$, ["Ctr", "Con", 0, 1, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(op_0, "<&>")), run_clo((x_6) => {
  return run_jump($kt$, ["Min", "", 0, 1, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_7) => {
  return run_jump($f_app$, [run_loop($kt$("Ref", run_loop($f_operator$(op_0)), 0, 1, {$: "Nil"})), {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
})]);
})]);
})]);
})]);
}

function $f_namespace_head$(t_0) {
  const x_0 = run_loop($f_eq$(run_loop($tg$(t_0)), "App"));
  const x_1 = run_loop($f_eq$(run_loop($tg$(t_0)), "Call"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_namespace_head$, [run_loop($kid$(t_0, 0))]);
}), run_clo((x_3) => {
  return t_0;
})]);
}

function $f_namespace_operator$(head_0) {
  const x_0 = run_loop($Char$is_eq$(run_loop($f_head$(run_loop($nm$(head_0)))), "."));
  const x_1 = run_loop($f_eq$(run_loop($nm$(head_0)), "Bool.and"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($nm$(head_0)), "Bool.or"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(run_loop($nm$(head_0)), "String.append"));
  return run_jump($Bool$and$, [run_loop($f_eq$(run_loop($tg$(head_0)), "Ref")), (x_4 || x_5)]);
}

function $f_namespace_terms$(terms_0, ty_0) {
  if (terms_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const term_0 = terms_0["head"];
    const rest_0 = terms_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_namespace$(term_0, ty_0)), ["tail"]: run_loop($f_namespace_terms$(rest_0, ty_0))};
  }
}

function $f_do_parameters$(monad_0, ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<>")), run_clo((x_0) => {
  return run_jump($f_do_types$, [monad_0, {$: "FParsed", ["term"]: run_loop($kt$("Args", "", 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))}]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<")), run_clo((x_2) => {
  return run_jump($f_do_parameters_open$, [monad_0, run_loop($f_space$(run_loop($f_tl$(ts_0))))]);
}), run_clo((x_3) => {
  return run_jump($fpe_error$, [ts_0, "expected <", "'<'"]);
})]);
})]);
}

function $f_rewrite_proof$(name_0, id_0, p_0) {
  const e_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_rewrite_motive$, [name_0, id_0, e_0, run_loop($f_expr$(ts_0, 0))]);
}

function $f_tuple$(n_0, p_0) {
  const m_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Ctr", "Tuple", 0, 1, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: m_0, ["tail"]: {$: "Nil"}}})), ["rest"]: ts_0};
}

function $f_group_namespace$(n_0, p_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: run_loop($f_choose$(run_loop($String$is_empty$(run_loop($f_error_term$(n_0)))), run_clo((x_1) => {
  return ty_0;
}), run_clo((x_2) => {
  return n_0;
}))), ["rest"]: ts_0};
}), run_clo((x_3) => {
  return {$: "FParsed", ["term"]: run_loop($f_namespace$(n_0, ty_0)), ["rest"]: ts_0};
})]);
}

function $f_brace_left$(p_0) {
  const a_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  const x_0 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=="));
  const x_1 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "!="));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_equation$, [a_0, run_loop($f_eq$(run_loop($f_tx$(ts_0)), "!=")), run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), ":"))]);
}), run_clo((x_3) => {
  return run_jump($f_group_ann$, [a_0, run_loop($f_expect$(run_loop($f_expr$(run_loop($f_pr$(run_loop($f_expect$({$: "FParsed", ["term"]: a_0, ["rest"]: ts_0}, ":")))), 0)), "}"))]);
})]);
}

function $f_array_first$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_0) => {
  return run_jump($f_array_type$, [n_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 12))]);
}), run_clo((x_1) => {
  return run_jump($f_list$, [run_loop($f_args$(run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
}), run_clo((x_3) => {
  return ts_0;
}))), "]", {$: "Con", ["head"]: n_0, ["tail"]: {$: "Nil"}}))]);
})]);
}

function $f_all_domain$(name_0, id_0, q_0, exi_0, p_0) {
  const a_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_all_body$, [name_0, id_0, q_0, exi_0, a_0, run_loop($f_expr$(ts_0, 0))]);
}

function $f_matcher_head$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(n_0)), "Ref")), run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")))), run_clo((x_0) => {
  return run_jump($f_matcher_arm$, [run_loop($nm$(n_0)), run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))]);
}), run_clo((x_1) => {
  return run_jump($f_expect$, [{$: "FParsed", ["term"]: n_0, ["rest"]: ts_0}, "}"]);
})]);
}

function $f_kind$(ts_0) {
  if (ts_0.$ === "Nil") {
    return 0;
  } else {
    const _t_0 = ts_0["head"];
    const t_0 = _t_0["text"];
    const l_0 = _t_0["f_line"];
    const c_0 = _t_0["f_col"];
    const k_0 = _t_0["f_kind"];
    const rest_0 = ts_0["tail"];
    return k_0;
  }
}

function $f_atom_nat_start$(ts_0, lit_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(lit_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: lit_0, ["rest"]: {$: "Nil"}};
}), run_clo((x_1) => {
  return run_jump($f_atom_nat_plus$, [lit_0, run_loop($f_expr$(run_loop($f_tl$(run_loop($f_tl$(ts_0)))), 0))]);
})]);
}

function $f_literal$(s_0) {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "\"")), run_clo((x_0) => {
  return run_jump($f_string$, [run_loop($f_tail$(s_0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "'")), run_clo((x_2) => {
  return run_jump($f_char_literal$, [run_loop($f_tail$(s_0))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_contains$(s_0, ".")), run_clo((x_4) => {
  return run_jump($f_float$, [s_0]);
}), run_clo((x_5) => {
  return run_jump($f_number$, [s_0, 0]);
})]);
})]);
})]);
}

function $f_atom_constructor$(name_0, id_0, p_0) {
  const args_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(args_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: args_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Ctr", name_0, id_0, 1, run_loop($ks$(args_0)))), ["rest"]: ts_0};
})]);
}

function $f_unquote_chars$(s_0) {
  const x_0 = run_loop($String$is_empty$(s_0));
  const x_1 = run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "\""));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return "";
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "\\")), run_clo((x_4) => {
  return (char_new(run_loop($f_escape_code$(run_loop($f_head$(run_loop($f_tail$(s_0))))))) + run_loop($f_unquote_chars$(run_loop($f_tail$(run_loop($f_tail$(s_0)))))));
}), run_clo((x_5) => {
  return (run_loop($f_head$(s_0)) + run_loop($f_unquote_chars$(run_loop($f_tail$(s_0)))));
})]);
})]);
}

function $fc_term$(t_0, env_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_0) => {
  return run_jump($fc_ref$, [run_loop($nm$(t_0)), env_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "ADT")), run_clo((x_2) => {
  const x_3 = run_loop($fc_ref$(run_loop($nm$(t_0)), env_0));
  const x_4 = run_loop($fc_terms$(run_loop($ks$(t_0)), env_0));
  return ((x_3 + x_4) >>> 0);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "All")), run_clo((x_6) => {
  const x_7 = run_loop($fc_term$(run_loop($kid$(t_0, 0)), env_0));
  const x_8 = run_loop($fc_term$(run_loop($kid$(t_0, 1)), run_loop($fc_bind$(t_0, env_0))));
  const x_9 = ((x_7 + x_8) >>> 0);
  return ((1 + x_9) >>> 0);
}), run_clo((x_10) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_11) => {
  const x_12 = run_loop($fc_ref$(run_loop($nm$(t_0)), env_0));
  const x_13 = run_loop($fc_term$(run_loop($kid$(t_0, 0)), run_loop($fc_bind$(t_0, env_0))));
  const x_14 = ((x_12 + x_13) >>> 0);
  return ((1 + x_14) >>> 0);
}), run_clo((x_15) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Match")), run_clo((x_16) => {
  const x_17 = run_loop($fc_terms$(run_loop($ks$(run_loop($kid$(t_0, 0)))), env_0));
  const x_18 = run_loop($fc_rows$(run_loop($f_tail_terms$(run_loop($ks$(t_0)))), env_0));
  return ((x_17 + x_18) >>> 0);
}), run_clo((x_19) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Local")), run_clo((x_20) => {
  const x_21 = run_loop($qt$(run_loop($kid$(t_0, 0))));
  const x_24 = run_loop($fc_bind_count$({$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}}));
  const x_25 = run_loop($fc_term$(run_loop($kid$(t_0, 2)), run_loop($f_concat$(run_loop($fc_binders$({$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}})), env_0))));
  const x_26 = run_loop($fc_term$(run_loop($kid$(t_0, 1)), env_0));
  const x_27 = ((x_24 + x_25) >>> 0);
  const x_28 = run_loop($f_choose$((x_21 === 0), run_clo((x_22) => {
  return 0;
}), run_clo((x_23) => {
  return run_jump($fc_term$, [run_loop($kid$(t_0, 0)), env_0]);
})));
  const x_29 = ((x_26 + x_27) >>> 0);
  return ((x_28 + x_29) >>> 0);
}), run_clo((x_30) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Parallel")), run_clo((x_31) => {
  const x_32 = run_loop($fc_bind_count$(run_loop($ks$(run_loop($kid$(t_0, 0))))));
  const x_33 = run_loop($fc_term$(run_loop($kid$(t_0, 2)), run_loop($f_concat$(run_loop($fc_binders$(run_loop($ks$(run_loop($kid$(t_0, 0)))))), env_0))));
  const x_34 = run_loop($fc_terms$(run_loop($ks$(run_loop($kid$(t_0, 1)))), env_0));
  const x_35 = ((x_32 + x_33) >>> 0);
  const x_36 = run_loop($fc_terms$(run_loop($ks$(run_loop($kid$(t_0, 0)))), env_0));
  const x_37 = ((x_34 + x_35) >>> 0);
  return ((x_36 + x_37) >>> 0);
}), run_clo((x_38) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Mat")), run_clo((x_39) => {
  const x_40 = run_loop($fc_ref$(run_loop($nm$(t_0)), env_0));
  const x_41 = run_loop($fc_terms$(run_loop($ks$(t_0)), env_0));
  return ((x_40 + x_41) >>> 0);
}), run_clo((x_42) => {
  return run_jump($fc_terms$, [run_loop($ks$(t_0)), env_0]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_body_context_at$(ts_0, outer_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "match")), run_clo((x_0) => {
  return run_jump($f_match_heads$, [run_loop($f_tl$(ts_0)), outer_0, {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($f_body_at$, [ts_0]);
})]);
}

function $f_ctor_more$(name_0, found_0, rest_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($dk$(found_0)), "Missing")), run_clo((x_0) => {
  return run_jump($f_ctor_lookup$, [name_0, rest_0]);
}), run_clo((x_1) => {
  return found_0;
})]);
}

function $f_param_refs$(pars_0) {
  if (pars_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const p_0 = pars_0["head"];
    const ps_0 = pars_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Ref", run_loop($nm$(p_0)), run_loop($ix$(p_0)), run_loop($qt$(p_0)), {$: "Nil"})), ["tail"]: run_loop($f_param_refs$(ps_0))};
  }
}

function $f_path_terms$(ts_0, dir_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_path_term$(t_0, dir_0)), ["tail"]: run_loop($f_path_terms$(rest_0, dir_0))};
  }
}

function $f_elab_def$(d_0, book_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const ty_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return {$: "KDef", ["name"]: name_0, ["kind"]: kind_0, ["arity"]: arity_0, ["templates"]: templates_0, ["typ"]: run_loop($f_scope$(ty_0, {$: "Nil"}, book_0)), ["value"]: run_loop($f_scope$(value_0, {$: "Nil"}, book_0)), ["ctors"]: run_loop($f_elab_defs$(ctors_0, book_0)), ["native"]: native_0, ["unsafe"]: unsafe_0};
}

function $f_qual_def$(d_0, book_0, ns_0, imports_0) {
  const name_0 = d_0["name"];
  const kind_0 = d_0["kind"];
  const arity_0 = d_0["arity"];
  const templates_0 = d_0["templates"];
  const ty_0 = d_0["typ"];
  const value_0 = d_0["value"];
  const ctors_0 = d_0["ctors"];
  const native_0 = d_0["native"];
  const unsafe_0 = d_0["unsafe"];
  return {$: "KDef", ["name"]: run_loop($f_qual_name$(name_0, ns_0)), ["kind"]: kind_0, ["arity"]: arity_0, ["templates"]: templates_0, ["typ"]: run_loop($f_qual_term$(ty_0, book_0, ns_0, imports_0)), ["value"]: run_loop($f_qual_term$(value_0, book_0, ns_0, imports_0)), ["ctors"]: run_loop($f_qual_defs$(ctors_0, book_0, ns_0, imports_0)), ["native"]: native_0, ["unsafe"]: unsafe_0};
}

function $f_prefix$(s_0, prefix_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(prefix_0)), run_clo((x_0) => {
  return true;
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_2) => {
  return false;
}), run_clo((x_3) => {
  return run_jump($Bool$and$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), run_loop($f_head$(prefix_0)))), run_loop($f_prefix$(run_loop($f_tail$(s_0)), run_loop($f_tail$(prefix_0))))]);
})]);
})]);
}

function $f_drop_prefix$(s_0, prefix_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(prefix_0)), run_clo((x_0) => {
  return s_0;
}), run_clo((x_1) => {
  return run_jump($f_drop_prefix$, [run_loop($f_tail$(s_0)), run_loop($f_tail$(prefix_0))]);
})]);
}

function $f_path_parent$(parts_0) {
  if (parts_0.$ === "Nil") {
    return {$: "Con", ["head"]: "..", ["tail"]: {$: "Nil"}};
  } else {
    const p_0 = parts_0["head"];
    const rest_0 = parts_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(p_0, "..")), run_clo((x_0) => {
    return {$: "Con", ["head"]: "..", ["tail"]: {$: "Con", ["head"]: p_0, ["tail"]: rest_0}};
}), run_clo((x_1) => {
    return rest_0;
})]);
  }
}

function $fp_token_origin$(t_0, definition_0, text_0, token_0, route_0) {
  const word_0 = token_0["text"];
  const line_0 = token_0["f_line"];
  const column_0 = token_0["f_col"];
  const kind_0 = token_0["f_kind"];
  const begin_0 = run_loop($fp_offset$(text_0, 1, 0, line_0, column_0, 0));
  const x_0 = run_loop($fp_utf16$(word_0));
  return {$: "Con", ["head"]: {$: "DOrigin", ["definition"]: definition_0, ["term"]: t_0, ["source"]: text_0, ["begin"]: begin_0, ["end"]: ((begin_0 + x_0) >>> 0), ["path"]: route_0}, ["tail"]: {$: "Nil"}};
}

function $sp_mname$(m_0) {
  const template_0 = m_0["template"];
  const key_0 = m_0["key"];
  const name_0 = m_0["name"];
  const active_0 = m_0["active"];
  return name_0;
}

function $sp_active$(m_0) {
  const template_0 = m_0["template"];
  const key_0 = m_0["key"];
  const name_0 = m_0["name"];
  const active_0 = m_0["active"];
  return active_0;
}

function $sp_mint$(st_0, d_0, xs_0, depth_0, key_0, name_0) {
  return run_jump($sp_mint_type$, [st_0, d_0, xs_0, depth_0, key_0, name_0, run_loop($tele_fill$(run_loop($sp_book$(st_0)), run_loop($sp_shift$(run_loop($dt$(d_0)), run_loop($sp_fresh$(st_0)))), xs_0)), run_loop($sp_apply_template$(run_loop($sp_shift$(run_loop($dv$(d_0)), run_loop($sp_fresh$(st_0)))), xs_0))]);
}

function $sp_mtemplate$(m_0) {
  const template_0 = m_0["template"];
  const key_0 = m_0["key"];
  const name_0 = m_0["name"];
  const active_0 = m_0["active"];
  return template_0;
}

function $sp_mkey$(m_0) {
  const template_0 = m_0["template"];
  const key_0 = m_0["key"];
  const name_0 = m_0["name"];
  const active_0 = m_0["active"];
  return key_0;
}

function $sp_key_string$(s_0) {
  const x_0 = run_loop($U32$show$(run_loop($sp_len$(s_0))));
  const x_1 = (":" + s_0);
  return (x_0 + x_1);
}

function $sp_name_keys$(ns_0) {
  if (ns_0.$ === "Nil") {
    return "";
  } else {
    const h_0 = ns_0["head"];
    const rest_0 = ns_0["tail"];
    const x_0 = run_loop($sp_key_string$(h_0));
    const x_1 = run_loop($sp_name_keys$(rest_0));
    return (x_0 + x_1);
  }
}

function $g_states$(r_0) {
  const state_0 = r_0["state"];
  const terms_0 = r_0["terms"];
  return state_0;
}

function $g_terms$(r_0) {
  const state_0 = r_0["state"];
  const terms_0 = r_0["terms"];
  return terms_0;
}

function $g_shared_term$(rest_0, done_0, r_0) {
  return run_jump($g_share_terms$, [run_loop($g_state$(r_0)), rest_0, {$: "Con", ["head"]: run_loop($g_term$(r_0)), ["tail"]: done_0}]);
}

function $f_arg_next$(p_0, end_0, acc_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_args$, [run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
}), run_clo((x_3) => {
  return ts_0;
}))), end_0, {$: "Con", ["head"]: n_0, ["tail"]: acc_0}]);
})]);
}

function $f_lambda_valid$(a_0, body_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(a_0)), "Ref")), run_loop($f_valid_name$(run_loop($nm$(a_0)))))), run_clo((x_0) => {
  return run_jump($kt$, ["Lam", run_loop($nm$(a_0)), run_loop($ix$(a_0)), run_loop($qt$(a_0)), {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "a lambda binder must be a non-reserved name", 0, 0, {$: "Nil"}]);
})]);
}

function $f_operator$(s_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "&")), run_clo((x_0) => {
  return "Pair";
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "|")), run_clo((x_2) => {
  return "Or";
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "++")), run_clo((x_4) => {
  return "String.append";
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "||")), run_clo((x_6) => {
  return "Bool.or";
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "&&")), run_clo((x_8) => {
  return "Bool.and";
}), run_clo((x_9) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "+")), run_clo((x_10) => {
  return ".add";
}), run_clo((x_11) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "-")), run_clo((x_12) => {
  return ".sub";
}), run_clo((x_13) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "*")), run_clo((x_14) => {
  return ".mul";
}), run_clo((x_15) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "/")), run_clo((x_16) => {
  return ".div";
}), run_clo((x_17) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "%")), run_clo((x_18) => {
  return ".mod";
}), run_clo((x_19) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "<")), run_clo((x_20) => {
  return ".is_lt";
}), run_clo((x_21) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ">op")), run_clo((x_22) => {
  return ".is_gt";
}), run_clo((x_23) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "<=")), run_clo((x_24) => {
  return ".is_le";
}), run_clo((x_25) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ">=")), run_clo((x_26) => {
  return ".is_ge";
}), run_clo((x_27) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "<<")), run_clo((x_28) => {
  return ".shln";
}), run_clo((x_29) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ">>op")), run_clo((x_30) => {
  return ".shrn";
}), run_clo((x_31) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".&.")), run_clo((x_32) => {
  return ".and";
}), run_clo((x_33) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".|.")), run_clo((x_34) => {
  return ".or";
}), run_clo((x_35) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, ".^.")), run_clo((x_36) => {
  return ".xor";
}), run_clo((x_37) => {
  return s_0;
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_do_types$(monad_0, p_0) {
  const types_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(types_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: types_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_do_types_at$, [monad_0, types_0, run_loop($f_space$(ts_0))]);
})]);
}

function $f_do_parameters_open$(monad_0, ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ";")), run_clo((x_0) => {
  return run_jump($fpe_error$, [ts_0, "expected term", "a term"]);
}), run_clo((x_1) => {
  const x_2 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), ">"));
  const x_3 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), ">op"));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($f_do_types$, [monad_0, {$: "FParsed", ["term"]: run_loop($kt$("Args", "", 0, 1, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))}]);
}), run_clo((x_5) => {
  return run_jump($f_do_types$, [monad_0, run_loop($f_args$(ts_0, ">", {$: "Nil"}))]);
})]);
})]);
}

function $f_rewrite_motive$(name_0, id_0, e_0, p_0) {
  const motive_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_rewrite_body$, [e_0, run_loop($kt$("Lam", "_", ((id_0 + 2147483648) >>> 0), 4, {$: "Con", ["head"]: run_loop($kt$("Lam", name_0, id_0, 1, {$: "Con", ["head"]: motive_0, ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}})), run_loop($f_body$(ts_0))]);
}

function $f_equation$(a_0, neg_0, p_0) {
  const b_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_equation_type$, [a_0, b_0, neg_0, run_loop($f_expect$(run_loop($f_expr$(ts_0, 0)), "}"))]);
}

function $f_group_ann$(n_0, p_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Ann", "", 0, 1, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}})), ["rest"]: ts_0};
}

function $f_array_type$(n_0, p_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_array_size$, [n_0, ty_0, run_loop($f_eq$(run_loop($f_tx$(ts_0)), "*")), run_loop($f_expect$(run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), "]"))]);
}

function $f_list$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return n_0;
}), run_clo((x_1) => {
  return run_jump($f_list_nodes$, [run_loop($ks$(n_0))]);
}))), ["rest"]: ts_0};
}

function $f_all_body$(name_0, id_0, q_0, exi_0, a_0, p_0) {
  const b_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_choose$(exi_0, run_clo((x_0) => {
  return run_jump($f_app$, [run_loop($kt$("Ref", "Exists", 0, 1, {$: "Nil"})), {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Lam", name_0, id_0, q_0, {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["All", name_0, id_0, q_0, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
}))), ["rest"]: ts_0};
}

function $f_matcher_arm$(name_0, p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_matcher_tail$, [name_0, n_0, run_loop($f_matcher$(run_loop($f_skip$(ts_0))))]);
}

function $f_atom_nat_plus$(lit_0, p_0) {
  const rhs_0 = p_0["term"];
  const rest_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(rhs_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: rhs_0, ["rest"]: rest_0};
}), run_clo((x_1) => {
  return {$: "FParsed", ["term"]: run_loop($f_nat_extend$(lit_0, rhs_0)), ["rest"]: rest_0};
})]);
}

function $f_string$(s_0) {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "\"")), run_clo((x_0) => {
  return run_jump($kt$, ["Ctr", "SNil", 0, 1, {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($f_string_decoded$, [run_loop($f_decode_char$(s_0))]);
})]);
}

function $f_char_literal$(s_0) {
  return run_jump($f_char_decoded$, [run_loop($f_decode_char$(s_0))]);
}

function $f_contains$(s_0, c_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return false;
}), run_clo((x_1) => {
  const x_2 = run_loop($Char$is_eq$(run_loop($f_head$(s_0)), c_0));
  const x_3 = run_loop($f_contains$(run_loop($f_tail$(s_0)), c_0));
  return (x_2 || x_3);
})]);
}

function $f_float$(s_0) {
  return run_jump($f_float_read$, [f32_read(s_0)]);
}

function $f_number$(s_0, acc_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return run_jump($f_u32$, [acc_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(s_0, "n")), run_clo((x_2) => {
  return run_jump($f_nat$, [acc_0]);
}), run_clo((x_3) => {
  const x_4 = run_loop($Char$to_u32$(run_loop($f_head$(s_0))));
  const x_5 = (acc_0 < 429496729);
  const x_6 = run_loop($Bool$and$((acc_0 === 429496729), (x_4 <= 53)));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Char$is_digit$(run_loop($f_head$(s_0)))), (x_5 || x_6))), run_clo((x_7) => {
  const x_8 = run_loop($Char$to_u32$(run_loop($f_head$(s_0))));
  const x_9 = (Math.imul(acc_0, 10) >>> 0);
  const x_10 = ((x_8 - 48) >>> 0);
  return run_jump($f_number$, [run_loop($f_tail$(s_0)), ((x_9 + x_10) >>> 0)]);
}), run_clo((x_11) => {
  return run_jump($kt$, ["Error", "invalid or unsupported numeric literal", 0, 0, {$: "Nil"}]);
})]);
})]);
})]);
}

function $f_escape_code$(c_0) {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(c_0, "n")), run_clo((x_0) => {
  return 10;
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(c_0, "t")), run_clo((x_2) => {
  return 9;
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(c_0, "r")), run_clo((x_4) => {
  return 13;
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(c_0, "0")), run_clo((x_6) => {
  return 0;
}), run_clo((x_7) => {
  return run_jump($Char$to_u32$, [c_0]);
})]);
})]);
})]);
})]);
}

function $fc_ref$(name_0, env_0) {
  const x_0 = run_loop($f_contains$(name_0, "."));
  const x_1 = run_loop($Bool$not$(run_loop($f_eq$(run_loop($tg$(run_loop($f_env$(name_0, env_0)))), "Absent"))));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return 0;
}), run_clo((x_3) => {
  return 1;
})]);
}

function $fc_terms$(ts_0, env_0) {
  if (ts_0.$ === "Nil") {
    return 0;
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($fc_term$(t_0, env_0));
    const x_1 = run_loop($fc_terms$(rest_0, env_0));
    return ((x_0 + x_1) >>> 0);
  }
}

function $fc_bind$(v_0, env_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($nm$(v_0)), "_")), run_clo((x_0) => {
  return env_0;
}), run_clo((x_1) => {
  return {$: "Con", ["head"]: v_0, ["tail"]: env_0};
})]);
}

function $fc_rows$(rs_0, env_0) {
  if (rs_0.$ === "Nil") {
    return 0;
  } else {
    const r_0 = rs_0["head"];
    const rest_0 = rs_0["tail"];
    const x_0 = run_loop($fc_term$(run_loop($kid$(r_0, 1)), run_loop($f_concat$(run_loop($fc_binders$(run_loop($ks$(run_loop($kid$(r_0, 0)))))), env_0))));
    const x_1 = run_loop($fc_rows$(rest_0, env_0));
    const x_2 = run_loop($fc_bind_count$(run_loop($ks$(run_loop($kid$(r_0, 0))))));
    const x_3 = ((x_0 + x_1) >>> 0);
    const x_4 = run_loop($fc_terms$(run_loop($ks$(run_loop($kid$(r_0, 0)))), env_0));
    const x_5 = ((x_2 + x_3) >>> 0);
    return ((x_4 + x_5) >>> 0);
  }
}

function $f_tail_terms$(xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return xt_0;
  }
}

function $fc_bind_count$(ps_0) {
  if (ps_0.$ === "Nil") {
    return 0;
  } else {
    const p_0 = ps_0["head"];
    const rest_0 = ps_0["tail"];
    const x_0 = run_loop($f_eq$(run_loop($tg$(p_0)), "Ref"));
    const x_1 = run_loop($f_eq$(run_loop($tg$(p_0)), "Var"));
    const x_4 = run_loop($f_choose$((x_0 || x_1), run_clo((x_2) => {
    return 1;
}), run_clo((x_3) => {
    return run_jump($fc_bind_count$, [run_loop($ks$(p_0))]);
})));
    const x_5 = run_loop($fc_bind_count$(rest_0));
    return ((x_4 + x_5) >>> 0);
  }
}

function $f_concat$(xs_0, ys_0) {
  if (xs_0.$ === "Nil") {
    return ys_0;
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return {$: "Con", ["head"]: x_0, ["tail"]: run_loop($f_concat$(xt_0, ys_0))};
  }
}

function $fc_binders$(ps_0) {
  if (ps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const p_0 = ps_0["head"];
    const rest_0 = ps_0["tail"];
    const x_0 = run_loop($f_eq$(run_loop($tg$(p_0)), "Ref"));
    const x_1 = run_loop($f_eq$(run_loop($tg$(p_0)), "Var"));
    return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
    return run_jump($fc_bind$, [p_0, run_loop($fc_binders$(rest_0))]);
}), run_clo((x_3) => {
    return run_jump($f_concat$, [run_loop($fc_binders$(run_loop($ks$(p_0)))), run_loop($fc_binders$(rest_0))]);
})]);
  }
}

function $f_match_heads$(ts_0, indent_0, acc_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_0) => {
  return run_jump($f_match_begin$, [run_loop($f_skip$(run_loop($f_tl$(ts_0)))), indent_0, run_loop($List$reverse$(acc_0))]);
}), run_clo((x_1) => {
  return run_jump($f_match_head$, [run_loop($f_expr$(run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
}), run_clo((x_3) => {
  return ts_0;
}))), 0)), indent_0, acc_0]);
})]);
}

function $f_body_at$(ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "-")), run_clo((x_0) => {
  return run_jump($f_erased_local$, [run_loop($f_tl$(ts_0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "match")), run_clo((x_2) => {
  return run_jump($f_match_heads$, [run_loop($f_tl$(ts_0)), run_loop($f_col$(ts_0)), {$: "Nil"}]);
}), run_clo((x_3) => {
  return run_jump($f_statement$, [run_loop($f_expr$(ts_0, 0))]);
})]);
})]);
}

function $f_scope$(t_0, env_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Call")), run_clo((x_0) => {
  return run_jump($f_scope_call$, [t_0, env_0, book_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "TemplateArg")), run_clo((x_2) => {
  return run_jump($kt$, ["Error", "~ is only valid in a named template call", 0, 0, {$: "Nil"}]);
}), run_clo((x_3) => {
  return run_jump($f_scope_lower$, [t_0, env_0, book_0]);
})]);
})]);
}

function $f_elab_defs$(ds_0, book_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_elab_def$(d_0, book_0)), ["tail"]: run_loop($f_elab_defs$(rest_0, book_0))};
  }
}

function $f_qual_name$(name_0, ns_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(ns_0)), run_clo((x_0) => {
  return name_0;
}), run_clo((x_1) => {
  const x_2 = ("." + name_0);
  return (ns_0 + x_2);
})]);
}

function $f_qual_term$(t_0, book_0, ns_0, imports_0) {
  const x_0 = run_loop($f_eq$(run_loop($tg$(t_0)), "Ref"));
  const x_1 = run_loop($f_eq$(run_loop($tg$(t_0)), "ADT"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($f_eq$(run_loop($tg$(t_0)), "Ctr"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($f_eq$(run_loop($tg$(t_0)), "Mat"));
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($f_choose$((x_4 || x_5), run_clo((x_6) => {
  return run_jump($f_resolve_name$, [run_loop($nm$(t_0)), book_0, ns_0, imports_0]);
}), run_clo((x_7) => {
  return run_jump($nm$, [t_0]);
}))), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_qual_terms$(run_loop($ks$(t_0)), book_0, ns_0, imports_0)), ["removed"]: run_loop($rm$(t_0))};
}

function $f_qual_defs$(ds_0, book_0, ns_0, imports_0) {
  if (ds_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const d_0 = ds_0["head"];
    const rest_0 = ds_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_qual_def$(d_0, book_0, ns_0, imports_0)), ["tail"]: run_loop($f_qual_defs$(rest_0, book_0, ns_0, imports_0))};
  }
}

function $fp_offset$(text_0, line_0, column_0, targetLine_0, targetColumn_0, offset_0) {
  const x_0 = run_loop($String$is_empty$(text_0));
  const x_1 = run_loop($Bool$and$((line_0 === targetLine_0), (column_0 === targetColumn_0)));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return offset_0;
}), run_clo((x_3) => {
  const x_8 = run_loop($Char$to_u32$(run_loop($f_head$(text_0))));
  const x_11 = run_loop($f_choose$((x_8 > 65535), run_clo((x_9) => {
  return 2;
}), run_clo((x_10) => {
  return 1;
})));
  return run_jump($fp_offset$, [run_loop($f_tail$(text_0)), run_loop($f_choose$(run_loop($Char$is_eq$(run_loop($f_head$(text_0)), "\n")), run_clo((x_4) => {
  return ((line_0 + 1) >>> 0);
}), run_clo((x_5) => {
  return line_0;
}))), run_loop($f_choose$(run_loop($Char$is_eq$(run_loop($f_head$(text_0)), "\n")), run_clo((x_6) => {
  return 0;
}), run_clo((x_7) => {
  return ((column_0 + 1) >>> 0);
}))), targetLine_0, targetColumn_0, ((offset_0 + x_11) >>> 0)]);
})]);
}

function $fp_utf16$(text_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(text_0)), run_clo((x_0) => {
  return 0;
}), run_clo((x_1) => {
  const x_2 = run_loop($Char$to_u32$(run_loop($f_head$(text_0))));
  const x_5 = run_loop($f_choose$((x_2 > 65535), run_clo((x_3) => {
  return 2;
}), run_clo((x_4) => {
  return 1;
})));
  const x_6 = run_loop($fp_utf16$(run_loop($f_tail$(text_0))));
  return ((x_5 + x_6) >>> 0);
})]);
}

function $sp_mint_type$(st_0, d_0, xs_0, depth_0, key_0, name_0, ty_0, body_0) {
  const x_0 = run_loop($da$(d_0));
  const x_1 = run_loop($dx$(d_0));
  const x_2 = run_loop($sp_fresh$(st_0));
  const x_3 = run_loop($norm_max$(run_loop($norm_max_term$(run_loop($dt$(d_0)))), run_loop($norm_max_term$(run_loop($dv$(d_0))))));
  const x_4 = run_loop($sp_serial$(st_0));
  const x_5 = run_loop($sp_fresh$(st_0));
  const x_6 = run_loop($norm_max$(run_loop($norm_max_term$(run_loop($dt$(d_0)))), run_loop($norm_max_term$(run_loop($dv$(d_0))))));
  const x_7 = ((x_5 + x_6) >>> 0);
  return run_jump($sp_mint_body$, [d_0, name_0, ty_0, run_loop($sp_term$({$: "KSpecState", ["book"]: {$: "Con", ["head"]: {$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: ((x_0 - x_1) >>> 0), ["templates"]: 0, ["typ"]: ty_0, ["value"]: run_loop($atom$("Absent")), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: run_loop($du$(d_0))}, ["tail"]: run_loop($sp_stamp$(run_loop($sp_book$(st_0)), ((x_2 + x_3) >>> 0)))}, ["memo"]: {$: "Con", ["head"]: {$: "KSpecMemo", ["template"]: run_loop($dn$(d_0)), ["key"]: key_0, ["name"]: name_0, ["active"]: true}, ["tail"]: run_loop($sp_memo$(st_0))}, ["serial"]: ((x_4 + 1) >>> 0), ["fresh"]: ((x_7 + 1) >>> 0), ["error"]: run_loop($sp_error$(st_0)), ["templates"]: run_loop($sp_templates$(st_0))}, body_0, {$: "Nil"}, ty_0, name_0, depth_0))]);
}

function $sp_shift$(t_0, offset_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(t_0)), "Var"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(t_0)), "All"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Lam"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($String$eq$(run_loop($tg$(t_0)), "Bind"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($String$eq$(run_loop($tg$(t_0)), "Sub"));
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($kc$((x_6 || x_7), run_clo((x_8) => {
  const x_9 = run_loop($ix$(t_0));
  return ((x_9 + offset_0) >>> 0);
}), run_clo((x_10) => {
  return run_jump($ix$, [t_0]);
}))), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($sp_shifts$(run_loop($ks$(t_0)), offset_0)), ["removed"]: run_loop($rm$(t_0))};
}

function $sp_apply_template$(body_0, xs_0) {
  if (xs_0.$ === "Nil") {
    return body_0;
  } else {
    const h_0 = xs_0["head"];
    const rest_0 = xs_0["tail"];
    return run_jump($sp_apply_template$, [run_loop($kapply$(body_0, h_0)), rest_0]);
  }
}

function $f_do_types_at$(monad_0, types_0, ts_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_0) => {
  return run_jump($f_do$, [monad_0, run_loop($ks$(types_0)), run_loop($f_skip$(run_loop($f_tl$(ts_0)))), run_loop($f_col$(run_loop($f_skip$(run_loop($f_tl$(ts_0))))))]);
}), run_clo((x_1) => {
  return run_jump($f_err$, [ts_0, "expected :"]);
})]);
}

function $f_rewrite_body$(e_0, motive_0, p_0) {
  const body_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Rwt", "", 0, 1, {$: "Con", ["head"]: e_0, ["tail"]: {$: "Con", ["head"]: motive_0, ["tail"]: {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}}})), ["rest"]: ts_0};
}

function $f_equation_type$(a_0, b_0, neg_0, p_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_choose$(neg_0, run_clo((x_0) => {
  return run_jump($kt$, ["All", "_", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Eql", "", 0, 1, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}}})), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Ref", "Empty", 0, 1, {$: "Nil"})), ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Eql", "", 0, 1, {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}}}]);
}))), ["rest"]: ts_0};
}

function $f_array_size$(n_0, ty_0, count_0, p_0) {
  const size_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_app$(run_loop($ref$("Array.new")), {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_choose$(count_0, run_clo((x_0) => {
  return run_jump($f_array_depth$, [size_0]);
}), run_clo((x_1) => {
  return size_0;
}))), ["tail"]: {$: "Con", ["head"]: run_loop($f_namespace$(n_0, ty_0)), ["tail"]: {$: "Nil"}}}})), ["rest"]: ts_0};
}

function $f_list_nodes$(xs_0) {
  if (xs_0.$ === "Nil") {
    return run_jump($kt$, ["Ctr", "Nil", 0, 1, {$: "Nil"}]);
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return run_jump($kt$, ["Ctr", "Con", 0, 1, {$: "Con", ["head"]: x_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_list_nodes$(xt_0)), ["tail"]: {$: "Nil"}}}]);
  }
}

function $f_matcher_tail$(name_0, n_0, p_0) {
  const m_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Mat", name_0, 0, 1, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Con", ["head"]: m_0, ["tail"]: {$: "Nil"}}})), ["rest"]: ts_0};
}

function $f_nat_extend$(a_0, b_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(a_0)), "Ctr")), run_loop($f_eq$(run_loop($nm$(a_0)), "Zero")))), run_clo((x_0) => {
  return b_0;
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(a_0)), "Ctr")), run_loop($f_eq$(run_loop($nm$(a_0)), "Succ")))), run_clo((x_2) => {
  return run_jump($kt$, ["Ctr", "Succ", 0, 1, {$: "Con", ["head"]: run_loop($f_nat_extend$(run_loop($kid$(a_0, 0)), b_0)), ["tail"]: {$: "Nil"}}]);
}), run_clo((x_3) => {
  return run_jump($f_app$, [run_loop($ref$("Nat.add")), {$: "Con", ["head"]: a_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}]);
})]);
})]);
}

function $f_string_decoded$(d_0) {
  const code_0 = d_0["code"];
  const rest_0 = d_0["rest"];
  const err_0 = d_0["error"];
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($kt$, ["Ctr", "SCon", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Ctr", "Chr", 0, 1, {$: "Con", ["head"]: run_loop($f_u32$(code_0)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Con", ["head"]: run_loop($f_string$(rest_0)), ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", err_0, 0, 0, {$: "Nil"}]);
})]);
}

function $f_decode_char$(s_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(s_0)), run_clo((x_0) => {
  return {$: "FDecoded", ["code"]: 0, ["rest"]: "", ["error"]: "expected character"};
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "\\")), run_clo((x_2) => {
  return run_jump($f_decode_escape$, [run_loop($f_tail$(s_0))]);
}), run_clo((x_3) => {
  return {$: "FDecoded", ["code"]: run_loop($Char$to_u32$(run_loop($f_head$(s_0)))), ["rest"]: run_loop($f_tail$(s_0)), ["error"]: ""};
})]);
})]);
}

function $f_char_decoded$(d_0) {
  const code_0 = d_0["code"];
  const rest_0 = d_0["rest"];
  const err_0 = d_0["error"];
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($String$is_empty$(err_0)), run_loop($f_eq$(rest_0, "'")))), run_clo((x_0) => {
  return run_jump($kt$, ["Ctr", "Chr", 0, 1, {$: "Con", ["head"]: run_loop($f_u32$(code_0)), ["tail"]: {$: "Nil"}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "character literal requires one character and a closing quote", 0, 0, {$: "Nil"}]);
})]);
}

function $f_float_read$(m_0) {
  if (m_0.$ === "None") {
    return run_jump($kt$, ["Error", "invalid f32 literal", 0, 0, {$: "Nil"}]);
  } else {
    const v_0 = m_0["value"];
    return run_jump($f_float_bits$, [f32_bits(v_0)]);
  }
}

function $f_u32$(n_0) {
  return run_jump($kt$, ["Ctr", "U32", 0, 1, {$: "Con", ["head"]: run_loop($f_word$(n_0, 32)), ["tail"]: {$: "Nil"}}]);
}

function $f_nat$(n_0) {
  return run_jump($f_choose$, [(n_0 > 256), run_clo((x_0) => {
  return run_jump($app$, [run_loop($ref$("U32.to_nat")), run_loop($f_u32$(n_0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_2) => {
  return run_jump($kt$, ["Ctr", "Zero", 0, 1, {$: "Nil"}]);
}), run_clo((x_3) => {
  return run_jump($kt$, ["Ctr", "Succ", 0, 1, {$: "Con", ["head"]: run_loop($f_nat$(((n_0 - 1) >>> 0))), ["tail"]: {$: "Nil"}}]);
})]);
})]);
}

function $f_match_begin$(ts_0, outer_0, heads_0) {
  const x_0 = run_loop($f_col$(ts_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "case")), (x_0 > outer_0))), run_clo((x_1) => {
  const x_2 = run_loop($f_col$(ts_0));
  return run_jump($f_match_cases$, [ts_0, ((x_2 - 1) >>> 0), heads_0, {$: "Nil"}]);
}), run_clo((x_3) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Match", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Heads", "", 0, 1, heads_0)), ["tail"]: {$: "Nil"}})), ["rest"]: ts_0};
})]);
}

function $f_match_head$(p_0, indent_0, acc_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_match_heads$, [ts_0, indent_0, {$: "Con", ["head"]: n_0, ["tail"]: acc_0}]);
})]);
}

function $f_erased_local$(ts_0) {
  return run_jump($f_statement$, [{$: "FParsed", ["term"]: run_loop($kt$("Ref", run_loop($f_tx$(ts_0)), run_loop($f_atid$(ts_0)), 0, {$: "Nil"})), ["rest"]: run_loop($f_tl$(ts_0))}]);
}

function $f_statement$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=")), run_clo((x_0) => {
  return run_jump($f_let_value$, [n_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_2) => {
  return run_jump($f_typed_let_try$, [n_0, ts_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))]);
}), run_clo((x_3) => {
  return run_jump($f_statement_more$, [{$: "FParsed", ["term"]: n_0, ["rest"]: ts_0}]);
})]);
})]);
}

function $f_scope_call$(t_0, env_0, book_0) {
  return run_jump($f_scope_call_head$, [t_0, env_0, book_0, run_loop($f_scope$(run_loop($kid$(t_0, 0)), env_0, book_0))]);
}

function $f_scope_lower$(t_0, env_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Write")), run_clo((x_0) => {
  return run_jump($f_scope$, [run_loop($kid$(t_0, 0)), env_0, book_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "ADT")), run_clo((x_2) => {
  return run_jump($f_adt$, [t_0, run_loop($f_scope_terms$(run_loop($ks$(t_0)), env_0, book_0)), run_loop($f_find$(run_loop($nm$(t_0)), book_0))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "App")), run_clo((x_4) => {
  return run_jump($f_scope_app$, [run_loop($f_scope$(run_loop($kid$(t_0, 0)), env_0, book_0)), run_loop($f_scope$(run_loop($kid$(t_0, 1)), env_0, book_0))]);
}), run_clo((x_5) => {
  return run_jump($f_scope_base$, [t_0, env_0, book_0]);
})]);
})]);
})]);
}

function $f_resolve_name$(name_0, book_0, ns_0, imports_0) {
  return run_jump($f_choose$, [run_loop($f_declared$(name_0, book_0)), run_clo((x_0) => {
  return run_jump($f_qual_name$, [name_0, ns_0]);
}), run_clo((x_1) => {
  return run_jump($f_alias$, [name_0, imports_0]);
})]);
}

function $f_qual_terms$(ts_0, book_0, ns_0, imports_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_qual_term$(t_0, book_0, ns_0, imports_0)), ["tail"]: run_loop($f_qual_terms$(rest_0, book_0, ns_0, imports_0))};
  }
}

function $sp_mint_body$(d_0, name_0, ty_0, r_0) {
  const x_0 = run_loop($da$(d_0));
  const x_1 = run_loop($dx$(d_0));
  return run_jump($sp_validate$, [run_loop($sp_state$(r_0)), {$: "KDef", ["name"]: name_0, ["kind"]: "Def", ["arity"]: ((x_0 - x_1) >>> 0), ["templates"]: 0, ["typ"]: ty_0, ["value"]: run_loop($sp_value$(r_0)), ["ctors"]: {$: "Nil"}, ["native"]: false, ["unsafe"]: run_loop($du$(d_0))}]);
}

function $sp_shifts$(ts_0, offset_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($sp_shift$(h_0, offset_0)), ["tail"]: run_loop($sp_shifts$(rest_0, offset_0))};
  }
}

function $f_do$(monad_0, types_0, ts_0, indent_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "return")), run_clo((x_0) => {
  return run_jump($f_do_return$, [monad_0, types_0, run_loop($f_atid$(ts_0)), run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))]);
}), run_clo((x_1) => {
  return run_jump($f_do_statement$, [monad_0, types_0, run_loop($f_expr$(ts_0, 0)), indent_0]);
})]);
}

function $f_array_depth$(size_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(size_0)), "Literal")), run_clo((x_0) => {
  return run_jump($f_power_depth$, [run_loop($nm$(size_0)), 0]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "array count must be a literal power of two", 0, 0, {$: "Nil"}]);
})]);
}

function $f_decode_escape$(s_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "u")), run_loop($Char$is_eq$(run_loop($f_head$(run_loop($f_tail$(s_0)))), "{")))), run_clo((x_0) => {
  return run_jump($f_decode_unicode$, [run_loop($f_tail$(run_loop($f_tail$(s_0)))), 0, 0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_escape_valid$(run_loop($f_head$(s_0)))), run_clo((x_2) => {
  return {$: "FDecoded", ["code"]: run_loop($f_escape_code$(run_loop($f_head$(s_0)))), ["rest"]: run_loop($f_tail$(s_0)), ["error"]: ""};
}), run_clo((x_3) => {
  return {$: "FDecoded", ["code"]: 0, ["rest"]: s_0, ["error"]: "invalid character escape"};
})]);
})]);
}

function $f_float_bits$(bits_0) {
  const x_0 = ((bits_0 & 2139095040) >>> 0);
  return run_jump($f_choose$, [(x_0 === 2139095040), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "float literal must be finite", 0, 0, {$: "Nil"}]);
}), run_clo((x_2) => {
  return run_jump($kt$, ["Ctr", "F32", 0, 1, {$: "Con", ["head"]: run_loop($f_word$(bits_0, 32)), ["tail"]: {$: "Nil"}}]);
})]);
}

function $f_word$(n_0, bits_0) {
  return run_jump($f_choose$, [(bits_0 === 0), run_clo((x_0) => {
  return run_jump($kt$, ["Ctr", "WNil", 0, 1, {$: "Nil"}]);
}), run_clo((x_1) => {
  const x_2 = ((n_0 & 1) >>> 0);
  return run_jump($kt$, ["Ctr", "WCon", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Ctr", run_loop($f_choose$((x_2 === 0), run_clo((x_3) => {
  return "False";
}), run_clo((x_4) => {
  return "True";
}))), 0, 1, {$: "Nil"})), ["tail"]: {$: "Con", ["head"]: run_loop($f_word$((1n >= 32n ? 0 : (n_0 >>> Number(1n)) >>> 0), ((bits_0 - 1) >>> 0))), ["tail"]: {$: "Nil"}}}]);
})]);
}

function $f_match_cases$(ts_0, indent_0, heads_0, rows_0) {
  const x_0 = run_loop($f_col$(ts_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), "case")), (x_0 > indent_0))), run_clo((x_1) => {
  return run_jump($f_case_pats$, [run_loop($f_tl$(ts_0)), indent_0, heads_0, rows_0, {$: "Nil"}]);
}), run_clo((x_2) => {
  return {$: "FParsed", ["term"]: run_loop($kt$("Match", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Heads", "", 0, 1, heads_0)), ["tail"]: run_loop($List$reverse$(rows_0))})), ["rest"]: ts_0};
})]);
}

function $f_let_value$(pat_0, p_0) {
  const v_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_let_body$, [pat_0, v_0, run_loop($f_body$(ts_0))]);
}

function $f_typed_let_try$(n_0, old_0, p_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=")), run_clo((x_0) => {
  return run_jump($f_let_value$, [n_0, run_loop($f_let_ann$(ty_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0))))]);
}), run_clo((x_1) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: old_0};
})]);
}

function $f_statement_more$(p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Write")), run_clo((x_0) => {
  return run_jump($f_write_statement$, [n_0, ts_0]);
}), run_clo((x_1) => {
  const x_2 = run_loop($f_kind$(ts_0));
  const x_3 = (x_2 === 1);
  const x_4 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "+bind"));
  return run_jump($f_choose$, [(x_3 || x_4), run_clo((x_5) => {
  return run_jump($f_parallel$, [ts_0, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Nil"}}]);
}), run_clo((x_6) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
})]);
})]);
}

function $f_scope_call_head$(t_0, env_0, book_0, head_0) {
  return run_jump($f_choose$, [run_loop($f_templates_valid$(run_loop($f_tail_terms$(run_loop($ks$(t_0)))), run_loop($f_choose$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(head_0)), "Ref")), run_loop($f_eq$(run_loop($tg$(run_loop($kid$(t_0, 0)))), "Ref")))), run_clo((x_0) => {
  return run_jump($dx$, [run_loop($f_find$(run_loop($nm$(head_0)), book_0))]);
}), run_clo((x_1) => {
  return 0;
}))), false)), run_clo((x_2) => {
  return run_jump($f_scope_apply_many$, [head_0, run_loop($f_scope_call_args$(run_loop($f_tail_terms$(run_loop($ks$(t_0)))), env_0, book_0))]);
}), run_clo((x_3) => {
  return run_jump($kt$, ["Error", "~ arguments require leading template slots on a named template definition", 0, 0, {$: "Nil"}]);
})]);
}

function $f_adt$(t_0, args_0, d_0) {
  return run_jump($f_adt_fill$, [t_0, args_0, run_loop($da$(d_0)), run_loop($f_leading_quants$(run_loop($dt$(d_0))))]);
}

function $f_scope_terms$(xs_0, env_0, book_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_scope$(x_0, env_0, book_0)), ["tail"]: run_loop($f_scope_terms$(xt_0, env_0, book_0))};
  }
}

function $f_scope_app$(f_0, x_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(f_0)), "Lam")), run_clo((x_1) => {
  return run_jump($f_sub$, [run_loop($kid$(f_0, 0)), run_loop($ix$(f_0)), x_0]);
}), run_clo((x_2) => {
  return run_jump($app$, [f_0, x_0]);
})]);
}

function $f_scope_base$(t_0, env_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Ref")), run_clo((x_0) => {
  return run_jump($f_scope_ref$, [t_0, run_loop($f_env$(run_loop($nm$(t_0)), env_0)), book_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Literal")), run_clo((x_2) => {
  return run_jump($f_literal$, [run_loop($nm$(t_0))]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "All")), run_clo((x_4) => {
  return run_jump($kt$, ["All", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), {$: "Con", ["head"]: run_loop($f_scope$(run_loop($kid$(t_0, 0)), env_0, book_0)), ["tail"]: {$: "Con", ["head"]: run_loop($f_scope$(run_loop($kid$(t_0, 1)), {$: "Con", ["head"]: run_loop($kt$("Var", run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($qt$(t_0)), {$: "Nil"})), ["tail"]: env_0}, book_0)), ["tail"]: {$: "Nil"}}}]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Lam")), run_clo((x_6) => {
  return run_jump($f_scope_lambda$, [t_0, env_0, book_0]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Body")), run_clo((x_8) => {
  return run_jump($ff_term$, [run_loop($ff_flat$(run_loop($f_scope_body$(run_loop($kid$(t_0, 1)), run_loop($f_concat$(run_loop($f_vars$(run_loop($ks$(run_loop($kid$(t_0, 0)))))), env_0)), book_0)), run_loop($f_vars$(run_loop($ks$(run_loop($kid$(t_0, 0)))))), run_loop($ix$(t_0))))]);
}), run_clo((x_9) => {
  const x_10 = run_loop($f_eq$(run_loop($tg$(t_0)), "Local"));
  const x_11 = run_loop($f_eq$(run_loop($tg$(t_0)), "Match"));
  return run_jump($f_choose$, [(x_10 || x_11), run_clo((x_12) => {
  return run_jump($f_flat$, [run_loop($f_scope_body$(t_0, env_0, book_0)), {$: "Nil"}]);
}), run_clo((x_13) => {
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_scope_terms$(run_loop($ks$(t_0)), env_0, book_0)), ["removed"]: run_loop($rm$(t_0))};
})]);
})]);
})]);
})]);
})]);
})]);
}

function $f_declared$(name_0, book_0) {
  if (book_0.$ === "Nil") {
    return false;
  } else {
    const d_0 = book_0["head"];
    const ds_0 = book_0["tail"];
    const x_0 = run_loop($f_eq$(name_0, run_loop($f_dn$(d_0))));
    const x_1 = run_loop($f_declared$(name_0, run_loop($dc$(d_0))));
    const x_2 = (x_0 || x_1);
    const x_3 = run_loop($f_declared$(name_0, ds_0));
    return (x_2 || x_3);
  }
}

function $sp_validate$(st_0, d_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($sp_error$(st_0)), "")), run_clo((x_0) => {
  return run_jump($sp_validate_done$, [st_0, d_0, run_loop($check_definition$(run_loop($sp_book$(st_0)), d_0))]);
}), run_clo((x_1) => {
  return {$: "KSpecTerm", ["state"]: st_0, ["term"]: run_loop($ref$(run_loop($dn$(d_0))))};
})]);
}

function $f_do_return$(monad_0, types_0, position_0, p_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_app$(run_loop($kt$("Ref", (monad_0 + ".pure"), position_0, 1, {$: "Nil"})), run_loop($f_concat$(types_0, {$: "Con", ["head"]: n_0, ["tail"]: {$: "Nil"}})))), ["rest"]: ts_0};
}

function $f_do_statement$(monad_0, types_0, p_0, indent_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_loop($f_eq$(run_loop($tg$(n_0)), "Ref")))), run_loop($f_alias_valid$(run_loop($nm$(n_0)))))), run_clo((x_0) => {
  return run_jump($f_do_annotated$, [monad_0, types_0, n_0, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 1)), indent_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<-")), run_clo((x_2) => {
  return run_jump($f_do_value$, [monad_0, types_0, run_loop($kt$("Ref", "_", run_loop($ix$(n_0)), 1, {$: "Nil"})), n_0, false, run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), indent_0]);
}), run_clo((x_3) => {
  const x_4 = run_loop($f_col$(run_loop($f_skip$(ts_0))));
  const x_5 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), ";"));
  const x_6 = (x_4 === indent_0);
  return run_jump($f_choose$, [run_loop($Bool$and$((x_5 || x_6), run_loop($Bool$not$(run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(ts_0)))), "<eof>")))))), run_clo((x_7) => {
  return run_jump($f_do_value$, [monad_0, types_0, run_loop($kt$("Ref", "_", run_loop($ix$(n_0)), 1, {$: "Nil"})), run_loop($ref$("Unit")), false, {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0}, indent_0]);
}), run_clo((x_8) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
})]);
})]);
})]);
}

function $f_power_depth$(s_0, n_0) {
  const x_0 = run_loop($String$is_empty$(s_0));
  const x_1 = run_loop($f_eq$(s_0, "n"));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($f_power_bits$, [n_0, 0]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($Char$is_digit$(run_loop($f_head$(s_0)))), run_clo((x_4) => {
  const x_5 = run_loop($Char$to_u32$(run_loop($f_head$(s_0))));
  const x_6 = (Math.imul(n_0, 10) >>> 0);
  const x_7 = ((x_5 - 48) >>> 0);
  return run_jump($f_power_depth$, [run_loop($f_tail$(s_0)), ((x_6 + x_7) >>> 0)]);
}), run_clo((x_8) => {
  return run_jump($kt$, ["Error", "array count must be a literal power of two", 0, 0, {$: "Nil"}]);
})]);
})]);
}

function $f_decode_unicode$(s_0, code_0, count_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Char$is_eq$(run_loop($f_head$(s_0)), "}")), (count_0 > 0))), run_clo((x_0) => {
  return {$: "FDecoded", ["code"]: code_0, ["rest"]: run_loop($f_tail$(s_0)), ["error"]: ""};
}), run_clo((x_1) => {
  const x_2 = run_loop($f_hex$(run_loop($f_head$(s_0))));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_2 < 16), (count_0 < 6))), run_clo((x_3) => {
  const x_4 = (Math.imul(code_0, 16) >>> 0);
  const x_5 = run_loop($f_hex$(run_loop($f_head$(s_0))));
  return run_jump($f_decode_unicode$, [run_loop($f_tail$(s_0)), ((x_4 + x_5) >>> 0), ((count_0 + 1) >>> 0)]);
}), run_clo((x_6) => {
  return {$: "FDecoded", ["code"]: 0, ["rest"]: s_0, ["error"]: "invalid Unicode escape"};
})]);
})]);
}

function $f_escape_valid$(c_0) {
  const x_0 = run_loop($Char$is_eq$(c_0, "n"));
  const x_1 = run_loop($Char$is_eq$(c_0, "t"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($Char$is_eq$(c_0, "r"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($Char$is_eq$(c_0, "0"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($Char$is_eq$(c_0, "\\"));
  const x_8 = (x_6 || x_7);
  const x_9 = run_loop($Char$is_eq$(c_0, "'"));
  const x_10 = (x_8 || x_9);
  const x_11 = run_loop($Char$is_eq$(c_0, "\""));
  return (x_10 || x_11);
}

function $f_case_pats$(ts_0, indent_0, heads_0, rows_0, pats_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), ":")), run_clo((x_0) => {
  return run_jump($f_case_body$, [run_loop($f_body_context$(run_loop($f_tl$(ts_0)), ((indent_0 + 1) >>> 0))), indent_0, heads_0, rows_0, run_loop($List$reverse$(pats_0))]);
}), run_clo((x_1) => {
  return run_jump($f_case_pat$, [run_loop($f_expr$(run_loop($f_choose$(run_loop($f_eq$(run_loop($f_tx$(ts_0)), ",")), run_clo((x_2) => {
  return run_jump($f_tl$, [ts_0]);
}), run_clo((x_3) => {
  return ts_0;
}))), 0)), indent_0, heads_0, rows_0, pats_0]);
})]);
}

function $f_let_body$(pat_0, v_0, p_0) {
  const b_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Local", "", 0, 1, {$: "Con", ["head"]: pat_0, ["tail"]: {$: "Con", ["head"]: v_0, ["tail"]: {$: "Con", ["head"]: b_0, ["tail"]: {$: "Nil"}}}})), ["rest"]: ts_0};
}

function $f_let_ann$(ty_0, p_0) {
  const v_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Ann", "", 0, 1, {$: "Con", ["head"]: v_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}})), ["rest"]: ts_0};
}

function $f_write_statement$(n_0, ts_0) {
  const x_0 = run_loop($ix$(n_0));
  const x_1 = run_loop($f_col$(run_loop($f_skip$(ts_0))));
  const x_2 = ((x_0 & 65535) >>> 0);
  const x_3 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), ";"));
  const x_4 = (x_1 === x_2);
  return run_jump($f_choose$, [run_loop($Bool$and$((x_3 || x_4), run_loop($Bool$not$(run_loop($f_eq$(run_loop($f_tx$(run_loop($f_skip$(ts_0)))), "<eof>")))))), run_clo((x_5) => {
  return run_jump($f_let_value$, [run_loop($kt$("Ref", run_loop($nm$(n_0)), run_loop($ix$(n_0)), 1, {$: "Nil"})), {$: "FParsed", ["term"]: run_loop($kid$(n_0, 0)), ["rest"]: ts_0}]);
}), run_clo((x_6) => {
  return {$: "FParsed", ["term"]: run_loop($kid$(n_0, 0)), ["rest"]: ts_0};
})]);
}

function $f_parallel$(ts_0, pats_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=")), run_clo((x_0) => {
  return run_jump($f_parallel_values$, [run_loop($f_tl$(ts_0)), run_loop($List$reverse$(pats_0)), run_loop($f_len$(pats_0)), {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($f_parallel_pat$, [run_loop($f_expr$(ts_0, 0)), pats_0]);
})]);
}

function $f_templates_valid$(args_0, left_0, ordinary_0) {
  if (args_0.$ === "Nil") {
    return true;
  } else {
    const a_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(a_0)), "TemplateArg")), run_clo((x_0) => {
    return run_jump($Bool$and$, [run_loop($Bool$and$(run_loop($Bool$not$(ordinary_0)), (left_0 > 0))), run_loop($f_templates_valid$(rest_0, ((left_0 - 1) >>> 0), false))]);
}), run_clo((x_1) => {
    return run_jump($f_templates_valid$, [rest_0, left_0, true]);
})]);
  }
}

function $f_scope_apply_many$(head_0, args_0) {
  if (args_0.$ === "Nil") {
    return head_0;
  } else {
    const a_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return run_jump($f_scope_apply_many$, [run_loop($f_scope_app$(head_0, a_0)), rest_0]);
  }
}

function $f_scope_call_args$(args_0, env_0, book_0) {
  if (args_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const a_0 = args_0["head"];
    const rest_0 = args_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_scope$(run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(a_0)), "TemplateArg")), run_clo((x_0) => {
    return run_jump($kid$, [a_0, 0]);
}), run_clo((x_1) => {
    return a_0;
}))), env_0, book_0)), ["tail"]: run_loop($f_scope_call_args$(rest_0, env_0, book_0))};
  }
}

function $f_adt_fill$(t_0, args_0, arity_0, g_0) {
  const x_0 = run_loop($f_len$(args_0));
  const x_1 = ((x_0 + g_0) >>> 0);
  return run_jump($f_choose$, [(x_1 === arity_0), run_clo((x_2) => {
  const x_3 = run_loop($qt$(t_0));
  return {$: "KTerm", ["tag"]: "ADT", ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_concat$(run_loop($f_quants$(g_0, run_loop($f_choose$((x_3 === 2), run_clo((x_4) => {
  return 2;
}), run_clo((x_5) => {
  return 1;
}))))), args_0)), ["removed"]: run_loop($rm$(t_0))};
}), run_clo((x_6) => {
  const x_7 = run_loop($qt$(t_0));
  return {$: "KTerm", ["tag"]: "ADT", ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_choose$((x_7 === 2), run_clo((x_8) => {
  return run_jump($f_concat$, [run_loop($f_quants$(g_0, 2)), run_loop($f_drop_terms$(args_0, g_0))]);
}), run_clo((x_9) => {
  return args_0;
}))), ["removed"]: run_loop($rm$(t_0))};
})]);
}

function $f_leading_quants$(ty_0) {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(ty_0)), "All")), run_loop($f_eq$(run_loop($tg$(run_loop($kid$(ty_0, 0)))), "Qnt")))), run_clo((x_0) => {
  const x_1 = run_loop($f_leading_quants$(run_loop($kid$(ty_0, 1))));
  return ((1 + x_1) >>> 0);
}), run_clo((x_2) => {
  return 0;
})]);
}

function $f_sub$(t_0, id_0, v_0) {
  const x_0 = run_loop($ix$(t_0));
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(t_0)), "Var")), (x_0 === id_0))), run_clo((x_1) => {
  return v_0;
}), run_clo((x_2) => {
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($ix$(t_0)), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($f_subs$(run_loop($ks$(t_0)), id_0, v_0)), ["removed"]: run_loop($rm$(t_0))};
})]);
}

function $f_scope_ref$(t_0, bound_0, book_0) {
  return run_jump($f_scope_reference$, [t_0, bound_0, book_0]);
}

function $f_scope_lambda$(t_0, env_0, book_0) {
  const x_0 = run_loop($qt$(t_0));
  const x_3 = run_loop($qt$(t_0));
  return run_jump($f_scope_lambda_var$, [t_0, env_0, book_0, run_loop($kt$(run_loop($f_choose$((x_0 === 4), run_clo((x_1) => {
  return "RewriteVar";
}), run_clo((x_2) => {
  return "Var";
}))), run_loop($nm$(t_0)), run_loop($ix$(t_0)), run_loop($f_choose$((x_3 === 4), run_clo((x_4) => {
  return 1;
}), run_clo((x_5) => {
  return run_jump($qt$, [t_0]);
}))), {$: "Nil"}))]);
}

function $ff_term$(r_0) {
  const t_0 = r_0["term"];
  const next_0 = r_0["next"];
  return t_0;
}

function $ff_flat$(t_0, vars_0, next_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Match")), run_clo((x_0) => {
  return run_jump($ff_match$, [run_loop($ks$(run_loop($kid$(t_0, 0)))), run_loop($f_tail_terms$(run_loop($ks$(t_0)))), vars_0, next_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Local")), run_clo((x_2) => {
  return run_jump($ff_local$, [t_0, vars_0, next_0]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Parallel")), run_clo((x_4) => {
  return run_jump($ff_parallel$, [t_0, vars_0, run_loop($ff_flat$(run_loop($kid$(t_0, 2)), run_loop($ks$(run_loop($kid$(t_0, 0)))), next_0))]);
}), run_clo((x_5) => {
  return {$: "FFlatten", ["term"]: run_loop($f_lbind$(vars_0, t_0)), ["next"]: next_0};
})]);
})]);
})]);
}

function $f_scope_body$(t_0, env_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Parallel")), run_clo((x_0) => {
  return run_jump($f_scope_parallel$, [t_0, env_0, book_0]);
}), run_clo((x_1) => {
  return run_jump($f_scope_body_base$, [t_0, env_0, book_0]);
})]);
}

function $f_vars$(xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Var", run_loop($nm$(x_0)), run_loop($ix$(x_0)), 1, {$: "Nil"})), ["tail"]: run_loop($f_vars$(xt_0))};
  }
}

function $f_flat$(t_0, vars_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Parallel")), run_clo((x_0) => {
  return run_jump($f_flat_parallel$, [t_0, vars_0]);
}), run_clo((x_1) => {
  return run_jump($f_flat_base$, [t_0, vars_0]);
})]);
}

function $sp_validate_done$(st_0, d_0, error_0) {
  return run_jump($kc$, [run_loop($String$eq$(error_0, "")), run_clo((x_0) => {
  return {$: "KSpecTerm", ["state"]: {$: "KSpecState", ["book"]: {$: "Con", ["head"]: d_0, ["tail"]: run_loop($index_remove$(run_loop($sp_book$(st_0)), run_loop($dn$(d_0))))}, ["memo"]: run_loop($sp_done_memo$(run_loop($sp_memo$(st_0)), run_loop($dn$(d_0)))), ["serial"]: run_loop($sp_serial$(st_0)), ["fresh"]: run_loop($sp_fresh$(st_0)), ["error"]: run_loop($sp_error$(st_0)), ["templates"]: run_loop($sp_templates$(st_0))}, ["term"]: run_loop($ref$(run_loop($dn$(d_0))))};
}), run_clo((x_1) => {
  const x_2 = run_loop($dn$(d_0));
  const x_3 = (": " + error_0);
  return {$: "KSpecTerm", ["state"]: run_loop($sp_fail$(st_0, (x_2 + x_3))), ["term"]: run_loop($ref$(run_loop($dn$(d_0))))};
})]);
}

function $check_definition$(book_0, d_0) {
  return run_jump($ce$, [run_loop($check_definition_result$(book_0, d_0))]);
}

function $f_do_annotated$(monad_0, types_0, binder_0, p_0, indent_0) {
  const ty_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(ty_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: ty_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  const x_2 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "="));
  const x_3 = run_loop($f_eq$(run_loop($f_tx$(ts_0)), "<-"));
  return run_jump($f_choose$, [(x_2 || x_3), run_clo((x_4) => {
  return run_jump($f_do_value$, [monad_0, types_0, binder_0, ty_0, run_loop($f_eq$(run_loop($f_tx$(ts_0)), "=")), run_loop($f_expr$(run_loop($f_tl$(ts_0)), 0)), indent_0]);
}), run_clo((x_5) => {
  return run_jump($f_err$, [ts_0, "expected <-"]);
})]);
})]);
}

function $f_do_value$(monad_0, types_0, binder_0, ty_0, pure_0, p_0, indent_0) {
  const v_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_do_tail$, [monad_0, types_0, binder_0, ty_0, pure_0, v_0, run_loop($f_do$(monad_0, types_0, run_loop($f_skip$(ts_0)), indent_0))]);
}

function $f_power_bits$(n_0, d_0) {
  return run_jump($f_choose$, [(n_0 === 1), run_clo((x_0) => {
  return run_jump($f_nat$, [d_0]);
}), run_clo((x_1) => {
  const x_2 = ((n_0 & 1) >>> 0);
  const x_3 = (n_0 === 0);
  const x_4 = (x_2 === 1);
  return run_jump($f_choose$, [(x_3 || x_4), run_clo((x_5) => {
  return run_jump($kt$, ["Error", "array count must be a positive power of two", 0, 0, {$: "Nil"}]);
}), run_clo((x_6) => {
  return run_jump($f_power_bits$, [(1n >= 32n ? 0 : (n_0 >>> Number(1n)) >>> 0), ((d_0 + 1) >>> 0)]);
})]);
})]);
}

function $f_hex$(c_0) {
  return run_jump($f_choose$, [run_loop($Char$is_digit$(c_0)), run_clo((x_0) => {
  const x_1 = run_loop($Char$to_u32$(c_0));
  return ((x_1 - 48) >>> 0);
}), run_clo((x_2) => {
  const x_3 = run_loop($Char$to_u32$(run_loop($Char$to_lower$(c_0))));
  const x_4 = run_loop($Char$to_u32$(run_loop($Char$to_lower$(c_0))));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_3 >= 97), (x_4 <= 102))), run_clo((x_5) => {
  const x_6 = run_loop($Char$to_u32$(run_loop($Char$to_lower$(c_0))));
  return ((x_6 - 87) >>> 0);
}), run_clo((x_7) => {
  return 16;
})]);
})]);
}

function $f_case_body$(p_0, indent_0, heads_0, rows_0, pats_0) {
  return run_jump($f_case_checked$, [p_0, indent_0, heads_0, rows_0, pats_0]);
}

function $f_case_pat$(p_0, indent_0, heads_0, rows_0, pats_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_case_pats$, [ts_0, indent_0, heads_0, rows_0, {$: "Con", ["head"]: n_0, ["tail"]: pats_0}]);
})]);
}

function $f_parallel_values$(ts_0, pats_0, left_0, vals_0) {
  return run_jump($f_choose$, [(left_0 === 0), run_clo((x_0) => {
  return run_jump($f_parallel_body$, [pats_0, run_loop($List$reverse$(vals_0)), run_loop($f_body$(ts_0))]);
}), run_clo((x_1) => {
  return run_jump($f_parallel_value$, [run_loop($f_expr$(ts_0, 0)), pats_0, left_0, vals_0]);
})]);
}

function $f_parallel_pat$(p_0, pats_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_parallel$, [ts_0, {$: "Con", ["head"]: n_0, ["tail"]: pats_0}]);
})]);
}

function $f_quants$(n_0, q_0) {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_0) => {
  return {$: "Nil"};
}), run_clo((x_1) => {
  return {$: "Con", ["head"]: run_loop($qua$(q_0)), ["tail"]: run_loop($f_quants$(((n_0 - 1) >>> 0), q_0))};
})]);
}

function $f_drop_terms$(ts_0, n_0) {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_0) => {
  return ts_0;
}), run_clo((x_1) => {
  return run_jump($f_drop_terms$, [run_loop($f_tail_terms$(ts_0)), ((n_0 - 1) >>> 0)]);
})]);
}

function $f_subs$(ts_0, id_0, v_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_sub$(t_0, id_0, v_0)), ["tail"]: run_loop($f_subs$(rest_0, id_0, v_0))};
  }
}

function $f_scope_reference$(t_0, bound_0, book_0) {
  const x_0 = run_loop($qt$(t_0));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_0 === 2), run_loop($Bool$not$(run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(run_loop($nm$(t_0)), book_0)))), "ADT")))))), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "+ marks a binder or a quantified datatype, not a value reference", 0, 0, {$: "Nil"}]);
}), run_clo((x_2) => {
  const x_3 = run_loop($qt$(t_0));
  const x_4 = run_loop($Bool$not$(run_loop($f_eq$(run_loop($tg$(bound_0)), "Absent"))));
  const x_5 = run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(run_loop($nm$(t_0)), book_0)))), "ADT"));
  return run_jump($f_choose$, [run_loop($Bool$and$((x_3 === 3), (x_4 || x_5))), run_clo((x_6) => {
  return run_jump($kt$, ["Error", "offload requires a named definition", 0, 0, {$: "Nil"}]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($f_eq$(run_loop($tg$(bound_0)), "Absent")))), run_clo((x_8) => {
  return run_jump($kt$, ["Var", run_loop($nm$(bound_0)), run_loop($ix$(bound_0)), run_loop($qt$(bound_0)), {$: "Nil"}]);
}), run_clo((x_9) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($dk$(run_loop($f_find$(run_loop($nm$(t_0)), book_0)))), "ADT")), run_clo((x_10) => {
  return run_jump($f_adt$, [t_0, {$: "Nil"}, run_loop($f_find$(run_loop($nm$(t_0)), book_0))]);
}), run_clo((x_11) => {
  return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Char$is_eq$(run_loop($f_head$(run_loop($nm$(t_0)))), ".")), run_loop($Bool$not$(run_loop($Char$is_eq$(run_loop($f_head$(run_loop($f_tail$(run_loop($nm$(t_0)))))), ".")))))), run_clo((x_12) => {
  const x_13 = run_loop($f_operator_display$(run_loop($nm$(t_0)), {$: "Con", ["head"]: "+", ["tail"]: {$: "Con", ["head"]: "-", ["tail"]: {$: "Con", ["head"]: "*", ["tail"]: {$: "Con", ["head"]: "/", ["tail"]: {$: "Con", ["head"]: "%", ["tail"]: {$: "Con", ["head"]: "<", ["tail"]: {$: "Con", ["head"]: ">op", ["tail"]: {$: "Con", ["head"]: "<=", ["tail"]: {$: "Con", ["head"]: ">=", ["tail"]: {$: "Con", ["head"]: "<<", ["tail"]: {$: "Con", ["head"]: ">>op", ["tail"]: {$: "Con", ["head"]: ".&.", ["tail"]: {$: "Con", ["head"]: ".|.", ["tail"]: {$: "Con", ["head"]: ".^.", ["tail"]: {$: "Nil"}}}}}}}}}}}}}}}));
  const x_14 = (x_13 + " b : Nat))");
  return run_jump($kt$, ["Error", ("a type for this operator (write (a " + x_14), run_loop($ix$(t_0)), 0, {$: "Nil"}]);
}), run_clo((x_15) => {
  return t_0;
})]);
})]);
})]);
})]);
})]);
}

function $f_scope_lambda_var$(t_0, env_0, book_0, v_0) {
  return run_jump($f_flat$, [run_loop($f_scope_body$(run_loop($kid$(t_0, 0)), {$: "Con", ["head"]: v_0, ["tail"]: env_0}, book_0)), {$: "Con", ["head"]: run_loop($kt$("Var", run_loop($nm$(v_0)), run_loop($ix$(v_0)), run_loop($qt$(v_0)), {$: "Nil"})), ["tail"]: {$: "Nil"}}]);
}

function $ff_match$(heads_0, rows_0, vars_0, next_0) {
  if (heads_0.$ === "Nil") {
    const x_0 = run_loop($f_len$(rows_0));
    return run_jump($f_choose$, [(x_0 === 0), run_clo((x_1) => {
    return {$: "FFlatten", ["term"]: run_loop($atom$("Efq")), ["next"]: next_0};
}), run_clo((x_2) => {
    return run_jump($ff_flat$, [run_loop($kid$(run_loop($terms_at$(rows_0, 0)), 1)), vars_0, next_0]);
})]);
  } else {
    const h_0 = heads_0["head"];
    const hs_0 = heads_0["tail"];
    const x_3 = run_loop($f_len$(rows_0));
    return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(run_loop($f_first_ctor$(rows_0)))), "Absent")), (x_3 > 0))), run_loop($f_has_id$(vars_0, run_loop($ix$(h_0)))))), run_clo((x_4) => {
    return run_jump($ff_match$, [hs_0, run_loop($f_var_rows$(rows_0, h_0)), run_loop($f_mark_vars$(vars_0, run_loop($ix$(h_0)), run_loop($f_mark_rows$(rows_0, run_loop($qt$(h_0)))))), next_0]);
}), run_clo((x_5) => {
    return run_jump($ff_column$, [h_0, hs_0, rows_0, vars_0, next_0]);
})]);
  }
}

function $ff_local$(t_0, vars_0, next_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(run_loop($kid$(t_0, 0)))), "Ctr")), run_clo((x_0) => {
  return run_jump($ff_match$, [{$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Nil"}}, {$: "Con", ["head"]: run_loop($kt$("Row", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 2)), ["tail"]: {$: "Nil"}}})), ["tail"]: {$: "Nil"}}, vars_0, next_0]);
}), run_clo((x_1) => {
  return run_jump($ff_let$, [t_0, vars_0, run_loop($ff_flat$(run_loop($kid$(t_0, 2)), {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}}, next_0))]);
})]);
}

function $ff_parallel$(t_0, vars_0, r_0) {
  const body_0 = r_0["term"];
  const next_0 = r_0["next"];
  return {$: "FFlatten", ["term"]: run_loop($f_lbind$(vars_0, run_loop($kt$("Let", "", 0, 1, run_loop($f_concat$(run_loop($f_parallel_binds$(run_loop($ks$(run_loop($kid$(t_0, 0)))), run_loop($ks$(run_loop($kid$(t_0, 1)))))), {$: "Con", ["head"]: run_loop($f_unlamb$(body_0, run_loop($f_len$(run_loop($ks$(run_loop($kid$(t_0, 0)))))))), ["tail"]: {$: "Nil"}})))))), ["next"]: next_0};
}

function $f_lbind$(pars_0, body_0) {
  if (pars_0.$ === "Nil") {
    return body_0;
  } else {
    const p_0 = pars_0["head"];
    const ps_0 = pars_0["tail"];
    return run_jump($kt$, ["Lam", run_loop($nm$(p_0)), run_loop($ix$(p_0)), run_loop($qt$(p_0)), {$: "Con", ["head"]: run_loop($f_lbind$(ps_0, body_0)), ["tail"]: {$: "Nil"}}]);
  }
}

function $f_scope_parallel$(t_0, env_0, book_0) {
  return run_jump($f_scope_parallel_pats$, [t_0, run_loop($f_patterns$(run_loop($ks$(run_loop($kid$(t_0, 0)))))), env_0, book_0]);
}

function $f_scope_body_base$(t_0, env_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Local")), run_clo((x_0) => {
  return run_jump($f_scope_local$, [t_0, run_loop($f_patterns$({$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}})), env_0, book_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Match")), run_clo((x_2) => {
  return run_jump($kt$, ["Match", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Heads", "", 0, 1, run_loop($f_scope_terms$(run_loop($ks$(run_loop($kid$(t_0, 0)))), env_0, book_0)))), ["tail"]: run_loop($f_scope_rows$(run_loop($f_tail_terms$(run_loop($ks$(t_0)))), env_0, book_0))}]);
}), run_clo((x_3) => {
  return run_jump($f_scope$, [t_0, env_0, book_0]);
})]);
})]);
}

function $f_flat_parallel$(t_0, vars_0) {
  return run_jump($f_lbind$, [vars_0, run_loop($kt$("Let", "", 0, 1, run_loop($f_concat$(run_loop($f_parallel_binds$(run_loop($ks$(run_loop($kid$(t_0, 0)))), run_loop($ks$(run_loop($kid$(t_0, 1)))))), {$: "Con", ["head"]: run_loop($f_unlamb$(run_loop($f_flat$(run_loop($kid$(t_0, 2)), run_loop($ks$(run_loop($kid$(t_0, 0)))))), run_loop($f_len$(run_loop($ks$(run_loop($kid$(t_0, 0)))))))), ["tail"]: {$: "Nil"}}))))]);
}

function $f_flat_base$(t_0, vars_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Match")), run_clo((x_0) => {
  return run_jump($f_flat_match$, [run_loop($ks$(run_loop($kid$(t_0, 0)))), run_loop($f_tail_terms$(run_loop($ks$(t_0)))), vars_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(t_0)), "Local")), run_clo((x_2) => {
  return run_jump($f_flat_local$, [t_0, vars_0]);
}), run_clo((x_3) => {
  return run_jump($f_lbind$, [vars_0, t_0]);
})]);
})]);
}

function $sp_done_memo$(ms_0, name_0) {
  if (ms_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ms_0["head"];
    const rest_0 = ms_0["tail"];
    return {$: "Con", ["head"]: run_loop($kc$(run_loop($String$eq$(run_loop($sp_mname$(h_0)), name_0)), run_clo((x_0) => {
    return {$: "KSpecMemo", ["template"]: run_loop($sp_mtemplate$(h_0)), ["key"]: run_loop($sp_mkey$(h_0)), ["name"]: run_loop($sp_mname$(h_0)), ["active"]: false};
}), run_clo((x_1) => {
    return h_0;
}))), ["tail"]: run_loop($sp_done_memo$(rest_0, name_0))};
  }
}

function $f_do_tail$(monad_0, types_0, binder_0, ty_0, pure_0, v_0, p_0) {
  const body_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($f_choose$(pure_0, run_clo((x_0) => {
  return run_jump($kt$, ["Local", "Do", 0, 1, {$: "Con", ["head"]: binder_0, ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Ann", "", 0, 1, {$: "Con", ["head"]: v_0, ["tail"]: {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}}})), ["tail"]: {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}}}]);
}), run_clo((x_1) => {
  return run_jump($f_app$, [run_loop($kt$("Ref", (monad_0 + ".bind"), run_loop($ix$(binder_0)), 1, {$: "Nil"})), run_loop($f_concat$(run_loop($f_do_bind_types$(types_0, ty_0)), {$: "Con", ["head"]: v_0, ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Lam", run_loop($nm$(binder_0)), run_loop($ix$(binder_0)), run_loop($qt$(binder_0)), {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Nil"}}}))]);
}))), ["rest"]: ts_0};
}

function $Char$to_lower$(c_0) {
  const x_0 = run_loop($Bool$to_u32$(run_loop($Char$is_upper$(c_0))));
  const x_1 = run_loop($Char$to_u32$(c_0));
  const x_2 = (Math.imul(x_0, 32) >>> 0);
  return char_new(((x_1 + x_2) >>> 0));
}

function $f_case_checked$(p_0, indent_0, heads_0, rows_0, pats_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  const x_0 = run_loop($f_len$(pats_0));
  const x_1 = run_loop($f_len$(heads_0));
  return run_jump($f_choose$, [(x_0 === x_1), run_clo((x_2) => {
  return run_jump($f_match_cases$, [run_loop($f_skip$(ts_0)), indent_0, heads_0, {$: "Con", ["head"]: run_loop($kt$("Row", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, pats_0)), ["tail"]: {$: "Con", ["head"]: n_0, ["tail"]: {$: "Nil"}}})), ["tail"]: rows_0}]);
}), run_clo((x_3) => {
  return run_jump($f_err$, [ts_0, "one pattern is required per match scrutinee"]);
})]);
}

function $f_parallel_body$(pats_0, vals_0, p_0) {
  const body_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return {$: "FParsed", ["term"]: run_loop($kt$("Parallel", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, pats_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Values", "", 0, 1, vals_0)), ["tail"]: {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}}})), ["rest"]: ts_0};
}

function $f_parallel_value$(p_0, pats_0, left_0, vals_0) {
  const n_0 = p_0["term"];
  const ts_0 = p_0["rest"];
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(n_0)), "Error")), run_clo((x_0) => {
  return {$: "FParsed", ["term"]: n_0, ["rest"]: ts_0};
}), run_clo((x_1) => {
  return run_jump($f_parallel_values$, [ts_0, pats_0, ((left_0 - 1) >>> 0), {$: "Con", ["head"]: n_0, ["tail"]: vals_0}]);
})]);
}

function $f_operator_display$(name_0, ops_0) {
  if (ops_0.$ === "Nil") {
    return name_0;
  } else {
    const op_0 = ops_0["head"];
    const rest_0 = ops_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($f_operator$(op_0)), name_0)), run_clo((x_0) => {
    return run_jump($f_choose$, [run_loop($f_eq$(op_0, ">op")), run_clo((x_1) => {
    return ">";
}), run_clo((x_2) => {
    return run_jump($f_choose$, [run_loop($f_eq$(op_0, ">>op")), run_clo((x_3) => {
    return ">>";
}), run_clo((x_4) => {
    return op_0;
})]);
})]);
}), run_clo((x_5) => {
    return run_jump($f_operator_display$, [name_0, rest_0]);
})]);
  }
}

function $f_first_ctor$(rows_0) {
  if (rows_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Ctr")), run_clo((x_0) => {
    return run_jump($f_rowpat$, [r_0]);
}), run_clo((x_1) => {
    return run_jump($f_first_ctor$, [rs_0]);
})]);
  }
}

function $f_has_id$(vars_0, id_0) {
  if (vars_0.$ === "Nil") {
    return false;
  } else {
    const v_0 = vars_0["head"];
    const vs_0 = vars_0["tail"];
    const x_0 = run_loop($ix$(v_0));
    const x_1 = (x_0 === id_0);
    const x_2 = run_loop($f_has_id$(vs_0, id_0));
    return (x_1 || x_2);
  }
}

function $f_var_rows$(rows_0, v_0) {
  if (rows_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    const x_0 = run_loop($qt$(r_0));
    return {$: "Con", ["head"]: run_loop($kt$("Row", "", 0, run_loop($qt$(r_0)), {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, run_loop($f_tail_terms$(run_loop($ks$(run_loop($kid$(r_0, 0)))))))), ["tail"]: {$: "Con", ["head"]: run_loop($f_choose$((x_0 === 0), run_clo((x_1) => {
    return run_jump($kid$, [r_0, 1]);
}), run_clo((x_2) => {
    return run_jump($f_sub$, [run_loop($kid$(r_0, 1)), run_loop($ix$(run_loop($f_rowpat$(r_0)))), v_0]);
}))), ["tail"]: {$: "Nil"}}})), ["tail"]: run_loop($f_var_rows$(rs_0, v_0))};
  }
}

function $f_mark_vars$(vars_0, id_0, q_0) {
  if (vars_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const v_0 = vars_0["head"];
    const vs_0 = vars_0["tail"];
    const x_0 = run_loop($ix$(v_0));
    return {$: "Con", ["head"]: run_loop($f_choose$((x_0 === id_0), run_clo((x_1) => {
    return run_jump($kt$, ["Var", run_loop($nm$(v_0)), run_loop($ix$(v_0)), q_0, {$: "Nil"}]);
}), run_clo((x_2) => {
    return v_0;
}))), ["tail"]: run_loop($f_mark_vars$(vs_0, id_0, q_0))};
  }
}

function $f_mark_rows$(rows_0, q_0) {
  if (rows_0.$ === "Nil") {
    return q_0;
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    const x_0 = run_loop($qt$(run_loop($f_rowpat$(r_0))));
    return run_jump($f_mark_rows$, [rs_0, run_loop($f_choose$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Var")), (x_0 === 2))), run_clo((x_1) => {
    return 2;
}), run_clo((x_2) => {
    return q_0;
})))]);
  }
}

function $ff_column$(h_0, hs_0, rows_0, vars_0, next_0) {
  if (vars_0.$ === "Nil") {
    return {$: "FFlatten", ["term"]: run_loop($kt$("Error", "match requires an unconsumed parameter or constructor field", 0, 0, {$: "Nil"})), ["next"]: next_0};
  } else {
    const v_0 = vars_0["head"];
    const vs_0 = vars_0["tail"];
    const x_0 = run_loop($ix$(h_0));
    const x_1 = run_loop($ix$(v_0));
    return run_jump($f_choose$, [(x_0 === x_1), run_clo((x_2) => {
    return run_jump($ff_split$, [h_0, hs_0, rows_0, v_0, vs_0, run_loop($f_first_ctor$(rows_0)), next_0]);
}), run_clo((x_3) => {
    return run_jump($ff_lam$, [v_0, run_loop($ff_match$({$: "Con", ["head"]: h_0, ["tail"]: hs_0}, rows_0, vs_0, next_0))]);
})]);
  }
}

function $ff_let$(t_0, vars_0, r_0) {
  const body_0 = r_0["term"];
  const next_0 = r_0["next"];
  return {$: "FFlatten", ["term"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(body_0)), "Lam")), run_clo((x_0) => {
  return run_jump($f_lbind$, [vars_0, run_loop($kt$("Let", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(run_loop($kid$(t_0, 0)))), run_loop($ix$(run_loop($kid$(t_0, 0)))), run_loop($qt$(run_loop($kid$(t_0, 0)))), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(body_0, 0)), ["tail"]: {$: "Nil"}}}))]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "a match cannot scrutinize a local binding", 0, 0, {$: "Nil"}]);
}))), ["next"]: next_0};
}

function $f_parallel_binds$(pats_0, vals_0) {
  if (pats_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const p_0 = pats_0["head"];
    const ps_0 = pats_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(p_0)), run_loop($ix$(p_0)), run_loop($qt$(p_0)), {$: "Con", ["head"]: run_loop($terms_at$(vals_0, 0)), ["tail"]: {$: "Nil"}})), ["tail"]: run_loop($f_parallel_binds$(ps_0, run_loop($f_tail_terms$(vals_0))))};
  }
}

function $f_unlamb$(body_0, n_0) {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_0) => {
  return body_0;
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(body_0)), "Lam")), run_clo((x_2) => {
  return run_jump($f_unlamb$, [run_loop($kid$(body_0, 0)), ((n_0 - 1) >>> 0)]);
}), run_clo((x_3) => {
  return run_jump($kt$, ["Error", "cannot match a parallel let binding", 0, 0, {$: "Nil"}]);
})]);
})]);
}

function $f_scope_parallel_pats$(t_0, pats_0, env_0, book_0) {
  return run_jump($f_scope_parallel_valid$, [t_0, pats_0, env_0, book_0, run_loop($f_valid_patterns_mode$(pats_0, book_0, true))]);
}

function $f_patterns$(xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(x_0)), "Ref")), run_clo((x_1) => {
    return run_jump($kt$, ["Var", run_loop($nm$(x_0)), run_loop($ix$(x_0)), run_loop($qt$(x_0)), {$: "Nil"}]);
}), run_clo((x_2) => {
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(x_0)), "Literal")), run_clo((x_3) => {
    return run_jump($f_pattern_literal$, [run_loop($nm$(x_0))]);
}), run_clo((x_4) => {
    return run_jump($kt$, [run_loop($tg$(x_0)), run_loop($nm$(x_0)), run_loop($ix$(x_0)), run_loop($qt$(x_0)), run_loop($f_patterns$(run_loop($ks$(x_0))))]);
})]);
}))), ["tail"]: run_loop($f_patterns$(xt_0))};
  }
}

function $f_scope_local$(t_0, pats_0, env_0, book_0) {
  return run_jump($f_scope_local_valid$, [t_0, pats_0, env_0, book_0, run_loop($f_valid_patterns$(pats_0, run_loop($f_choose$(run_loop($f_eq$(run_loop($nm$(t_0)), "Do")), run_clo((x_0) => {
  return {$: "Nil"};
}), run_clo((x_1) => {
  return book_0;
})))))]);
}

function $f_scope_rows$(rows_0, env_0, book_0) {
  if (rows_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_scope_row$(r_0, run_loop($f_patterns$(run_loop($ks$(run_loop($kid$(r_0, 0)))))), env_0, book_0)), ["tail"]: run_loop($f_scope_rows$(rs_0, env_0, book_0))};
  }
}

function $f_flat_match$(heads_0, rows_0, vars_0) {
  if (heads_0.$ === "Nil") {
    const x_0 = run_loop($f_len$(rows_0));
    return run_jump($f_choose$, [(x_0 === 0), run_clo((x_1) => {
    return run_jump($atom$, ["Efq"]);
}), run_clo((x_2) => {
    return run_jump($f_flat$, [run_loop($kid$(run_loop($terms_at$(rows_0, 0)), 1)), vars_0]);
})]);
  } else {
    const h_0 = heads_0["head"];
    const hs_0 = heads_0["tail"];
    const x_3 = run_loop($f_len$(rows_0));
    return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(run_loop($f_first_ctor$(rows_0)))), "Absent")), (x_3 > 0))), run_loop($f_has_id$(vars_0, run_loop($ix$(h_0)))))), run_clo((x_4) => {
    return run_jump($f_flat_match$, [hs_0, run_loop($f_var_rows$(rows_0, h_0)), run_loop($f_mark_vars$(vars_0, run_loop($ix$(h_0)), run_loop($f_mark_rows$(rows_0, run_loop($qt$(h_0))))))]);
}), run_clo((x_5) => {
    return run_jump($f_flat_column$, [h_0, hs_0, rows_0, vars_0]);
})]);
  }
}

function $f_flat_local$(t_0, vars_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(run_loop($kid$(t_0, 0)))), "Ctr")), run_clo((x_0) => {
  return run_jump($f_flat_match$, [{$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Nil"}}, {$: "Con", ["head"]: run_loop($kt$("Row", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(t_0, 2)), ["tail"]: {$: "Nil"}}})), ["tail"]: {$: "Nil"}}, vars_0]);
}), run_clo((x_1) => {
  return run_jump($f_flat_let$, [t_0, vars_0, run_loop($f_flat$(run_loop($kid$(t_0, 2)), {$: "Con", ["head"]: run_loop($kid$(t_0, 0)), ["tail"]: {$: "Nil"}}))]);
})]);
}

function $f_do_bind_types$(types_0, ty_0) {
  if (types_0.$ === "Nil") {
    return {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Nil"}};
  } else {
    const head_0 = types_0["head"];
    const rest_0 = types_0["tail"];
    return run_jump($f_concat$, [run_loop($f_init$({$: "Con", ["head"]: head_0, ["tail"]: rest_0})), {$: "Con", ["head"]: ty_0, ["tail"]: {$: "Con", ["head"]: run_loop($f_last$({$: "Con", ["head"]: head_0, ["tail"]: rest_0})), ["tail"]: {$: "Nil"}}}]);
  }
}

function $Bool$to_u32$(b_0) {
  if (!b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $f_rowpat$(r_0) {
  return run_jump($kid$, [run_loop($kid$(r_0, 0)), 0]);
}

function $ff_split$(h_0, hs_0, rows_0, v_0, vs_0, c_0, next_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(c_0)), "Absent")), run_clo((x_0) => {
  return {$: "FFlatten", ["term"]: run_loop($atom$("Efq")), ["next"]: next_0};
}), run_clo((x_1) => {
  return run_jump($ff_fields_done$, [h_0, hs_0, rows_0, v_0, vs_0, c_0, run_loop($ff_fields$(run_loop($ks$(c_0)), run_loop($f_mark_rows$(rows_0, run_loop($qt$(v_0)))), next_0))]);
})]);
}

function $ff_lam$(v_0, r_0) {
  const body_0 = r_0["term"];
  const next_0 = r_0["next"];
  return {$: "FFlatten", ["term"]: run_loop($kt$("Lam", run_loop($nm$(v_0)), run_loop($ix$(v_0)), run_loop($qt$(v_0)), {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}})), ["next"]: next_0};
}

function $f_scope_parallel_valid$(t_0, pats_0, env_0, book_0, err_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($kt$, ["Parallel", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, pats_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Values", "", 0, 1, run_loop($f_scope_terms$(run_loop($ks$(run_loop($kid$(t_0, 1)))), env_0, book_0)))), ["tail"]: {$: "Con", ["head"]: run_loop($f_scope_body$(run_loop($kid$(t_0, 2)), run_loop($f_pattern_env$(pats_0, env_0)), book_0)), ["tail"]: {$: "Nil"}}}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", err_0, 0, 0, {$: "Nil"}]);
})]);
}

function $f_valid_patterns_mode$(ps_0, book_0, names_0) {
  if (ps_0.$ === "Nil") {
    return "";
  } else {
    const p_0 = ps_0["head"];
    const rest_0 = ps_0["tail"];
    return run_jump($f_valid_patterns_mode_next$, [run_loop($f_valid_binding_pattern$(p_0, book_0, names_0)), rest_0, book_0, names_0]);
  }
}

function $f_pattern_literal$(s_0) {
  return run_jump($f_choose$, [run_loop($String$ends_with$(s_0, "n")), run_clo((x_0) => {
  return run_jump($f_nat_pattern$, [run_loop($f_pattern_number$(s_0, 0))]);
}), run_clo((x_1) => {
  return run_jump($f_literal$, [s_0]);
})]);
}

function $f_scope_local_valid$(t_0, pats_0, env_0, book_0, err_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($kt$, ["Local", "", 0, run_loop($qt$(t_0)), {$: "Con", ["head"]: run_loop($terms_at$(pats_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($f_scope$(run_loop($kid$(t_0, 1)), env_0, book_0)), ["tail"]: {$: "Con", ["head"]: run_loop($f_scope_body$(run_loop($kid$(t_0, 2)), run_loop($f_pattern_env$(pats_0, env_0)), book_0)), ["tail"]: {$: "Nil"}}}}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", err_0, 0, 0, {$: "Nil"}]);
})]);
}

function $f_valid_patterns$(ps_0, book_0) {
  return run_jump($f_valid_patterns_mode$, [ps_0, book_0, false]);
}

function $f_scope_row$(r_0, pats_0, env_0, book_0) {
  return run_jump($f_scope_row_valid$, [r_0, pats_0, env_0, book_0, run_loop($f_valid_patterns$(pats_0, book_0))]);
}

function $f_flat_column$(h_0, hs_0, rows_0, vars_0) {
  if (vars_0.$ === "Nil") {
    return run_jump($kt$, ["Error", "match requires an unconsumed parameter or constructor field", 0, 0, {$: "Nil"}]);
  } else {
    const v_0 = vars_0["head"];
    const vs_0 = vars_0["tail"];
    const x_0 = run_loop($ix$(h_0));
    const x_1 = run_loop($ix$(v_0));
    return run_jump($f_choose$, [(x_0 === x_1), run_clo((x_2) => {
    return run_jump($f_flat_split$, [h_0, hs_0, rows_0, v_0, vs_0, run_loop($f_first_ctor$(rows_0))]);
}), run_clo((x_3) => {
    return run_jump($kt$, ["Lam", run_loop($nm$(v_0)), run_loop($ix$(v_0)), run_loop($qt$(v_0)), {$: "Con", ["head"]: run_loop($f_flat_match$({$: "Con", ["head"]: h_0, ["tail"]: hs_0}, rows_0, vs_0)), ["tail"]: {$: "Nil"}}]);
})]);
  }
}

function $f_flat_let$(t_0, vars_0, body_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(body_0)), "Lam")), run_clo((x_0) => {
  return run_jump($f_lbind$, [vars_0, run_loop($kt$("Let", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(run_loop($kid$(t_0, 0)))), run_loop($ix$(run_loop($kid$(t_0, 0)))), run_loop($qt$(run_loop($kid$(t_0, 0)))), {$: "Con", ["head"]: run_loop($kid$(t_0, 1)), ["tail"]: {$: "Nil"}})), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(body_0, 0)), ["tail"]: {$: "Nil"}}}))]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Error", "a match cannot scrutinize a local binding", 0, 0, {$: "Nil"}]);
})]);
}

function $f_init$(xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    const x_1 = run_loop($f_len$(xt_0));
    return run_jump($f_choose$, [(x_1 === 0), run_clo((x_2) => {
    return {$: "Nil"};
}), run_clo((x_3) => {
    return {$: "Con", ["head"]: x_0, ["tail"]: run_loop($f_init$(xt_0))};
})]);
  }
}

function $f_last$(xs_0) {
  if (xs_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    const x_1 = run_loop($f_len$(xt_0));
    return run_jump($f_choose$, [(x_1 === 0), run_clo((x_2) => {
    return x_0;
}), run_clo((x_3) => {
    return run_jump($f_last$, [xt_0]);
})]);
  }
}

function $ff_fields_done$(h_0, hs_0, rows_0, v_0, vs_0, c_0, r_0) {
  const fields_0 = r_0["fields"];
  const next_0 = r_0["next"];
  return run_jump($ff_hit_done$, [h_0, hs_0, rows_0, v_0, vs_0, c_0, run_loop($ff_match$(run_loop($f_concat$(fields_0, hs_0)), run_loop($f_hit_rows$(rows_0, c_0, fields_0, v_0)), run_loop($f_concat$(fields_0, vs_0)), next_0))]);
}

function $ff_fields$(ps_0, q_0, next_0) {
  if (ps_0.$ === "Nil") {
    return {$: "FFields", ["fields"]: {$: "Nil"}, ["next"]: next_0};
  } else {
    const p_0 = ps_0["head"];
    const rest_0 = ps_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(p_0)), "Var")), run_clo((x_0) => {
    return run_jump($ff_field_cons$, [run_loop($kt$("Var", run_loop($nm$(p_0)), run_loop($ix$(p_0)), run_loop($f_choose$((q_0 === 2), run_clo((x_1) => {
    return 2;
}), run_clo((x_2) => {
    return run_jump($qt$, [p_0]);
}))), {$: "Nil"})), run_loop($ff_fields$(rest_0, q_0, next_0))]);
}), run_clo((x_3) => {
    const x_4 = run_loop($U32$show$(next_0));
    return run_jump($ff_field_cons$, [run_loop($kt$("Var", ("_" + x_4), ((2147483648 + next_0) >>> 0), q_0, {$: "Nil"})), run_loop($ff_fields$(rest_0, q_0, ((next_0 + 1) >>> 0)))]);
})]);
  }
}

function $f_pattern_env$(pats_0, env_0) {
  return run_jump($f_concat$, [run_loop($List$reverse$(run_loop($f_penv$(pats_0)))), env_0]);
}

function $f_valid_patterns_mode_next$(err_0, ps_0, book_0, names_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_valid_patterns_mode$, [ps_0, book_0, names_0]);
}), run_clo((x_1) => {
  return err_0;
})]);
}

function $f_valid_binding_pattern$(p_0, book_0, names_0) {
  return run_jump($f_choose$, [names_0, run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(p_0)), "Var")), run_clo((x_1) => {
  return run_jump($f_valid_pattern$, [p_0, book_0]);
}), run_clo((x_2) => {
  return "a parallel let binds names; destructure in its body";
})]);
}), run_clo((x_3) => {
  return run_jump($f_valid_pattern$, [p_0, book_0]);
})]);
}

function $f_nat_pattern$(n_0) {
  return run_jump($f_choose$, [(n_0 === 0), run_clo((x_0) => {
  return run_jump($kt$, ["Ctr", "Zero", 0, 1, {$: "Nil"}]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Ctr", "Succ", 0, 1, {$: "Con", ["head"]: run_loop($f_nat_pattern$(((n_0 - 1) >>> 0))), ["tail"]: {$: "Nil"}}]);
})]);
}

function $f_pattern_number$(s_0, n_0) {
  const x_0 = run_loop($f_eq$(s_0, "n"));
  const x_1 = run_loop($String$is_empty$(s_0));
  return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
  return n_0;
}), run_clo((x_3) => {
  const x_4 = run_loop($Char$to_u32$(run_loop($f_head$(s_0))));
  const x_5 = (Math.imul(n_0, 10) >>> 0);
  const x_6 = ((x_4 - 48) >>> 0);
  return run_jump($f_pattern_number$, [run_loop($f_tail$(s_0)), ((x_5 + x_6) >>> 0)]);
})]);
}

function $f_scope_row_valid$(r_0, pats_0, env_0, book_0, err_0) {
  return run_jump($f_choose$, [run_loop($String$is_empty$(err_0)), run_clo((x_0) => {
  return run_jump($f_scoped_row$, [pats_0, run_loop($f_scope_body$(run_loop($kid$(r_0, 1)), run_loop($f_pattern_env$(pats_0, env_0)), book_0))]);
}), run_clo((x_1) => {
  return run_jump($kt$, ["Row", "", 0, 1, {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, pats_0)), ["tail"]: {$: "Con", ["head"]: run_loop($kt$("Error", err_0, 0, 0, {$: "Nil"})), ["tail"]: {$: "Nil"}}}]);
})]);
}

function $f_flat_split$(h_0, hs_0, rows_0, v_0, vs_0, c_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(c_0)), "Absent")), run_clo((x_0) => {
  return run_jump($atom$, ["Efq"]);
}), run_clo((x_1) => {
  const x_2 = run_loop($ix$(c_0));
  return run_jump($f_flat_fields$, [h_0, hs_0, rows_0, v_0, vs_0, c_0, run_loop($f_mark_fields$(run_loop($f_fresh_fields$(run_loop($ks$(c_0)), ((2147483648 + x_2) >>> 0))), run_loop($f_mark_rows$(rows_0, run_loop($qt$(v_0))))))]);
})]);
}

function $ff_hit_done$(h_0, hs_0, rows_0, v_0, vs_0, c_0, r_0) {
  const hit_0 = r_0["term"];
  const next_0 = r_0["next"];
  return run_jump($ff_miss_done$, [c_0, hit_0, run_loop($ff_match$({$: "Con", ["head"]: h_0, ["tail"]: hs_0}, run_loop($f_miss_rows$(rows_0, run_loop($nm$(c_0)))), {$: "Con", ["head"]: v_0, ["tail"]: vs_0}, next_0))]);
}

function $f_hit_rows$(rows_0, c_0, fields_0, v_0) {
  if (rows_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    const x_0 = run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Var"));
    const x_1 = run_loop($f_eq$(run_loop($nm$(run_loop($f_rowpat$(r_0)))), run_loop($nm$(c_0))));
    return run_jump($f_choose$, [(x_0 || x_1), run_clo((x_2) => {
    return {$: "Con", ["head"]: run_loop($f_hit_row$(r_0, c_0, fields_0, v_0)), ["tail"]: run_loop($f_hit_rows$(rs_0, c_0, fields_0, v_0))};
}), run_clo((x_3) => {
    return run_jump($f_hit_rows$, [rs_0, c_0, fields_0, v_0]);
})]);
  }
}

function $ff_field_cons$(p_0, r_0) {
  const fields_0 = r_0["fields"];
  const next_0 = r_0["next"];
  return {$: "FFields", ["fields"]: {$: "Con", ["head"]: p_0, ["tail"]: fields_0}, ["next"]: next_0};
}

function $f_penv$(xs_0) {
  if (xs_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const x_0 = xs_0["head"];
    const xt_0 = xs_0["tail"];
    return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(x_0)), "Var")), run_clo((x_1) => {
    return {$: "Con", ["head"]: x_0, ["tail"]: run_loop($f_penv$(xt_0))};
}), run_clo((x_2) => {
    return run_jump($f_concat$, [run_loop($f_penv$(run_loop($ks$(x_0)))), run_loop($f_penv$(xt_0))]);
})]);
  }
}

function $f_valid_pattern$(p_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(p_0)), "Var")), run_clo((x_0) => {
  return run_jump($f_choose$, [run_loop($Bool$not$(run_loop($f_valid_name$(run_loop($nm$(p_0)))))), run_clo((x_1) => {
  const x_2 = run_loop($nm$(p_0));
  return ("reserved pattern binder: " + x_2);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($dk$(run_loop($f_ctor_lookup$(run_loop($nm$(p_0)), book_0)))), "Missing")), run_clo((x_4) => {
  return "";
}), run_clo((x_5) => {
  const x_6 = run_loop($nm$(p_0));
  return ("a constructor pattern requires braces: " + x_6);
})]);
})]);
}), run_clo((x_7) => {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($tg$(p_0)), "Ctr")), run_clo((x_8) => {
  return run_jump($f_valid_ctor_pattern$, [p_0, run_loop($f_ctor_lookup$(run_loop($nm$(p_0)), book_0)), book_0]);
}), run_clo((x_9) => {
  return "expected a binder or constructor pattern";
})]);
})]);
}

function $f_scoped_row$(pats_0, body_0) {
  return run_jump($kt$, ["Row", "", 0, run_loop($f_choose$(run_loop($f_contains_var$(body_0)), run_clo((x_0) => {
  return 1;
}), run_clo((x_1) => {
  return 0;
}))), {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, pats_0)), ["tail"]: {$: "Con", ["head"]: body_0, ["tail"]: {$: "Nil"}}}]);
}

function $f_flat_fields$(h_0, hs_0, rows_0, v_0, vs_0, c_0, fields_0) {
  return run_jump($kt$, ["Mat", run_loop($nm$(c_0)), 0, 1, {$: "Con", ["head"]: run_loop($f_flat_match$(run_loop($f_concat$(fields_0, hs_0)), run_loop($f_hit_rows$(rows_0, c_0, fields_0, v_0)), run_loop($f_concat$(fields_0, vs_0)))), ["tail"]: {$: "Con", ["head"]: run_loop($f_flat_match$({$: "Con", ["head"]: h_0, ["tail"]: hs_0}, run_loop($f_miss_rows$(rows_0, run_loop($nm$(c_0)))), {$: "Con", ["head"]: v_0, ["tail"]: vs_0})), ["tail"]: {$: "Nil"}}}]);
}

function $f_mark_fields$(vars_0, q_0) {
  if (vars_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const v_0 = vars_0["head"];
    const vs_0 = vars_0["tail"];
    return {$: "Con", ["head"]: run_loop($kt$("Var", run_loop($nm$(v_0)), run_loop($ix$(v_0)), run_loop($f_choose$((q_0 === 2), run_clo((x_0) => {
    return 2;
}), run_clo((x_1) => {
    return run_jump($qt$, [v_0]);
}))), {$: "Nil"})), ["tail"]: run_loop($f_mark_fields$(vs_0, q_0))};
  }
}

function $f_fresh_fields$(ps_0, id_0) {
  if (ps_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const p_0 = ps_0["head"];
    const rest_0 = ps_0["tail"];
    return {$: "Con", ["head"]: run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(p_0)), "Var")), run_clo((x_0) => {
    return p_0;
}), run_clo((x_1) => {
    return run_jump($kt$, ["Var", "_field", id_0, 1, {$: "Nil"}]);
}))), ["tail"]: run_loop($f_fresh_fields$(rest_0, ((id_0 + 1) >>> 0)))};
  }
}

function $ff_miss_done$(c_0, hit_0, r_0) {
  const miss_0 = r_0["term"];
  const next_0 = r_0["next"];
  return {$: "FFlatten", ["term"]: run_loop($kt$("Mat", run_loop($nm$(c_0)), 0, 1, {$: "Con", ["head"]: hit_0, ["tail"]: {$: "Con", ["head"]: miss_0, ["tail"]: {$: "Nil"}}})), ["next"]: next_0};
}

function $f_miss_rows$(rows_0, name_0) {
  if (rows_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const r_0 = rows_0["head"];
    const rs_0 = rows_0["tail"];
    return run_jump($f_choose$, [run_loop($Bool$and$(run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Ctr")), run_loop($f_eq$(run_loop($nm$(run_loop($f_rowpat$(r_0)))), name_0)))), run_clo((x_0) => {
    return run_jump($f_miss_rows$, [rs_0, name_0]);
}), run_clo((x_1) => {
    return {$: "Con", ["head"]: r_0, ["tail"]: run_loop($f_miss_rows$(rs_0, name_0))};
})]);
  }
}

function $f_hit_row$(r_0, c_0, fields_0, v_0) {
  const x_2 = run_loop($qt$(r_0));
  return run_jump($kt$, ["Row", "", 0, run_loop($qt$(r_0)), {$: "Con", ["head"]: run_loop($kt$("Patterns", "", 0, 1, run_loop($f_concat$(run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Var")), run_clo((x_0) => {
  return fields_0;
}), run_clo((x_1) => {
  return run_jump($ks$, [run_loop($f_rowpat$(r_0))]);
}))), run_loop($f_tail_terms$(run_loop($ks$(run_loop($kid$(r_0, 0)))))))))), ["tail"]: {$: "Con", ["head"]: run_loop($f_choose$((x_2 === 0), run_clo((x_3) => {
  return run_jump($kid$, [r_0, 1]);
}), run_clo((x_4) => {
  return run_jump($f_sub$, [run_loop($f_choose$(run_loop($f_eq$(run_loop($tg$(run_loop($f_rowpat$(r_0)))), "Var")), run_clo((x_5) => {
  return run_jump($f_sub$, [run_loop($kid$(r_0, 1)), run_loop($ix$(run_loop($f_rowpat$(r_0)))), v_0]);
}), run_clo((x_6) => {
  return run_jump($kid$, [r_0, 1]);
}))), run_loop($ix$(v_0)), run_loop($kt$("Ctr", run_loop($nm$(c_0)), 0, 1, fields_0))]);
}))), ["tail"]: {$: "Nil"}}}]);
}

function $f_valid_ctor_pattern$(p_0, ctr_0, book_0) {
  return run_jump($f_choose$, [run_loop($f_eq$(run_loop($dk$(ctr_0)), "Missing")), run_clo((x_0) => {
  const x_1 = run_loop($nm$(p_0));
  return ("unknown constructor pattern: " + x_1);
}), run_clo((x_2) => {
  const x_3 = run_loop($da$(ctr_0));
  const x_4 = run_loop($f_len$(run_loop($ks$(p_0))));
  return run_jump($f_choose$, [(x_3 === x_4), run_clo((x_5) => {
  return run_jump($f_valid_patterns$, [run_loop($ks$(p_0)), book_0]);
}), run_clo((x_6) => {
  const x_7 = run_loop($nm$(p_0));
  return ("constructor pattern field count differs: " + x_7);
})]);
})]);
}

function $f_contains_var$(t_0) {
  const x_0 = run_loop($f_eq$(run_loop($tg$(t_0)), "Var"));
  const x_1 = run_loop($f_contains_var_terms$(run_loop($ks$(t_0))));
  return (x_0 || x_1);
}

function $f_contains_var_terms$(ts_0) {
  if (ts_0.$ === "Nil") {
    return false;
  } else {
    const t_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    const x_0 = run_loop($f_contains_var$(t_0));
    const x_1 = run_loop($f_contains_var_terms$(rest_0));
    return (x_0 || x_1);
  }
}
export default {
  "check_book": run_lib($check_book$, 1),
  "check": run_lib($check$, 5),
  "infer": run_lib($infer$, 5),
  "annotate_book": run_lib($annotate_book$, 1),
  "kp_show": run_lib($kp_show$, 1),
  "specialize_book": run_lib($specialize_book$, 1),
  "specialized_book": run_lib($specialized_book$, 1),
  "specialized_error": run_lib($specialized_error$, 1),
  "strong": run_lib($strong$, 2),
  "wnf": run_lib($wnf$, 2),
  "compare": run_lib($compare$, 4),
  "exact_prefix": run_lib($exact_prefix$, 2),
  "check_from_exact_prefix": run_lib($check_from_exact_prefix$, 2),
  "reach_book": run_lib($reach_book$, 3),
  "lookup": run_lib($lookup$, 2),
  "book_cached": run_lib($book_cached$, 2),
  "book_context": run_lib($book_context$, 1),
  "book_put": run_lib($book_put$, 2),
  "f_parse": run_lib($f_parse$, 1),
  "f_source_parsed": run_lib($f_source_parsed$, 4),
  "f_load_graph": run_lib($f_load_graph$, 2),
  "f_load_graph_seed": run_lib($f_load_graph_seed$, 5),
  "f_main_names": run_lib($f_main_names$, 2),
  "f_fresh_term": run_lib($f_fresh_term$, 3),
  "f_fresh_defs": run_lib($f_fresh_defs$, 2),
  "check_book_diagnostic": run_lib($check_book_diagnostic$, 2),
  "diagnostic_render": run_lib($diagnostic_render$, 1),
  "diagnostic_result_locate": run_lib($diagnostic_result_locate$, 2),
  "dg_render": run_lib($dg_render$, 2),
  "diagnostic_locate": run_lib($diagnostic_locate$, 2),
  "f_load_origins": run_lib($f_load_origins$, 2),
  "f_load_origins_for": run_lib($f_load_origins_for$, 3),
  "nc_ctor_identity": run_lib($nc_ctor_identity$, 2),
  "nc_ctor_display": run_lib($nc_ctor_display$, 1),
  "nc_ctor_encode": run_lib($nc_ctor_encode$, 1),
  "nc_ctor_owned": run_lib($nc_ctor_owned$, 2),
};
