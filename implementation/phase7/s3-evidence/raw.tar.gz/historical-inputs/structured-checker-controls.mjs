// Observational instrumentation only. Both original API files stay unchanged.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {identity,verifyIdentity} from '../../development/workflow.mjs';
const [controlArg,candidateArg,outArg]=process.argv.slice(2);
assert.ok(outArg,'Usage: CONTROL_ATTEMPT CANDIDATE_ATTEMPT NEW_OUTPUT');
const out=path.resolve(outArg);fs.mkdirSync(out);
const read=f=>JSON.parse(fs.readFileSync(f));
const attempts=[controlArg,candidateArg].map(a=>read(path.join(a,'attempt.json')));
const host=path.join(attempts[1].snapshot.root,'tools/typed-driver.mjs');
const report={kind:'phase6-authoritative-checker-controls',complete:false,rows:[],inputs:[],scope:'Disposable check-call counters and actual new host; no timing conclusions.'};
const add=f=>{const x=identity(f);if(!report.inputs.some(y=>y.file===x.file))report.inputs.push(x);return x;};
const save=()=>fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
add(import.meta.filename);add(process.execPath);add(host);
for(const name of ['assemble','compiler-abi','native-build','node-resource-args'])add(path.join(path.dirname(host),name+'.mjs'));
for(const [i,m]of attempts.entries()){add(path.join([controlArg,candidateArg][i],'attempt.json'));assert.equal(add(m.api.file).sha256,m.api.sha256);add(m.base.file);add(m.runtime.file);}
const prelude='type Flag is Data:\n  On{}\n  Off{}\n\n';
const defs=Array.from({length:30},(_,i)=>`def value${i}() -> Flag:\n  On{}\n`).join('');
const texts={early:prelude+'def broken() -> Flag:\n  missing\n'+defs,late:prelude+defs+'def broken() -> Flag:\n  missing\n',accepted:prelude+defs+'def main() -> Flag:\n  On{}\n'};
const fixtures=Object.fromEntries(Object.entries(texts).map(([name,text])=>{const file=path.join(out,name+'.bend');fs.writeFileSync(file,text);add(file);return [name,file];}));
for(const key of Object.keys(process.env))if(key.startsWith('BEND_')||key==='NODE_OPTIONS')delete process.env[key];
Object.assign(process.env,{BEND_TYPED_API:attempts[1].api.file,BEND_BASE:attempts[1].base.file,BEND_TYPED_RUNTIME:attempts[1].runtime.file});
const D=await import(pathToFileURL(host));
const nil={$:'Nil'},list=xs=>xs.reduceRight((tail,head)=>({$:'Con',head,tail}),nil);
try {
  const modules=[];
  for(const [index,m]of attempts.entries()){
    let source=fs.readFileSync(m.api.file,'utf8');
    const header='function $check$(e_0, ctx_0, t_0, dem_0, ty_0) {';
    assert.equal(source.split(header).length,2);
    source=source.replace(header,header+"\n  __counts[e_0.name]=( __counts[e_0.name]??0)+1; if(t_0.tag==='Ref'&&t_0.name==='missing')__missing++;\n");
    source='let __counts={},__missing=0; export function __reset(){__counts={};__missing=0;} export function __read(){return {checks:{...__counts},missingChecks:__missing};}\n'+source;
    const file=path.join(out,index===0?'control-instrumented.mjs':'candidate-instrumented.mjs');fs.writeFileSync(file,source);add(file);
    modules.push(await import(pathToFileURL(file)));
  }
  for(const [index,module]of modules.entries())for(const [name,file]of Object.entries(fixtures)){
    module.__reset();const calls={};
    const api=Object.fromEntries(Object.entries(module.default).map(([key,fn])=>[key,(...args)=>{calls[key]=(calls[key]??0)+1;return fn(...args);} ]));
    const result=await D.inspect(file,{api,mode:'check'}),counts=module.__read();
    assert.equal(result.status,name==='accepted'?'ok':'error');assert.equal(result.phase,'check');assert.equal(result.checked,true);
    if(name!=='accepted')assert.equal(counts.missingChecks,index===0?4:1,'one selected failure check in new host');
    if(index===1){assert.equal(calls.check_book_diagnostic,1);assert.equal(calls.check_book,undefined);}
    else {assert.equal(calls.check_book,1);assert.equal(calls.check_book_diagnostic,name==='accepted'?undefined:1);}
    report.rows.push({variant:index===0?'control':'candidate',name,result,calls,...counts});save();
  }
  for(const name of Object.keys(fixtures))assert.deepEqual(report.rows.find(r=>r.variant==='candidate'&&r.name===name).result,report.rows.find(r=>r.variant==='control'&&r.name===name).result);
  const [B,K]=modules.map(m=>m.default),file=fixtures.late,source={$:'FSource',name:file,path:file,text:texts.late};
  const loaded=K.f_load_graph(file,list([source]));assert.equal(loaded.error,'');
  const oversized=list([...(()=>{const xs=[];for(let x=loaded.book;x.$==='Con';x=x.tail)xs.push(x.head);return xs;})(),loaded.book.head]);
  assert.equal(K.exact_prefix(loaded.book,oversized),false);
  const expected=B.check_book_diagnostic(loaded.book,nil);
  assert.deepEqual(K.check_book_diagnostic_from_exact_prefix(loaded.book,oversized,nil),expected);
  assert.equal(K.check_from_exact_prefix(loaded.book,oversized),expected.error);
  report.oversizedPrefixFallback=true;
  report.inputs.forEach(verifyIdentity);report.complete=true;
} catch(error){report.error=error.stack;process.exitCode=1;}
save();console.log(JSON.stringify({complete:report.complete,error:report.error,rows:report.rows.map(r=>({variant:r.variant,name:r.name,missingChecks:r.missingChecks,calls:r.calls}))}));
