// One frozen host and the unchanged Phase 5 fresh-process worker.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {verifyAttempt,identity,verifyIdentity,validatedCache} from '../../development/workflow.mjs';
import {verifyEqualityDerivation} from '../../development/equality.mjs';
import {supervise,requireExecution} from '../../development/process.mjs';
const read=f=>JSON.parse(fs.readFileSync(f));const save=(f,x)=>fs.writeFileSync(f,JSON.stringify(x,null,2)+'\n');
const oracle='016a5cedeb7e285adeabdad19388d99d3d9070668c15776ccc10fab8ea7b7186';
function environment(){const env={...process.env};for(const k of Object.keys(env))if(k.startsWith('BEND_')||k==='NODE_OPTIONS')delete env[k];return env;}
function verify(s){s.inputs.forEach(verifyIdentity);assert.equal(process.execPath,s.node.file);assert.equal(process.version,s.node.version);}
async function worker(s,variant,workload,label,out,prime=false){
 verify(s);const request=path.join(out,label+'.request.json'),result=path.join(out,label+'.result.json'),output=path.join(out,label+'.mjs');
 save(request,{variant:variant.id,api:variant.api.file,upstream:s.upstream,base:s.base.file,runtime:s.runtime.file,host:s.host,input:workload.input,mode:workload.mode,output,prime,workloads:s.workloads,inputs:s.inputs});
 const ms=Math.min(90000,Date.parse(s.deadline)-Date.now());assert.ok(ms>0,'Absolute pilot deadline exhausted');
 const execution=await supervise('taskset',['-c','0',process.execPath,'--stack-size=4096','--max-old-space-size=4096',s.worker,request,result],{directory:path.join(out,label+'-process'),env:environment(),timeoutMs:Math.floor(ms)});
 const row={variant:variant.id,workload:workload.id,request:identity(request),execution,passed:false};
 if(fs.existsSync(result)){row.result=identity(result);row.observation=read(result);}return row;
}
function valid(row,workload){requireExecution(row.execution);const o=row.observation;assert.equal(o.inputsVerified,true);assert.equal(o.node.path,process.execPath);assert.equal(o.affinity.split(':')[1].trim(),'0');assert.equal(o.result.checked,true);
 if(workload.id==='accepted'){assert.deepEqual({status:o.result.status,phase:o.result.phase,exitCode:o.result.exitCode},{status:'ok',phase:'compile',exitCode:0});assert.equal(o.emitted.sha256,oracle);verifyIdentity(o.emitted);}
 else {assert.deepEqual({status:o.result.status,phase:o.result.phase,exitCode:o.result.exitCode},{status:'error',phase:'check',exitCode:1});assert.match(o.result.diagnostic,/p6_failure/);assert.match(o.result.diagnostic,/undefined name|p6_nonexistent_identifier/);assert.equal(o.emitted,undefined);}
}
function same(a,b){assert.deepEqual(a.observation.result,b.observation.result,'Exact verdict/diagnostic changed');if(a.observation.emitted)assert.deepEqual(fs.readFileSync(a.observation.emitted.file),fs.readFileSync(b.observation.emitted.file),'Exact output changed');}
export async function prepare(configFile,out){
 configFile=fs.realpathSync(configFile);out=path.resolve(out);fs.mkdirSync(out);const cfg=read(configFile);assert.equal(cfg.cpu,0);assert.equal(cfg.timeoutMs,90000);assert.ok(Date.parse(cfg.deadline)>Date.now());
 const report={kind:'phase6-structured-checker-preparation',complete:false,started:new Date().toISOString(),inputs:[],priming:[],preflights:[],deadline:cfg.deadline};const write=()=>save(path.join(out,'report.json'),report);write();
 const add=f=>{const x=identity(f);if(!report.inputs.some(i=>i.file===x.file))report.inputs.push(x);return x;};
 try{
  const original=await verifyAttempt(cfg.attempt),candidate=await verifyAttempt(cfg.candidateAttempt),control=verifyEqualityDerivation(original.derivationReport.file),derived=verifyEqualityDerivation(candidate.derivationReport.file);
  assert.equal(original.artifactKind,'derived-b1');assert.equal(candidate.artifactKind,'derived-b1');
  for(const [m,d]of [[original,control],[candidate,derived]]){assert.equal(d.metadata.original.api.sha256,m.checkedApi.sha256);assert.equal(d.metadata.original.bootstrapReport.sha256,m.bootstrapReport.sha256);}
  assert.equal(identity(control.api).sha256,cfg.controlSha);assert.equal(identity(derived.api).sha256,cfg.candidateSha);assert.equal(original.base.sha256,candidate.base.sha256);assert.equal(original.base.canonicalPath,candidate.base.canonicalPath);assert.equal(original.runtime.sha256,candidate.runtime.sha256);
  report.attempts=[cfg.attempt,cfg.candidateAttempt];report.derivations=[control.report,derived.report];
  for(const f of [configFile,import.meta.filename,process.execPath,path.join(cfg.attempt,'attempt.json'),path.join(cfg.candidateAttempt,'attempt.json'),control.report,derived.report,control.metadata.toolSnapshot.file,derived.metadata.toolSnapshot.file])add(f);
  for(const d of [control,derived]){for(const x of d.metadata.original.inputs){verifyIdentity(x);add(x.file);}add(d.metadata.original.api.file);add(d.metadata.original.bootstrapReport.file);}
  for(const name of ['workflow','equality','process'])add(new URL('../../development/'+name+'.mjs',import.meta.url).pathname);add(new URL('../../conformance/inventory.mjs',import.meta.url).pathname);
  const tools=path.join(out,'host/tools');fs.mkdirSync(tools,{recursive:true});
  for(const name of ['typed-driver','compiler-abi','native-build','node-resource-args','assemble']){const source=path.join(candidate.snapshot.root,'tools',name+'.mjs'),target=path.join(tools,name+'.mjs');fs.copyFileSync(source,target);assert.equal(add(source).sha256,add(target).sha256);}
  const workerSource=new URL('../phase5/equality-worker.mjs',import.meta.url).pathname;report.worker=path.join(out,'worker.mjs');fs.copyFileSync(workerSource,report.worker);assert.equal(add(workerSource).sha256,add(report.worker).sha256);
  const core=fs.readFileSync(cfg.core,'utf8');assert.equal(Buffer.byteLength(core),60909);assert.ok(core.startsWith('import Base\n'));
  assert.equal(core.includes('p6_nonexistent_identifier'),false);
  const failure='\ndef p6_failure() -> U32:\n  p6_nonexistent_identifier\n';
  const early=path.join(out,'early.bend'),late=path.join(out,'late.bend');fs.writeFileSync(early,'import Base\n'+failure+core.slice('import Base\n'.length));fs.writeFileSync(late,core+failure);
  Object.assign(report,{host:path.join(tools,'typed-driver.mjs'),base:add(original.base.file),runtime:add(original.runtime.file),upstream:original.config.upstream,node:{...add(process.execPath),version:process.version},variants:[{id:'control',api:add(control.api)},{id:'candidate',api:add(derived.api)}],workloads:[{id:'accepted',input:add(cfg.core).file,mode:'library'},{id:'early',input:add(early).file,mode:'check'},{id:'late',input:add(late).file,mode:'check'}],cpu:0});write();
  for(const variant of report.variants){const row=await worker(report,variant,report.workloads[0],'prime-'+variant.id,out,true);report.priming.push(row);write();requireExecution(row.execution);assert.equal(row.observation.inputsVerified,true);assert.equal(row.observation.cache.validatedBy,'check_book');row.cache=validatedCache(path.join(out,'host/build/typed/cache'),variant.api.file,report.base.file);add(row.cache.file);for(const f of row.observation.dependencies)add(f);row.passed=true;write();}
  assert.deepEqual(read(report.priming[0].cache.file).book,read(report.priming[1].cache.file).book);report.decodedBaseGraphsEqual=true;
  for(const workload of report.workloads){let first;for(const variant of report.variants){const row=await worker(report,variant,workload,workload.id+'-'+variant.id+'-preflight',out);report.preflights.push(row);write();valid(row,workload);if(first)same(first,row);else first=row;row.passed=true;row.scope='Correctness preparation, not a controlled timing sample';write();}}
  verify(report);for(const a of report.attempts)await verifyAttempt(a);for(const d of report.derivations)verifyEqualityDerivation(d);report.complete=true;
 }catch(e){report.error=String(e.stack??e);process.exitCode=1;}report.finished=new Date().toISOString();write();return report;
}
export async function run(prepared,out){
 const preparation=path.resolve(prepared,'report.json'),s=read(preparation);assert.equal(s.complete,true);out=path.resolve(out);fs.mkdirSync(out);
 const report={kind:'phase6-structured-checker-ABBA',complete:false,started:new Date().toISOString(),preparation:identity(preparation),inputs:[...s.inputs,identity(preparation),identity(import.meta.filename)],rows:[],pairs:[],order:['control','candidate','candidate','control'],scope:'Four fresh processes per workload, same frozen conditional host/runtime/Base and equality profile, separately primed API-specific Base caches with exact decoded graph equality. Request excludes import/hash/output write; process and RSS include them. No full-source speed claim.',deadline:s.deadline};const write=()=>save(path.join(out,'report.json'),report);write();
 try{
  report.inputs.forEach(verifyIdentity);verify(s);
  for(const workload of s.workloads){const rows=[];for(const [index,id]of report.order.entries()){const row=await worker(s,s.variants.find(x=>x.id===id),workload,workload.id+'-'+index+'-'+id,out);row.index=index;rows.push(row);report.rows.push(row);write();valid(row,workload);same(row,s.preflights.find(r=>r.workload===workload.id&&r.variant===id));row.passed=true;write();}
   report.pairs.push(...[[0,1],[3,2]].map(([a,b])=>({workload:workload.id,control:a,candidate:b,requestReduction:1-rows[b].observation.requestMs/rows[a].observation.requestMs,processReduction:1-rows[b].execution.wallMs/rows[a].execution.wallMs})));write();}
  report.acceptedWithinFivePercent=report.pairs.filter(p=>p.workload==='accepted').every(p=>p.requestReduction>=-.05&&p.processReduction>=-.05);
  report.materialRejectionGains=Object.fromEntries(['early','late'].map(id=>[id,report.pairs.filter(p=>p.workload===id).every(p=>p.requestReduction>=.10&&p.processReduction>=.10)]));
  report.inputs.forEach(verifyIdentity);for(const a of s.attempts)await verifyAttempt(a);for(const d of s.derivations)verifyEqualityDerivation(d);report.inputsVerified=true;report.complete=true;
 }catch(e){report.error=String(e.stack??e);process.exitCode=1;}report.finished=new Date().toISOString();write();return report;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){const [mode,input,out,...extra]=process.argv.slice(2);if(!out||extra.length||!['prepare','run'].includes(mode))throw Error('Usage: structured-checker-compare.mjs prepare CONFIG NEW_PREPARATION | run PREPARATION NEW_RUN');const r=await(mode==='prepare'?prepare(input,out):run(input,out));console.log(JSON.stringify({complete:r.complete,acceptedWithinFivePercent:r.acceptedWithinFivePercent,error:r.error,pairs:r.pairs}));}
