function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0n ? {$: "Tuple", fst: 0n, snd: a}
    : {$: "Tuple", fst: a / b, snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655n) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && Math.fround(Number(s)) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = Number(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: Math.fround(v)} : {$: "None"};
}

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31n) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** Number(d)).fill(v);
}

// An unbalanced tree fails, as in C.
function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_swap(a, i, v) {
  const at = i % a.length;
  const old = a[at];
  a[at] = v;
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_jump(f, x) {
  return {$: "$JMP", f: f, x: x};
}

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : run_loop(f(...a));
}
// Program
// =======

function $a3_fresh$(term_0, env_0, next_0) {
  return run_jump($a3_walk$, [0, 0, term_0, env_0, next_0, {$: "Nil"}]);
}

function $a3_shift$(term_0, offset_0) {
  return run_jump($a3_unwrap$, [run_loop($a3_walk$(1, offset_0, term_0, {$: "Nil"}, 0, {$: "Nil"}))]);
}

function $f_fresh_term$(t_0, env_0, next_0) {
  return run_jump($f_fresh_stack$, [t_0, env_0, next_0]);
}

function $sp_shift$(t_0, offset_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(t_0)), "Var"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(t_0)), "All"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(t_0)), "Lam"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($String$eq$(run_loop($tg$(t_0)), "Bind"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($String$eq$(run_loop($tg$(t_0)), "Sub"));
  return {$: "KTerm", ["tag"]: run_loop($tg$(t_0)), ["name"]: run_loop($nm$(t_0)), ["id"]: run_loop($kc$((x_6 || x_7), run_clo((x_8) => {
  const x_9 = run_loop($ix$(t_0));
  return ((x_9 + offset_0) >>> 0);
}), run_clo((x_10) => {
  return run_jump($ix$, [t_0]);
}))), ["quant"]: run_loop($qt$(t_0)), ["kids"]: run_loop($sp_shifts$(run_loop($ks$(t_0)), offset_0)), ["removed"]: run_loop($rm$(t_0))};
}

function $a3_walk$(mode_0, offset_0, term_0, env_0, next_0, stack_0) {
  return run_jump($kc$, [(mode_0 === 1), run_clo((x_0) => {
  return run_jump($a3_kids$, [mode_0, offset_0, run_loop($a3_shift_head$(term_0, offset_0)), env_0, env_0, 0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Var")), run_clo((x_2) => {
  return run_jump($a3_done$, [mode_0, offset_0, run_loop($f_rename_var$(term_0, env_0)), next_0, stack_0]);
}), run_clo((x_3) => {
  return run_jump($a3_enter$, [term_0, env_0, next_0, run_loop($a3_shape$(term_0)), stack_0]);
})]);
})]);
}

function $a3_unwrap$(result_0) {
  const term_0 = result_0["term"];
  const next_0 = result_0["next"];
  return term_0;
}

function $f_fresh_stack$(term_0, env_0, next_0) {
  return run_jump($ffw_walk$, [term_0, env_0, next_0, {$: "Nil"}]);
}

function $tg$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return tag_0;
}

function $nm$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return name_0;
}

function $kc$(b_0, yes_0, no_0) {
  if (b_0) {
    return run_tail(yes_0, {$: "Unit"});
  } else {
    return run_tail(no_0, {$: "Unit"});
  }
}

function $String$eq$(a_0, b_0) {
  return run_jump($String$eq$fin$, [run_loop($String$cmp$(a_0, b_0))]);
}

function $ix$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return id_0;
}

function $qt$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return quant_0;
}

function $sp_shifts$(ts_0, offset_0) {
  if (ts_0.$ === "Nil") {
    return {$: "Nil"};
  } else {
    const h_0 = ts_0["head"];
    const rest_0 = ts_0["tail"];
    return {$: "Con", ["head"]: run_loop($sp_shift$(h_0, offset_0)), ["tail"]: run_loop($sp_shifts$(rest_0, offset_0))};
  }
}

function $ks$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return kids_0;
}

function $rm$(t_0) {
  const tag_0 = t_0["tag"];
  const name_0 = t_0["name"];
  const id_0 = t_0["id"];
  const quant_0 = t_0["quant"];
  const kids_0 = t_0["kids"];
  const removed_0 = t_0["removed"];
  return removed_0;
}

function $a3_kids$(mode_0, offset_0, root_0, outer_0, inner_0, shape_0, pending_0, built_0, next_0, stack_0) {
  if (pending_0.$ === "Nil") {
    return run_jump($a3_done$, [mode_0, offset_0, {$: "KTerm", ["tag"]: run_loop($tg$(root_0)), ["name"]: run_loop($nm$(root_0)), ["id"]: run_loop($ix$(root_0)), ["quant"]: run_loop($qt$(root_0)), ["kids"]: run_loop($List$reverse$(built_0)), ["removed"]: run_loop($rm$(root_0))}, next_0, stack_0]);
  } else {
    const head_0 = pending_0["head"];
    const rest_0 = pending_0["tail"];
    return run_jump($a3_child$, [mode_0, offset_0, root_0, outer_0, inner_0, shape_0, head_0, rest_0, built_0, next_0, stack_0]);
  }
}

function $a3_shift_head$(term_0, offset_0) {
  const x_0 = run_loop($String$eq$(run_loop($tg$(term_0)), "Var"));
  const x_1 = run_loop($String$eq$(run_loop($tg$(term_0)), "All"));
  const x_2 = (x_0 || x_1);
  const x_3 = run_loop($String$eq$(run_loop($tg$(term_0)), "Lam"));
  const x_4 = (x_2 || x_3);
  const x_5 = run_loop($String$eq$(run_loop($tg$(term_0)), "Bind"));
  const x_6 = (x_4 || x_5);
  const x_7 = run_loop($String$eq$(run_loop($tg$(term_0)), "Sub"));
  return {$: "KTerm", ["tag"]: run_loop($tg$(term_0)), ["name"]: run_loop($nm$(term_0)), ["id"]: run_loop($kc$((x_6 || x_7), run_clo((x_8) => {
  const x_9 = run_loop($ix$(term_0));
  return ((x_9 + offset_0) >>> 0);
}), run_clo((x_10) => {
  return run_jump($ix$, [term_0]);
}))), ["quant"]: run_loop($qt$(term_0)), ["kids"]: {$: "Nil"}, ["removed"]: run_loop($rm$(term_0))};
}

function $a3_done$(mode_0, offset_0, term_0, next_0, stack_0) {
  if (stack_0.$ === "Nil") {
    return {$: "FFresh", ["term"]: term_0, ["next"]: next_0};
  } else {
    const frame_0 = stack_0["head"];
    const rest_0 = stack_0["tail"];
    return run_jump($a3_resume$, [mode_0, offset_0, term_0, next_0, frame_0, rest_0]);
  }
}

function $f_rename_var$(t_0, env_0) {
  if (env_0.$ === "Nil") {
    return t_0;
  } else {
    const m_0 = env_0["head"];
    const ms_0 = env_0["tail"];
    const x_0 = run_loop($ix$(t_0));
    const x_1 = run_loop($ix$(m_0));
    return run_jump($f_choose$, [(x_0 === x_1), run_clo((x_2) => {
    return run_jump($kt$, ["Var", run_loop($nm$(t_0)), run_loop($ix$(run_loop($kid$(m_0, 0)))), run_loop($qt$(t_0)), {$: "Nil"}]);
}), run_clo((x_3) => {
    return run_jump($f_rename_var$, [t_0, ms_0]);
})]);
  }
}

function $a3_enter$(term_0, env_0, next_0, shape_0, stack_0) {
  const x_0 = (shape_0 === 1);
  const x_1 = (shape_0 === 2);
  return run_jump($kc$, [(x_0 || x_1), run_clo((x_2) => {
  return run_jump($a3_kids$, [0, 0, run_loop($kt$(run_loop($tg$(term_0)), run_loop($nm$(term_0)), next_0, run_loop($qt$(term_0)), {$: "Nil"})), env_0, run_loop($a3_bound$(env_0, run_loop($ix$(term_0)), run_loop($nm$(term_0)), next_0)), shape_0, run_loop($kc$((shape_0 === 1), run_clo((x_3) => {
  return {$: "Con", ["head"]: run_loop($kid$(term_0, 0)), ["tail"]: {$: "Nil"}};
}), run_clo((x_4) => {
  return {$: "Con", ["head"]: run_loop($kid$(term_0, 0)), ["tail"]: {$: "Con", ["head"]: run_loop($kid$(term_0, 1)), ["tail"]: {$: "Nil"}}};
}))), {$: "Nil"}, ((next_0 + 1) >>> 0), stack_0]);
}), run_clo((x_5) => {
  return run_jump($kc$, [(shape_0 === 3), run_clo((x_6) => {
  return run_jump($kc$, [run_loop($a3_empty$(run_loop($ks$(term_0)))), run_clo((x_7) => {
  return run_jump($a3_done$, [0, 0, run_loop($kt$("Error", "empty core let", 0, 0, {$: "Nil"})), next_0, stack_0]);
}), run_clo((x_8) => {
  return run_jump($a3_kids$, [0, 0, run_loop($kt$("Let", "", 0, 1, {$: "Nil"})), env_0, env_0, shape_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
})]);
}), run_clo((x_9) => {
  return run_jump($a3_kids$, [0, 0, term_0, env_0, env_0, shape_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
})]);
})]);
}

function $a3_shape$(term_0) {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Lam")), run_clo((x_0) => {
  return 1;
}), run_clo((x_1) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(term_0)), "All")), run_clo((x_2) => {
  return 2;
}), run_clo((x_3) => {
  return run_jump($kc$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Let")), run_clo((x_4) => {
  return 3;
}), run_clo((x_5) => {
  return 0;
})]);
})]);
})]);
}

function $ffw_walk$(term_0, env_0, next_0, stack_0) {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Var")), run_clo((x_0) => {
  return run_jump($ffw_done$, [run_loop($f_rename_var$(term_0, env_0)), next_0, stack_0]);
}), run_clo((x_1) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "All")), run_clo((x_2) => {
  return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), env_0, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFAllA", ["term"]: term_0, ["env"]: env_0, ["id"]: next_0}, ["tail"]: stack_0}]);
}), run_clo((x_3) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Lam")), run_clo((x_4) => {
  return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(term_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(term_0)), next_0)), ["tail"]: {$: "Nil"}})), ["tail"]: env_0}, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFLambda", ["term"]: term_0, ["id"]: next_0}, ["tail"]: stack_0}]);
}), run_clo((x_5) => {
  return run_jump($f_choose$, [run_loop($String$eq$(run_loop($tg$(term_0)), "Let")), run_clo((x_6) => {
  return run_jump($ffw_let$, [env_0, env_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
}), run_clo((x_7) => {
  return run_jump($ffw_kids$, [term_0, env_0, run_loop($ks$(term_0)), {$: "Nil"}, next_0, stack_0]);
})]);
})]);
})]);
})]);
}

function $String$eq$fin$(r_0) {
  const _t_0 = r_0["fst"];
  const a2_0 = _t_0["fst"];
  const b2_0 = _t_0["snd"];
  const c_0 = r_0["snd"];
  return run_jump($Cmp$is_eq$, [c_0]);
}

function $String$cmp$(a_0, b_0) {
  if (a_0 === "") {
    if (b_0 === "") {
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: "", ["snd"]: ""}, ["snd"]: {$: "EQ"}};
    } else {
      const h_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(0, 2) : b_0[0]);
      const t_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(2) : b_0.slice(1));
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: "", ["snd"]: (h_0 + t_0)}, ["snd"]: {$: "LT"}};
    }
  } else {
    const h_1 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(0, 2) : a_0[0]);
    const t_1 = (a_0.codePointAt(0) > 0xFFFF ? a_0.slice(2) : a_0.slice(1));
    if (b_0 === "") {
      return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h_1 + t_1), ["snd"]: ""}, ["snd"]: {$: "GT"}};
    } else {
      const h2_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(0, 2) : b_0[0]);
      const t2_0 = (b_0.codePointAt(0) > 0xFFFF ? b_0.slice(2) : b_0.slice(1));
      return run_jump($String$cmp$fin$, [t_1, t2_0, run_loop($Char$cmp$(h_1, h2_0))]);
    }
  }
}

function $List$reverse$(xs_0) {
  return run_jump($List$reverse$go$, [xs_0, {$: "Nil"}]);
}

function $a3_child$(mode_0, offset_0, root_0, outer_0, inner_0, shape_0, head_0, rest_0, built_0, next_0, stack_0) {
  return run_jump($kc$, [run_loop($Bool$and$((shape_0 === 3), run_loop($Bool$not$(run_loop($a3_empty$(rest_0)))))), run_clo((x_0) => {
  return run_jump($a3_walk$, [mode_0, offset_0, run_loop($kid$(head_0, 0)), outer_0, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "A3Frame", ["root"]: root_0, ["outer"]: outer_0, ["inner"]: run_loop($a3_bound$(inner_0, run_loop($ix$(head_0)), run_loop($nm$(head_0)), next_0)), ["shape"]: shape_0, ["pending"]: rest_0, ["built"]: built_0, ["field"]: run_loop($kt$("Bind", run_loop($nm$(head_0)), next_0, run_loop($qt$(head_0)), {$: "Nil"}))}, ["tail"]: stack_0}]);
}), run_clo((x_1) => {
  return run_jump($a3_walk$, [mode_0, offset_0, head_0, run_loop($kc$(run_loop($a3_body_scope$(shape_0, rest_0)), run_clo((x_2) => {
  return inner_0;
}), run_clo((x_3) => {
  return outer_0;
}))), next_0, {$: "Con", ["head"]: {$: "A3Frame", ["root"]: root_0, ["outer"]: outer_0, ["inner"]: inner_0, ["shape"]: shape_0, ["pending"]: rest_0, ["built"]: built_0, ["field"]: run_loop($atom$("Absent"))}, ["tail"]: stack_0}]);
})]);
}

function $a3_resume$(mode_0, offset_0, term_0, next_0, frame_0, stack_0) {
  const root_0 = frame_0["root"];
  const outer_0 = frame_0["outer"];
  const inner_0 = frame_0["inner"];
  const shape_0 = frame_0["shape"];
  const pending_0 = frame_0["pending"];
  const built_0 = frame_0["built"];
  const field_0 = frame_0["field"];
  return run_jump($a3_kids$, [mode_0, offset_0, root_0, outer_0, inner_0, shape_0, pending_0, {$: "Con", ["head"]: run_loop($kc$(run_loop($String$eq$(run_loop($tg$(field_0)), "Bind")), run_clo((x_0) => {
  return run_jump($kt$, ["Bind", run_loop($nm$(field_0)), run_loop($ix$(field_0)), run_loop($qt$(field_0)), {$: "Con", ["head"]: term_0, ["tail"]: {$: "Nil"}}]);
}), run_clo((x_1) => {
  return term_0;
}))), ["tail"]: built_0}, next_0, stack_0]);
}

function $f_choose$(b_0, yes_0, no_0) {
  if (b_0) {
    return run_tail(yes_0, {$: "Unit"});
  } else {
    return run_tail(no_0, {$: "Unit"});
  }
}

function $kt$(tag_0, name_0, id_0, quant_0, kids_0) {
  return {$: "KTerm", ["tag"]: tag_0, ["name"]: name_0, ["id"]: id_0, ["quant"]: quant_0, ["kids"]: kids_0, ["removed"]: {$: "Nil"}};
}

function $kid$(t_0, n_0) {
  return run_jump($terms_at$, [run_loop($ks$(t_0)), n_0]);
}

function $a3_bound$(env_0, old_0, name_0, fresh_0) {
  return {$: "Con", ["head"]: run_loop($kt$("Map", "", old_0, 0, {$: "Con", ["head"]: run_loop($var$(name_0, fresh_0)), ["tail"]: {$: "Nil"}})), ["tail"]: env_0};
}

function $a3_empty$(terms_0) {
  if (terms_0.$ === "Nil") {
    return true;
  } else {
    const head_0 = terms_0["head"];
    const tail_0 = terms_0["tail"];
    return false;
  }
}

function $ffw_done$(term_0, next_0, stack_0) {
  if (stack_0.$ === "Nil") {
    return {$: "FFresh", ["term"]: term_0, ["next"]: next_0};
  } else {
    const frame_0 = stack_0["head"];
    const rest_0 = stack_0["tail"];
    return run_jump($ffw_frame$, [frame_0, term_0, next_0, rest_0]);
  }
}

function $var$(name_0, id_0) {
  return run_jump($kt$, ["Var", name_0, id_0, 0, {$: "Nil"}]);
}

function $ffw_let$(env_0, bodyenv_0, items_0, built_0, next_0, stack_0) {
  if (items_0.$ === "Nil") {
    return run_jump($ffw_done$, [run_loop($kt$("Error", "empty core let", 0, 0, {$: "Nil"})), next_0, stack_0]);
  } else {
    const term_0 = items_0["head"];
    const tail_0 = items_0["tail"];
    return run_jump($ffw_let_tail$, [env_0, bodyenv_0, term_0, tail_0, built_0, next_0, stack_0]);
  }
}

function $ffw_kids$(term_0, env_0, pending_0, built_0, next_0, stack_0) {
  if (pending_0.$ === "Nil") {
    return run_jump($ffw_done$, [{$: "KTerm", ["tag"]: run_loop($tg$(term_0)), ["name"]: run_loop($nm$(term_0)), ["id"]: run_loop($ix$(term_0)), ["quant"]: run_loop($qt$(term_0)), ["kids"]: run_loop($List$reverse$(built_0)), ["removed"]: run_loop($rm$(term_0))}, next_0, stack_0]);
  } else {
    const head_0 = pending_0["head"];
    const rest_0 = pending_0["tail"];
    return run_jump($ffw_walk$, [head_0, env_0, next_0, {$: "Con", ["head"]: {$: "FFKids", ["term"]: term_0, ["env"]: env_0, ["pending"]: rest_0, ["built"]: built_0}, ["tail"]: stack_0}]);
  }
}

function $Cmp$is_eq$(c_0) {
  if (c_0.$ === "LT") {
    return false;
  } else if (c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$cmp$fin$(t1_0, t2_0, hc_0) {
  const _t_0 = hc_0["fst"];
  const h1b_0 = _t_0["fst"];
  const h2b_0 = _t_0["snd"];
  const _t_1 = hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1_0), ["snd"]: (h2b_0 + t2_0)}, ["snd"]: {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return run_jump($String$cmp$rec$, [h1b_0, h2b_0, run_loop($String$cmp$(t1_0, t2_0))]);
  } else {
    return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1_0), ["snd"]: (h2b_0 + t2_0)}, ["snd"]: {$: "GT"}};
  }
}

function $Char$cmp$(a_0, b_0) {
  const x_0 = a_0.codePointAt(0);
  const y_0 = b_0.codePointAt(0);
  return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: char_new(x_0), ["snd"]: char_new(y_0)}, ["snd"]: cmp_new(x_0, y_0)};
}

function $List$reverse$go$(xs_0, acc_0) {
  if (xs_0.$ === "Nil") {
    return acc_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return run_jump($List$reverse$go$, [t_0, {$: "Con", ["head"]: h_0, ["tail"]: acc_0}]);
  }
}

function $Bool$and$(a_0, b_0) {
  if (!a_0) {
    return false;
  } else {
    return b_0;
  }
}

function $Bool$not$(b_0) {
  if (!b_0) {
    return true;
  } else {
    return false;
  }
}

function $a3_body_scope$(shape_0, rest_0) {
  const x_0 = (shape_0 === 2);
  const x_1 = (shape_0 === 3);
  const x_2 = (shape_0 === 1);
  const x_3 = run_loop($Bool$and$((x_0 || x_1), run_loop($a3_empty$(rest_0))));
  return (x_2 || x_3);
}

function $atom$(tag_0) {
  return run_jump($kt$, [tag_0, "", 0, 0, {$: "Nil"}]);
}

function $terms_at$(ts_0, n_0) {
  if (ts_0.$ === "Nil") {
    return run_jump($atom$, ["Absent"]);
  } else {
    const h_0 = ts_0["head"];
    const t_0 = ts_0["tail"];
    return run_jump($kc$, [(n_0 === 0), run_clo((x_0) => {
    return h_0;
}), run_clo((x_1) => {
    return run_jump($terms_at$, [t_0, ((n_0 - 1) >>> 0)]);
})]);
  }
}

function $ffw_frame$(frame_0, value_0, next_0, stack_0) {
  if (frame_0.$ === "FFAllA") {
    const term_0 = frame_0["term"];
    const env_0 = frame_0["env"];
    const id_0 = frame_0["id"];
    return run_jump($ffw_walk$, [run_loop($kid$(term_0, 1)), {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(term_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(term_0)), id_0)), ["tail"]: {$: "Nil"}})), ["tail"]: env_0}, next_0, {$: "Con", ["head"]: {$: "FFAllB", ["term"]: term_0, ["id"]: id_0, ["typ"]: value_0}, ["tail"]: stack_0}]);
  } else if (frame_0.$ === "FFAllB") {
    const term_1 = frame_0["term"];
    const id_1 = frame_0["id"];
    const typ_0 = frame_0["typ"];
    return run_jump($ffw_done$, [run_loop($kt$("All", run_loop($nm$(term_1)), id_1, run_loop($qt$(term_1)), {$: "Con", ["head"]: typ_0, ["tail"]: {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}}})), next_0, stack_0]);
  } else if (frame_0.$ === "FFLambda") {
    const term_2 = frame_0["term"];
    const id_2 = frame_0["id"];
    return run_jump($ffw_done$, [run_loop($kt$("Lam", run_loop($nm$(term_2)), id_2, run_loop($qt$(term_2)), {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})), next_0, stack_0]);
  } else if (frame_0.$ === "FFKids") {
    const term_3 = frame_0["term"];
    const env_1 = frame_0["env"];
    const pending_0 = frame_0["pending"];
    const built_0 = frame_0["built"];
    return run_jump($ffw_kids$, [term_3, env_1, pending_0, {$: "Con", ["head"]: value_0, ["tail"]: built_0}, next_0, stack_0]);
  } else if (frame_0.$ === "FFLetValue") {
    const env_2 = frame_0["env"];
    const bodyenv_0 = frame_0["bodyenv"];
    const id_3 = frame_0["id"];
    const binding_0 = frame_0["binding"];
    const pending_1 = frame_0["pending"];
    const built_1 = frame_0["built"];
    return run_jump($ffw_let$, [env_2, {$: "Con", ["head"]: run_loop($kt$("Map", "", run_loop($ix$(binding_0)), 0, {$: "Con", ["head"]: run_loop($var$(run_loop($nm$(binding_0)), id_3)), ["tail"]: {$: "Nil"}})), ["tail"]: bodyenv_0}, pending_1, {$: "Con", ["head"]: run_loop($kt$("Bind", run_loop($nm$(binding_0)), id_3, run_loop($qt$(binding_0)), {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})), ["tail"]: built_1}, next_0, stack_0]);
  } else {
    const built_2 = frame_0["built"];
    return run_jump($ffw_done$, [run_loop($kt$("Let", "", 0, 1, run_loop($ffw_reverse_onto$(built_2, {$: "Con", ["head"]: value_0, ["tail"]: {$: "Nil"}})))), next_0, stack_0]);
  }
}

function $ffw_let_tail$(env_0, bodyenv_0, term_0, tail_0, built_0, next_0, stack_0) {
  if (tail_0.$ === "Nil") {
    return run_jump($ffw_walk$, [term_0, bodyenv_0, next_0, {$: "Con", ["head"]: {$: "FFLetBody", ["built"]: built_0}, ["tail"]: stack_0}]);
  } else {
    const head_0 = tail_0["head"];
    const rest_0 = tail_0["tail"];
    return run_jump($ffw_walk$, [run_loop($kid$(term_0, 0)), env_0, ((next_0 + 1) >>> 0), {$: "Con", ["head"]: {$: "FFLetValue", ["env"]: env_0, ["bodyenv"]: bodyenv_0, ["id"]: next_0, ["binding"]: term_0, ["pending"]: {$: "Con", ["head"]: head_0, ["tail"]: rest_0}, ["built"]: built_0}, ["tail"]: stack_0}]);
  }
}

function $String$cmp$rec$(h1b_0, h2b_0, rr_0) {
  const _t_0 = rr_0["fst"];
  const t1b_0 = _t_0["fst"];
  const t2b_0 = _t_0["snd"];
  const r_0 = rr_0["snd"];
  return {$: "Tuple", ["fst"]: {$: "Tuple", ["fst"]: (h1b_0 + t1b_0), ["snd"]: (h2b_0 + t2b_0)}, ["snd"]: r_0};
}

function $ffw_reverse_onto$(items_0, onto_0) {
  if (items_0.$ === "Nil") {
    return onto_0;
  } else {
    const head_0 = items_0["head"];
    const tail_0 = items_0["tail"];
    return run_jump($ffw_reverse_onto$, [tail_0, {$: "Con", ["head"]: head_0, ["tail"]: onto_0}]);
  }
}
export default {
  "a3_fresh": run_lib($a3_fresh$, 3),
  "a3_shift": run_lib($a3_shift$, 2),
  "f_fresh_term": run_lib($f_fresh_term$, 3),
  "sp_shift": run_lib($sp_shift$, 2),
};
