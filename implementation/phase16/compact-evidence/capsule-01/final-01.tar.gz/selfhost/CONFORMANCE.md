# Compiler validation

The target remains upstream `b2111cf43244e65f76ddc278ee695e669f720cbf`, Bend2
2.0.32 era. The [Phase16 release report](../implementation/phase16/consolidation.md)
binds the final checked artifact, controls, exact vectors, timing and preserved
failures. The [release manifest](dist/release.json) identifies the installed
guarded version5 derivative, genuine checked B1, source, Base, runtime and host.
`npm run verify:release` checks integrity and lineage after relocation; it does
not rerun conformance or establish a new self-hosted fixed point. Independent
proof-kernel validation and `--verdict` remain unsupported.

The full inventory has **1,498 fixtures**: 1,001 positive expectations,
482 validation negatives, 11 declaration-only trust refusals and four
later-emission errors. Eleven additional Bend files supply imports without
independent oracles. The final run completes all **2,996 parse/check observations**.
All 1,001 positives accept types; all 482 validation negatives reject, with no
observed invalid acceptance, timeout or unresolved observation. All 11 trust
cases type-check and reach the intended refusal, exactly matching TypeScript.

Exact reference differences fall **459→2**, with **457 new matches and zero lost
matches** versus Phase15. The remaining rows are parse and check for
`check/monad_do_destructure.bend`: rejection agrees, but the first diagnostic
differs because of an earlier do-block parsing checkpoint. All measured primitive
status, phase, type/trust, unsafe-list, exit and output axes agree on this corpus.
This finite result does not establish all intended typing rules or features.

Strict check results are **1,493 passes / 5 failures**. Four failures are expected
later-emission errors accepted by both frontends; the fifth is the do-block
oracle above. Exact reference comparison and strict fixture verdicts are separate.
Neither classification nor an integration no-regression gate weakens the oracle.

Broader controls retain known gaps outside that inventory:

- The 198-observation integration selection has **197 exact matches** and one
  same-body live-instance error-order difference.
- The 114-observation marked-pattern selection has **71 exact matches and 43
  known differences**. Its raw oracle report is `pass:false`, including the
  known do-block check failure. A separate audit establishes 114 unchanged
  candidate outcomes and zero regressions against its accepted predecessor;
  it does not establish full selected conformance. Six direct demand controls pass.
- The supplied-source 39 and ordered-host 43 controls each retain one known
  wording difference for `@unsafe` followed by an import. Namespace eight,
  term/cache 39 and whole-program host ten controls pass without exceptions.

On the exact final production API, the maintained 36 cases pass their selected
contract with two inherited exact differences. All **41 paired backend rows**,
**20 literal JS/native executions**, **176 literal observations**, **29 instance
controls** and **two specialization growth controls** match the pin. The direct
canonical-key probe passes **61 controls**, including 20 size boundaries; its
four-wrapper extension has a distinct recorded identity while retaining the
entire production API as an unchanged prefix. These are selected tests, not full
backend or proof-checker equivalence.

The standalone 25-module loader builds without checker or diagnostic-tracing
dependencies. All 16 unchanged derivation groups and five authentic version1–5
byte replays pass. All **42 installed/relocated CLI checks** pass without a copied
upstream checkout. [Interface validation](../implementation/phase16/release-validation.md)
and [final checker gates](../implementation/phase16/checker-compact-final-gates.md)
record the boundaries and individual artifacts.

Fresh long strings and the original 53/60-request histories preserve all
**226 paired complete results**, with original ordering and 4 MiB stack / 4 GiB
heap limits. The wave9 and final APIs run under the same reviewed final compatible
host; historical host differences remain explicit. The old 21-case prefix can
overflow even Phase11, so the maintained selection keeps the string first.
Finite histories do not establish general stack safety.

Other limits include hub/package fetching, independent proof-kernel validation,
backend/platform coverage and source Nat payloads restricted to U32 size (wider
runtime values have a separate representation). Native Process requires a libc
symbol unavailable on this host, also blocking upstream. GPU execution and
interactive devices are unvalidated. These control sets overlap and must not be
summed into a count of unique conformance programs. Earlier span/control counts
refer to their historical compiler images, not automatically to this release.

## Historical evidence

The following sections describe their recorded old-pin artifacts.

The supplied baseline compiler results are in [the compatibility matrix](docs/COMPATIBILITY-MATRIX.md).
Phase 1 changes have separate artifact-specific evidence in the
[implementation report](../implementation/phase1/report.md).
Phase 2 adds [exact paired checks and retained replay](../docs/PHASE2_DEVELOPMENT.md),
with revision-specific results in its [implementation report](../implementation/phase2/report.md).
Phase 3 adds [persistent frontend workers](../docs/PHASE3_DEVELOPMENT.md),
with artifact-specific validation and remaining gates in its
[implementation report](../implementation/phase3/report.md).
Phase 4 separates genuine checked B1, derived development images, native and
self-emitted artifacts in its [report](../implementation/phase4/report.md).
Phase 5 adds the [maintained checked workflow](../docs/PHASE5_DEVELOPMENT.md),
with source-specific repairs, controlled timings and remaining failures in its
[report](../implementation/phase5/report.md).
Its [final-source checked self-reproduction](../implementation/phase5/final-selfhost.md)
has actual equal stage2/stage3 bytes and matching current/frozen source modules;
this is separate from the supplied distribution's historical proof below.
Selected acceptance/phase checks, exact diagnostics, full-corpus coverage and
self-emission are distinct verdicts; none substitutes for the others.
The complete pinned corpus contains 1,378 fixtures across 24 namespaces; all 919
positive fixtures parsed and passed checking in the recorded full run. Exact
execution results, diagnostic differences, timeouts and hardware gates are
reported separately, with artifact hashes.

- [Component verification](dist/component-report.json) checks the assembled Bend source and compiler subsystems.
- [Negative-test audit](docs/NEGATIVE-COMPATIBILITY.md) separates presentation differences, different rejection rules/phases, and unproven intended-rule coverage.
- [Compiler ABI validation](docs/COMPILER-ABI.md) covers the lazy host adapter used by self-emitted compiler libraries. It is separate from the recorded full-corpus run, whose compiler, runtime and host hashes remain explicit.
- [Typed fixed-point verification](dist/selfhost/seed-verification/report.json) records direct checked seed self-emission and byte comparison. [Earlier failed attempts](dist/selfhost/release/report.json) remain separate evidence.
- [Conformance protocol](tools/conformance/README.md) explains reproducible runs and verdicts.
- [Original prototype baseline](docs/PROTOTYPE-BASELINE.md) and [earlier subset survey](docs/PROTOTYPE-SURVEY.md) are historical evidence for the unchecked compiler.

The typed compiler independently passed its complete checked self-rebuild on
2026-09-21: seed and output bytes match exactly. The recorded comparison uses
the same source and Base path layout; relocated checkouts need a local seed.
Passing positive programs does not establish full diagnostic or proof-checker equivalence.
