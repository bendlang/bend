import fs from 'node:fs';
import assert from 'node:assert/strict';
let denied=false;try{fs.readFileSync(process.argv[2]);}catch(e){assert.equal(e.code,'ERR_ACCESS_DENIED');denied=true;}
assert.equal(denied,true,'original repository unexpectedly readable');
fs.writeFileSync(process.argv[3],JSON.stringify({pass:true,code:'ERR_ACCESS_DENIED',denied:process.argv[2]})+'\n',{flag:'wx'});
