function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $b2u$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $sel$go$(_x_0, _y_0, _z_0) {
  if (_z_0) {
    return _x_0;
  } else {
    return _y_0;
  }
}

function $sel$(_t_0, _x_0, _y_0) {
  return $sel$go$(_x_0, _y_0, (_t_0 === 0));
}

function $asr8$(_v_0) {
  const _x_0 = (8 >= 32 ? 0 : (_v_0 >>> 8) >>> 0);
  const _x_1 = ($sel$((31 >= 32 ? 0 : (_v_0 >>> 31) >>> 0), 0, 4278190080));
  return ((_x_0 | _x_1) >>> 0);
}

function $mit$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _n_0 = $0;
      const _cr_0 = $1;
      const _ci_0 = $2;
      const _zr_0 = $3;
      const _zi_0 = $4;
      const _esc_0 = $5;
      const _it_0 = $6;
      if (_n_0 === 0) {
        return _it_0;
      } else {
        const _p_0 = (_n_0 - 1);
        const _r2_0 = ($asr8$((Math.imul(_zr_0, _zr_0) >>> 0)));
        const _i2_0 = ($asr8$((Math.imul(_zi_0, _zi_0) >>> 0)));
        const _x_0 = ((_r2_0 + _i2_0) >>> 0);
        const _x_1 = ($b2u$((_x_0 > 1024)));
        const _e2_0 = ((_esc_0 | _x_1) >>> 0);
        const _x_2 = ((_r2_0 - _i2_0) >>> 0);
        const _nzr_0 = ((_x_2 + _cr_0) >>> 0);
        const _x_3 = (Math.imul(_zr_0, _zi_0) >>> 0);
        const _x_4 = ($asr8$((Math.imul(2, _x_3) >>> 0)));
        const _nzi_0 = ((_x_4 + _ci_0) >>> 0);
        const _sr_0 = ($sel$(_e2_0, _nzr_0, _zr_0));
        const _si_0 = ($sel$(_e2_0, _nzi_0, _zi_0));
        const _x_5 = ($b2u$((_e2_0 === 0)));
        $0 = _p_0;
        $1 = _cr_0;
        $2 = _ci_0;
        $3 = _sr_0;
        $4 = _si_0;
        $5 = _e2_0;
        $6 = ((_it_0 + _x_5) >>> 0);
        continue;
      }
    }
  }
}

function $bench$(_size_0, _seed_0) {
  const _x_0 = ((_seed_0 & 1023) >>> 0);
  const _cr_0 = ((_x_0 - 512) >>> 0);
  const _x_1 = (10 >= 32 ? 0 : (_seed_0 >>> 10) >>> 0);
  const _x_2 = ((_x_1 & 1023) >>> 0);
  const _ci_0 = ((_x_2 - 512) >>> 0);
  return $mit$(_size_0, _cr_0, _ci_0, 0, 0, 0, 0);
}

function $point$(_n_0, _cr_0, _ci_0, _zr_0, _zi_0, _esc_0, _it_0) {
  return $mit$(_n_0, _cr_0, _ci_0, _zr_0, _zi_0, _esc_0, _it_0);
}
export default {
  "b2u": run_lib((a0) => { const r = (run_loop($b2u$((a0)))); (a0); return r; }, 1),
  "sel.go": run_lib((a0, a1, a2) => { const r = (run_loop($sel$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "sel": run_lib((a0, a1, a2) => { const r = (run_loop($sel$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "asr8": run_lib((a0) => { const r = (run_loop($asr8$((a0)))); (a0); return r; }, 1),
  "mit": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($mit$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), (a6)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "point": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($point$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
};
