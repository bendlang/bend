function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $prng$(_x_0) {
  const _x_1 = (13 >= 32 ? 0 : (_x_0 << 13) >>> 0);
  const _b_0 = ((_x_0 ^ _x_1) >>> 0);
  const _x_2 = (17 >= 32 ? 0 : (_b_0 >>> 17) >>> 0);
  const _d_0 = ((_b_0 ^ _x_2) >>> 0);
  const _x_3 = (5 >= 32 ? 0 : (_d_0 << 5) >>> 0);
  return ((_d_0 ^ _x_3) >>> 0);
}

function $key$(_i_0) {
  const _x_0 = ((_i_0 + 1) >>> 0);
  return $prng$((Math.imul(_x_0, 2654435761) >>> 0));
}

function $warp_leaf$go$(_x_0, _y_0, _t_0) {
  if (!_t_0) {
    return {$: "Node", "l": {$: "Leaf", "v": _x_0}, "r": {$: "Leaf", "v": _y_0}};
  } else {
    return {$: "Node", "l": {$: "Leaf", "v": _y_0}, "r": {$: "Leaf", "v": _x_0}};
  }
}

function $warp_leaf$(_x_0, _y_0, _s_0) {
  const _x_1 = (_x_0 > _y_0);
  return $warp_leaf$go$(_x_0, _y_0, (_s_0 !== _x_1));
}

function $warp_zip$(_wa_0, _wb_0) {
  if (_wa_0.$ === "Node") {
    const _a0_0 = _wa_0["l"];
    const _a1_0 = _wa_0["r"];
    if (_wb_0.$ === "Node") {
      const _b0_0 = _wb_0["l"];
      const _b1_0 = _wb_0["r"];
      return {$: "Node", "l": {$: "Node", "l": _a0_0, "r": _b0_0}, "r": {$: "Node", "l": _a1_0, "r": _b1_0}};
    } else {
      return {$: "Leaf", "v": 0};
    }
  } else {
    if (_wb_0.$ === "Node") {
      return {$: "Leaf", "v": 0};
    } else {
      return {$: "Leaf", "v": 0};
    }
  }
}

function $warp$(_a_0, _b_0, _s_0) {
  if (_a_0.$ === "Leaf") {
    const _av_0 = _a_0["v"];
    if (_b_0.$ === "Leaf") {
      const _bv_0 = _b_0["v"];
      return $warp_leaf$(_av_0, _bv_0, _s_0);
    } else {
      return {$: "Leaf", "v": 0};
    }
  } else {
    const _aa_0 = _a_0["l"];
    const _ab_0 = _a_0["r"];
    if (_b_0.$ === "Leaf") {
      return {$: "Leaf", "v": 0};
    } else {
      const _ba_1 = _b_0["l"];
      const _bb_1 = _b_0["r"];
      const _wa_0 = ($warp$(_aa_0, _ba_1, _s_0));
      const _wb_0 = ($warp$(_ab_0, _bb_1, _s_0));
      return $warp_zip$(_wa_0, _wb_0);
    }
  }
}

function $warp_node$(_t_0, _s_0) {
  if (_t_0.$ === "Leaf") {
    const _v_0 = _t_0["v"];
    return {$: "Leaf", "v": _v_0};
  } else {
    const _a_0 = _t_0["l"];
    const _b_0 = _t_0["r"];
    return $warp$(_a_0, _b_0, _s_0);
  }
}

function $flow$(_d_0, _s_0, _w_0) {
  if (_d_0 === 0) {
    if (_w_0.$ === "Leaf") {
      const _v_0 = _w_0["v"];
      return {$: "Leaf", "v": _v_0};
    } else {
      const _wa_0 = _w_0["l"];
      const _wb_0 = _w_0["r"];
      return {$: "Node", "l": _wa_0, "r": _wb_0};
    }
  } else {
    const _p_0 = (_d_0 - 1);
    if (_w_0.$ === "Leaf") {
      const _v_1 = _w_0["v"];
      return {$: "Leaf", "v": _v_1};
    } else {
      const _wa_1 = _w_0["l"];
      const _wb_1 = _w_0["r"];
      const _fa_0 = ($flow$(_p_0, _s_0, ($warp_node$(_wa_1, _s_0))));
      const _fb_0 = ($flow$(_p_0, _s_0, ($warp_node$(_wb_1, _s_0))));
      return {$: "Node", "l": _fa_0, "r": _fb_0};
    }
  }
}

function $bsort$(_d_0, _s_0, _x_0) {
  if (_d_0 === 0) {
    return {$: "Leaf", "v": ($key$(_x_0))};
  } else {
    const _p_0 = (_d_0 - 1);
    const _x_1 = ((_x_0 << 1) >>> 0);
    const _sa_0 = ($bsort$(_p_0, false, ((_x_1 + 1) >>> 0)));
    const _sb_0 = ($bsort$(_p_0, true, ((_x_0 << 1) >>> 0)));
    return $flow$(_p_0, _s_0, ($warp$(_sa_0, _sb_0, _s_0)));
  }
}

function $stat_join$go$(_alo_0, _bhi_0, _aok_0, _bok_0, _amx_0, _bmx_0, _t_0) {
  if (!_t_0) {
    const _x_0 = (Math.imul(_amx_0, 2654435761) >>> 0);
    return {$: "St", "lo": _alo_0, "hi": _bhi_0, "ok": 0, "mx": ((_x_0 + _bmx_0) >>> 0)};
  } else {
    const _x_1 = (Math.imul(_amx_0, 2654435761) >>> 0);
    return {$: "St", "lo": _alo_0, "hi": _bhi_0, "ok": ((_aok_0 & _bok_0) >>> 0), "mx": ((_x_1 + _bmx_0) >>> 0)};
  }
}

function $stat_join$(_a_0, _b_0) {
  const _alo_0 = _a_0["lo"];
  const _ahi_0 = _a_0["hi"];
  const _aok_0 = _a_0["ok"];
  const _amx_0 = _a_0["mx"];
  const _blo_0 = _b_0["lo"];
  const _bhi_0 = _b_0["hi"];
  const _bok_0 = _b_0["ok"];
  const _bmx_0 = _b_0["mx"];
  return $stat_join$go$(_alo_0, _bhi_0, _aok_0, _bok_0, _amx_0, _bmx_0, (_ahi_0 <= _blo_0));
}

function $scan$(_t_0) {
  if (_t_0.$ === "Leaf") {
    const _v_0 = _t_0["v"];
    return {$: "St", "lo": _v_0, "hi": _v_0, "ok": 1, "mx": _v_0};
  } else {
    const _a_0 = _t_0["l"];
    const _b_0 = _t_0["r"];
    const _l_0 = ($scan$(_a_0));
    const _r_0 = ($scan$(_b_0));
    return $stat_join$(_l_0, _r_0);
  }
}

function $stat_out$(_s_0) {
  const _lo_0 = _s_0["lo"];
  const _hi_0 = _s_0["hi"];
  const _ok_0 = _s_0["ok"];
  const _mx_0 = _s_0["mx"];
  const _x_0 = (Math.imul(_lo_0, 340573321) >>> 0);
  const _x_1 = (Math.imul(_mx_0, 2654435761) >>> 0);
  const _x_2 = ((_hi_0 + _x_0) >>> 0);
  const _x_3 = ((_x_1 ^ _x_2) >>> 0);
  const _x_4 = (Math.imul(_ok_0, 2246822519) >>> 0);
  return ((_x_3 + _x_4) >>> 0);
}

function $size$small$() {
  return 8;
}

function $expect$small$() {
  return 971629740;
}

function $size$big$() {
  return 23;
}

function $expect$big$() {
  return 3787129428;
}

function $bench$(_size_0, _seed_0) {
  return $stat_out$(($scan$(($bsort$(_size_0, false, _seed_0)))));
}
export default {
  "prng": run_lib((a0) => { const r = (run_loop($prng$((a0)))); (a0); return r; }, 1),
  "key": run_lib((a0) => { const r = (run_loop($key$((a0)))); (a0); return r; }, 1),
  "warp_leaf.go": run_lib((a0, a1, a2) => { const r = (run_loop($warp_leaf$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "warp_leaf": run_lib((a0, a1, a2) => { const r = (run_loop($warp_leaf$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "warp_zip": run_lib((a0, a1) => { const r = (run_loop($warp_zip$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "warp": run_lib((a0, a1, a2) => { const r = (run_loop($warp$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "warp_node": run_lib((a0, a1) => { const r = (run_loop($warp_node$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "flow": run_lib((a0, a1, a2) => { const r = (run_loop($flow$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "bsort": run_lib((a0, a1, a2) => { const r = (run_loop($bsort$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "stat_join.go": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($stat_join$go$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "stat_join": run_lib((a0, a1) => { const r = (run_loop($stat_join$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "scan": run_lib((a0) => { const r = (run_loop($scan$((a0)))); (a0); return r; }, 1),
  "stat_out": run_lib((a0) => { const r = (run_loop($stat_out$((a0)))); (a0); return r; }, 1),
  "size.small": run_lib(() => { const r = BigInt(run_loop($size$small$()));  return r; }, 0),
  "expect.small": run_lib(() => { const r = (run_loop($expect$small$()));  return r; }, 0),
  "size.big": run_lib(() => { const r = BigInt(run_loop($size$big$()));  return r; }, 0),
  "expect.big": run_lib(() => { const r = (run_loop($expect$big$()));  return r; }, 0),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
