function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $Hit$t$(_h_0) {
  const _t_0 = _h_0["t"];
  return _t_0;
}

function $fl$(_n_0, _d_0) {
  const _x_0 = Math.fround(_n_0);
  const _x_1 = Math.fround(_d_0);
  return Math.fround(_x_0 / _x_1);
}

function $sphere$(_i_0) {
  if (_i_0 === 0) {
    const _x_0 = Math.fround(0);
    const _x_1 = Math.fround(10001);
    return {$: "Sph", "x": Math.fround(0), "y": Math.fround(_x_0 - _x_1), "z": Math.fround(5), "r": Math.fround(10000), "kr": ($fl$(3, 10))};
  } else if (_i_0 === 1) {
    return {$: "Sph", "x": Math.fround(0), "y": Math.fround(0), "z": Math.fround(5), "r": Math.fround(1), "kr": ($fl$(7, 10))};
  } else if (_i_0 === 2) {
    return {$: "Sph", "x": Math.fround(2), "y": ($fl$(5, 10)), "z": Math.fround(6), "r": Math.fround(1), "kr": ($fl$(4, 10))};
  } else if (_i_0 === 3) {
    const _x_2 = Math.fround(0);
    const _x_3 = Math.fround(2);
    return {$: "Sph", "x": Math.fround(_x_2 - _x_3), "y": ($fl$(5, 10)), "z": Math.fround(6), "r": Math.fround(1), "kr": ($fl$(4, 10))};
  } else if (_i_0 === 4) {
    const _x_4 = Math.fround(0);
    const _x_5 = ($fl$(6, 10));
    return {$: "Sph", "x": Math.fround(1), "y": Math.fround(_x_4 - _x_5), "z": ($fl$(35, 10)), "r": ($fl$(4, 10)), "kr": ($fl$(9, 10))};
  } else if (_i_0 === 5) {
    const _x_6 = Math.fround(0);
    const _x_7 = Math.fround(1);
    const _x_8 = Math.fround(0);
    const _x_9 = ($fl$(6, 10));
    return {$: "Sph", "x": Math.fround(_x_6 - _x_7), "y": Math.fround(_x_8 - _x_9), "z": ($fl$(35, 10)), "r": ($fl$(4, 10)), "kr": ($fl$(9, 10))};
  } else if (_i_0 === 6) {
    return {$: "Sph", "x": Math.fround(0), "y": ($fl$(16, 10)), "z": Math.fround(7), "r": ($fl$(12, 10)), "kr": ($fl$(1, 10))};
  } else if (_i_0 === 7) {
    return {$: "Sph", "x": ($fl$(35, 10)), "y": ($fl$(2, 10)), "z": Math.fround(8), "r": Math.fround(1), "kr": ($fl$(6, 10))};
  } else {
    const _x_10 = Math.fround(0);
    const _x_11 = ($fl$(35, 10));
    return {$: "Sph", "x": Math.fround(_x_10 - _x_11), "y": ($fl$(2, 10)), "z": Math.fround(8), "r": Math.fround(1), "kr": ($fl$(6, 10))};
  }
}

function $isect$t2$(_t_0, _z_0) {
  if (_z_0) {
    return Math.fround(1000000000);
  } else {
    return _t_0;
  }
}

function $isect$t$(_t_0) {
  const _x_0 = ($fl$(1, 1000));
  return $isect$t2$(_t_0, (_t_0 < _x_0));
}

function $isect$go2$(_b_0, _disc_0, _z_0) {
  if (_z_0) {
    return Math.fround(1000000000);
  } else {
    const _x_0 = Math.fround(0);
    const _x_1 = Math.fround(_x_0 - _b_0);
    const _x_2 = Math.fround(Math.sqrt(_disc_0));
    return $isect$t$(Math.fround(_x_1 - _x_2));
  }
}

function $isect$go$(_b_0, _disc_0) {
  const _x_0 = Math.fround(0);
  return $isect$go2$(_b_0, _disc_0, (_disc_0 < _x_0));
}

function $isect5$(_cx_0, _cy_0, _cz_0, _r_0, _ox_0, _oy_0, _oz_0, _dx_0, _dy_0, _dz_0) {
  const _px_0 = Math.fround(_ox_0 - _cx_0);
  const _py_0 = Math.fround(_oy_0 - _cy_0);
  const _pz_0 = Math.fround(_oz_0 - _cz_0);
  const _x_0 = Math.fround(_px_0 * _dx_0);
  const _x_1 = Math.fround(_py_0 * _dy_0);
  const _x_2 = Math.fround(_x_0 + _x_1);
  const _x_3 = Math.fround(_pz_0 * _dz_0);
  const _b_0 = Math.fround(_x_2 + _x_3);
  const _x_4 = Math.fround(_px_0 * _px_0);
  const _x_5 = Math.fround(_py_0 * _py_0);
  const _x_6 = Math.fround(_x_4 + _x_5);
  const _x_7 = Math.fround(_pz_0 * _pz_0);
  const _x_8 = Math.fround(_x_6 + _x_7);
  const _x_9 = Math.fround(_r_0 * _r_0);
  const _x_10 = Math.fround(_b_0 * _b_0);
  const _x_11 = Math.fround(_x_8 - _x_9);
  return $isect$go$(_b_0, Math.fround(_x_10 - _x_11));
}

function $sx$(_i_0) {
  return TAB_0[Math.min(_i_0, 8)];
}

function $sy$(_i_0) {
  return TAB_1[Math.min(_i_0, 8)];
}

function $sz$(_i_0) {
  return TAB_2[Math.min(_i_0, 8)];
}

function $sr$(_i_0) {
  return TAB_3[Math.min(_i_0, 8)];
}

function $skr$(_i_0) {
  return TAB_4[Math.min(_i_0, 8)];
}

function $nearest$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) {
  for (;;) {
    {
      const _i_0 = $0;
      const _ox_0 = $1;
      const _oy_0 = $2;
      const _oz_0 = $3;
      const _dx_0 = $4;
      const _dy_0 = $5;
      const _dz_0 = $6;
      const _pt_0 = $7;
      const _pk_0 = $8;
      const _bt_0 = $9;
      const _bi_0 = $10;
      const _lt_0 = $11;
      if (_i_0 === 0) {
        if (!_lt_0) {
          return {$: "Hit", "ms": (_bi_0 === 9), "t": _bt_0, "i": _bi_0};
        } else {
          return {$: "Hit", "ms": (_pk_0 === 9), "t": _pt_0, "i": _pk_0};
        }
      } else {
        const _k_0 = (_i_0 - 1);
        if (!_lt_0) {
          const _t_0 = ($isect5$(($sx$(_k_0)), ($sy$(_k_0)), ($sz$(_k_0)), ($sr$(_k_0)), _ox_0, _oy_0, _oz_0, _dx_0, _dy_0, _dz_0));
          $0 = _k_0;
          $1 = _ox_0;
          $2 = _oy_0;
          $3 = _oz_0;
          $4 = _dx_0;
          $5 = _dy_0;
          $6 = _dz_0;
          $7 = _t_0;
          $8 = (_k_0 >>> 0);
          $9 = _bt_0;
          $10 = _bi_0;
          $11 = (_t_0 < _bt_0);
          continue;
        } else {
          const _t_1 = ($isect5$(($sx$(_k_0)), ($sy$(_k_0)), ($sz$(_k_0)), ($sr$(_k_0)), _ox_0, _oy_0, _oz_0, _dx_0, _dy_0, _dz_0));
          $0 = _k_0;
          $1 = _ox_0;
          $2 = _oy_0;
          $3 = _oz_0;
          $4 = _dx_0;
          $5 = _dy_0;
          $6 = _dz_0;
          $7 = _t_1;
          $8 = (_k_0 >>> 0);
          $9 = _pt_0;
          $10 = _pk_0;
          $11 = (_t_1 < _pt_0);
          continue;
        }
      }
    }
  }
}

function $fmax0$go$(_x_0, _z_0) {
  if (_z_0) {
    return Math.fround(0);
  } else {
    return _x_0;
  }
}

function $fmax0$(_x_0) {
  const _x_1 = Math.fround(0);
  return $fmax0$go$(_x_0, (_x_0 < _x_1));
}

function $shade$(_st_0, _ll_0, _df_0) {
  return $fmax0$go$(_df_0, (_st_0 < _ll_0));
}

function $clamp01$hi$go$(_x_0, _z_0) {
  if (_z_0) {
    return Math.fround(1);
  } else {
    return _x_0;
  }
}

function $clamp01$hi$(_x_0) {
  const _x_1 = Math.fround(1);
  return $clamp01$hi$go$(_x_0, (_x_1 < _x_0));
}

function $clamp01$go$(_x_0, _z_0) {
  if (_z_0) {
    return Math.fround(0);
  } else {
    return $clamp01$hi$(_x_0);
  }
}

function $clamp01$(_x_0) {
  const _x_1 = Math.fround(0);
  return $clamp01$go$(_x_0, (_x_0 < _x_1));
}

function $nearest$t$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9) {
  for (;;) {
    {
      const _i_0 = $0;
      const _ox_0 = $1;
      const _oy_0 = $2;
      const _oz_0 = $3;
      const _dx_0 = $4;
      const _dy_0 = $5;
      const _dz_0 = $6;
      const _pt_0 = $7;
      const _bt_0 = $8;
      const _lt_0 = $9;
      if (_i_0 === 0) {
        if (!_lt_0) {
          return _bt_0;
        } else {
          return _pt_0;
        }
      } else {
        const _k_0 = (_i_0 - 1);
        if (!_lt_0) {
          const _t_0 = ($isect5$(($sx$(_k_0)), ($sy$(_k_0)), ($sz$(_k_0)), ($sr$(_k_0)), _ox_0, _oy_0, _oz_0, _dx_0, _dy_0, _dz_0));
          $0 = _k_0;
          $1 = _ox_0;
          $2 = _oy_0;
          $3 = _oz_0;
          $4 = _dx_0;
          $5 = _dy_0;
          $6 = _dz_0;
          $7 = _t_0;
          $8 = _bt_0;
          $9 = (_t_0 < _bt_0);
          continue;
        } else {
          const _t_1 = ($isect5$(($sx$(_k_0)), ($sy$(_k_0)), ($sz$(_k_0)), ($sr$(_k_0)), _ox_0, _oy_0, _oz_0, _dx_0, _dy_0, _dz_0));
          $0 = _k_0;
          $1 = _ox_0;
          $2 = _oy_0;
          $3 = _oz_0;
          $4 = _dx_0;
          $5 = _dy_0;
          $6 = _dz_0;
          $7 = _t_1;
          $8 = _pt_0;
          $9 = (_t_1 < _pt_0);
          continue;
        }
      }
    }
  }
}

function $trace$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9) {
  for (;;) {
    {
      const _dep_0 = $0;
      const _ht_0 = $1;
      const _sox_0 = $2;
      const _soy_0 = $3;
      const _soz_0 = $4;
      const _rdx_0 = $5;
      const _rdy_0 = $6;
      const _rdz_0 = $7;
      const _acc_0 = $8;
      const _w_0 = $9;
      if (_dep_0 === 0) {
        const _t_0 = _ht_0["ms"];
        if (_t_0) {
          return _acc_0;
        } else {
          const _mt_1 = _ht_0["t"];
          const _mi_1 = _ht_0["i"];
          const _si_0 = _mi_1;
          const _rr_0 = ($sr$(_si_0));
          const _x_0 = Math.fround(_mt_1 * _rdx_0);
          const _hx_0 = Math.fround(_sox_0 + _x_0);
          const _x_1 = Math.fround(_mt_1 * _rdy_0);
          const _hy_0 = Math.fround(_soy_0 + _x_1);
          const _x_2 = Math.fround(_mt_1 * _rdz_0);
          const _hz_0 = Math.fround(_soz_0 + _x_2);
          const _x_3 = ($sx$(_si_0));
          const _x_4 = Math.fround(_hx_0 - _x_3);
          const _nx2_0 = Math.fround(_x_4 / _rr_0);
          const _x_5 = ($sy$(_si_0));
          const _x_6 = Math.fround(_hy_0 - _x_5);
          const _ny2_0 = Math.fround(_x_6 / _rr_0);
          const _x_7 = ($sz$(_si_0));
          const _x_8 = Math.fround(_hz_0 - _x_7);
          const _nz2_0 = Math.fround(_x_8 / _rr_0);
          const _x_9 = Math.fround(0);
          const _x_10 = Math.fround(3);
          const _x_11 = Math.fround(_x_9 - _x_10);
          const _lvx_0 = Math.fround(_x_11 - _hx_0);
          const _x_12 = Math.fround(8);
          const _lvy_0 = Math.fround(_x_12 - _hy_0);
          const _x_13 = Math.fround(1);
          const _lvz_0 = Math.fround(_x_13 - _hz_0);
          const _x_14 = Math.fround(_lvx_0 * _lvx_0);
          const _x_15 = Math.fround(_lvy_0 * _lvy_0);
          const _x_16 = Math.fround(_x_14 + _x_15);
          const _x_17 = Math.fround(_lvz_0 * _lvz_0);
          const _x_18 = Math.fround(_x_16 + _x_17);
          const _ll_0 = Math.fround(Math.sqrt(_x_18));
          const _lx_0 = Math.fround(_lvx_0 / _ll_0);
          const _ly_0 = Math.fround(_lvy_0 / _ll_0);
          const _lz_0 = Math.fround(_lvz_0 / _ll_0);
          const _x_19 = Math.fround(_nx2_0 * _lx_0);
          const _x_20 = Math.fround(_ny2_0 * _ly_0);
          const _x_21 = Math.fround(_x_19 + _x_20);
          const _x_22 = Math.fround(_nz2_0 * _lz_0);
          const _df_0 = ($fmax0$(Math.fround(_x_21 + _x_22)));
          const _x_23 = ($fl$(1, 1000));
          const _x_24 = Math.fround(_x_23 * _nx2_0);
          const _sox2_0 = Math.fround(_hx_0 + _x_24);
          const _x_25 = ($fl$(1, 1000));
          const _x_26 = Math.fround(_x_25 * _ny2_0);
          const _soy2_0 = Math.fround(_hy_0 + _x_26);
          const _x_27 = ($fl$(1, 1000));
          const _x_28 = Math.fround(_x_27 * _nz2_0);
          const _soz2_0 = Math.fround(_hz_0 + _x_28);
          const _st_0 = ($nearest$t$(9, _sox2_0, _soy2_0, _soz2_0, _lx_0, _ly_0, _lz_0, Math.fround(1000000000), Math.fround(1000000000), false));
          const _x_29 = ($fl$(85, 100));
          const _x_30 = ($shade$(_st_0, _ll_0, _df_0));
          const _x_31 = ($fl$(1, 10));
          const _x_32 = Math.fround(_x_29 * _x_30);
          const _x_33 = Math.fround(_x_31 + _x_32);
          const _x_34 = Math.fround(_w_0 * _x_33);
          return Math.fround(_acc_0 + _x_34);
        }
      } else {
        const _k_0 = (_dep_0 - 1);
        const _t_1 = _ht_0["ms"];
        if (_t_1) {
          return _acc_0;
        } else {
          const _mt_3 = _ht_0["t"];
          const _mi_3 = _ht_0["i"];
          const _si_1 = _mi_3;
          const _rr_1 = ($sr$(_si_1));
          const _x_35 = Math.fround(_mt_3 * _rdx_0);
          const _hx_1 = Math.fround(_sox_0 + _x_35);
          const _x_36 = Math.fround(_mt_3 * _rdy_0);
          const _hy_1 = Math.fround(_soy_0 + _x_36);
          const _x_37 = Math.fround(_mt_3 * _rdz_0);
          const _hz_1 = Math.fround(_soz_0 + _x_37);
          const _x_38 = ($sx$(_si_1));
          const _x_39 = Math.fround(_hx_1 - _x_38);
          const _nx2_1 = Math.fround(_x_39 / _rr_1);
          const _x_40 = ($sy$(_si_1));
          const _x_41 = Math.fround(_hy_1 - _x_40);
          const _ny2_1 = Math.fround(_x_41 / _rr_1);
          const _x_42 = ($sz$(_si_1));
          const _x_43 = Math.fround(_hz_1 - _x_42);
          const _nz2_1 = Math.fround(_x_43 / _rr_1);
          const _x_44 = Math.fround(0);
          const _x_45 = Math.fround(3);
          const _x_46 = Math.fround(_x_44 - _x_45);
          const _lvx_1 = Math.fround(_x_46 - _hx_1);
          const _x_47 = Math.fround(8);
          const _lvy_1 = Math.fround(_x_47 - _hy_1);
          const _x_48 = Math.fround(1);
          const _lvz_1 = Math.fround(_x_48 - _hz_1);
          const _x_49 = Math.fround(_lvx_1 * _lvx_1);
          const _x_50 = Math.fround(_lvy_1 * _lvy_1);
          const _x_51 = Math.fround(_x_49 + _x_50);
          const _x_52 = Math.fround(_lvz_1 * _lvz_1);
          const _x_53 = Math.fround(_x_51 + _x_52);
          const _ll_1 = Math.fround(Math.sqrt(_x_53));
          const _lx_1 = Math.fround(_lvx_1 / _ll_1);
          const _ly_1 = Math.fround(_lvy_1 / _ll_1);
          const _lz_1 = Math.fround(_lvz_1 / _ll_1);
          const _x_54 = Math.fround(_nx2_1 * _lx_1);
          const _x_55 = Math.fround(_ny2_1 * _ly_1);
          const _x_56 = Math.fround(_x_54 + _x_55);
          const _x_57 = Math.fround(_nz2_1 * _lz_1);
          const _df_1 = ($fmax0$(Math.fround(_x_56 + _x_57)));
          const _x_58 = ($fl$(1, 1000));
          const _x_59 = Math.fround(_x_58 * _nx2_1);
          const _sox2_1 = Math.fround(_hx_1 + _x_59);
          const _x_60 = ($fl$(1, 1000));
          const _x_61 = Math.fround(_x_60 * _ny2_1);
          const _soy2_1 = Math.fround(_hy_1 + _x_61);
          const _x_62 = ($fl$(1, 1000));
          const _x_63 = Math.fround(_x_62 * _nz2_1);
          const _soz2_1 = Math.fround(_hz_1 + _x_63);
          const _st_1 = ($nearest$t$(9, _sox2_1, _soy2_1, _soz2_1, _lx_1, _ly_1, _lz_1, Math.fround(1000000000), Math.fround(1000000000), false));
          const _x_64 = ($fl$(85, 100));
          const _x_65 = ($shade$(_st_1, _ll_1, _df_1));
          const _x_66 = ($fl$(1, 10));
          const _x_67 = Math.fround(_x_64 * _x_65);
          const _lum2_0 = Math.fround(_x_66 + _x_67);
          const _kr2_0 = ($skr$(_si_1));
          const _x_68 = Math.fround(_rdx_0 * _nx2_1);
          const _x_69 = Math.fround(_rdy_0 * _ny2_1);
          const _x_70 = Math.fround(_x_68 + _x_69);
          const _x_71 = Math.fround(_rdz_0 * _nz2_1);
          const _x_72 = Math.fround(2);
          const _x_73 = Math.fround(_x_70 + _x_71);
          const _k2_0 = Math.fround(_x_72 * _x_73);
          const _x_74 = Math.fround(_k2_0 * _nx2_1);
          const _rd2x_0 = Math.fround(_rdx_0 - _x_74);
          const _x_75 = Math.fround(_k2_0 * _ny2_1);
          const _rd2y_0 = Math.fround(_rdy_0 - _x_75);
          const _x_76 = Math.fround(_k2_0 * _nz2_1);
          const _rd2z_0 = Math.fround(_rdz_0 - _x_76);
          const _php_0 = ($nearest$(9, _sox2_1, _soy2_1, _soz2_1, _rd2x_0, _rd2y_0, _rd2z_0, Math.fround(1000000000), 9, Math.fround(1000000000), 9, false));
          const _x_77 = Math.fround(1);
          const _x_78 = Math.fround(_w_0 * _lum2_0);
          const _x_79 = Math.fround(_x_77 - _kr2_0);
          const _x_80 = Math.fround(_x_78 * _x_79);
          $0 = _k_0;
          $1 = _php_0;
          $2 = _sox2_1;
          $3 = _soy2_1;
          $4 = _soz2_1;
          $5 = _rd2x_0;
          $6 = _rd2y_0;
          $7 = _rd2z_0;
          $8 = Math.fround(_acc_0 + _x_80);
          $9 = Math.fround(_w_0 * _kr2_0);
          continue;
        }
      }
    }
  }
}

function $subray$(_fx_0, _fy_0) {
  const _x_0 = Math.fround(_fx_0 * _fx_0);
  const _x_1 = Math.fround(_fy_0 * _fy_0);
  const _x_2 = Math.fround(_x_0 + _x_1);
  const _x_3 = Math.fround(1);
  const _x_4 = Math.fround(_x_2 + _x_3);
  const _dl_0 = Math.fround(Math.sqrt(_x_4));
  const _dx_0 = Math.fround(_fx_0 / _dl_0);
  const _dy_0 = Math.fround(_fy_0 / _dl_0);
  const _x_5 = Math.fround(1);
  const _dz_0 = Math.fround(_x_5 / _dl_0);
  const _php_0 = ($nearest$(9, Math.fround(0), Math.fround(0), Math.fround(0), _dx_0, _dy_0, _dz_0, Math.fround(1000000000), 9, Math.fround(1000000000), 9, false));
  return $trace$(4, _php_0, Math.fround(0), Math.fround(0), Math.fround(0), _dx_0, _dy_0, _dz_0, Math.fround(0), Math.fround(1));
}

function $pixel$(_x_0, _y_0, _hw_0, _hh_0) {
  const _xf_0 = Math.fround(_x_0);
  const _yf_0 = Math.fround(_y_0);
  const _x_1 = ($fl$(1, 4));
  const _x_2 = Math.fround(_xf_0 + _x_1);
  const _x_3 = Math.fround(_x_2 - _hw_0);
  const _x_4 = ($fl$(1, 4));
  const _x_5 = Math.fround(_yf_0 + _x_4);
  const _x_6 = Math.fround(_hh_0 - _x_5);
  const _l1_0 = ($subray$(Math.fround(_x_3 / _hw_0), Math.fround(_x_6 / _hw_0)));
  const _x_7 = ($fl$(3, 4));
  const _x_8 = Math.fround(_xf_0 + _x_7);
  const _x_9 = Math.fround(_x_8 - _hw_0);
  const _x_10 = ($fl$(1, 4));
  const _x_11 = Math.fround(_yf_0 + _x_10);
  const _x_12 = Math.fround(_hh_0 - _x_11);
  const _l2_0 = ($subray$(Math.fround(_x_9 / _hw_0), Math.fround(_x_12 / _hw_0)));
  const _x_13 = ($fl$(1, 4));
  const _x_14 = Math.fround(_xf_0 + _x_13);
  const _x_15 = Math.fround(_x_14 - _hw_0);
  const _x_16 = ($fl$(3, 4));
  const _x_17 = Math.fround(_yf_0 + _x_16);
  const _x_18 = Math.fround(_hh_0 - _x_17);
  const _l3_0 = ($subray$(Math.fround(_x_15 / _hw_0), Math.fround(_x_18 / _hw_0)));
  const _x_19 = ($fl$(3, 4));
  const _x_20 = Math.fround(_xf_0 + _x_19);
  const _x_21 = Math.fround(_x_20 - _hw_0);
  const _x_22 = ($fl$(3, 4));
  const _x_23 = Math.fround(_yf_0 + _x_22);
  const _x_24 = Math.fround(_hh_0 - _x_23);
  const _l4_0 = ($subray$(Math.fround(_x_21 / _hw_0), Math.fround(_x_24 / _hw_0)));
  const _x_25 = Math.fround(_l1_0 + _l2_0);
  const _x_26 = Math.fround(_l3_0 + _l4_0);
  const _x_27 = Math.fround(_x_25 + _x_26);
  const _x_28 = ($fl$(1, 4));
  const _x_29 = Math.fround(255);
  const _x_30 = ($clamp01$(Math.fround(_x_27 * _x_28)));
  const _x_31 = Math.fround(_x_29 * _x_30);
  return (_x_31 >= 1 && _x_31 < 4294967296 ? Math.floor(_x_31) : 0);
}

function $colf$px$go$(_t_0, _xx_0, _y_0, _hw_0, _hh_0) {
  if (!_t_0) {
    return 0;
  } else {
    return $pixel$(_xx_0, _y_0, _hw_0, _hh_0);
  }
}

function $colf$px$(_xx_0, _y_0, _w_0, _hw_0, _hh_0) {
  return $colf$px$go$((_xx_0 < _w_0), _xx_0, _y_0, _hw_0, _hh_0);
}

function $colf$(_d_0, _x_0, _y_0, _w_0, _hw_0, _hh_0) {
  if (_d_0 === 0) {
    const _x_1 = (Math.imul(_x_0, 2654435761) >>> 0);
    return $colf$px$(((_x_1 & 16383) >>> 0), _y_0, _w_0, _hw_0, _hh_0);
  } else {
    const _p_0 = (_d_0 - 1);
    const _a_0 = ($colf$(_p_0, _x_0, _y_0, _w_0, _hw_0, _hh_0));
    const _x_2 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
    const _b_0 = ($colf$(_p_0, ((_x_0 + _x_2) >>> 0), _y_0, _w_0, _hw_0, _hh_0));
    return ((_a_0 + _b_0) >>> 0);
  }
}

function $rowf$(_d_0, _y_0, _m_0, _w_0, _hw_0, _hh_0) {
  if (_d_0 === 0) {
    const _x_0 = (Math.imul(_y_0, 1588635697) >>> 0);
    return $colf$(14, 0, ((_x_0 & _m_0) >>> 0), _w_0, _hw_0, _hh_0);
  } else {
    const _p_0 = (_d_0 - 1);
    const _a_0 = ($rowf$(_p_0, _y_0, _m_0, _w_0, _hw_0, _hh_0));
    const _x_1 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
    const _b_0 = ($rowf$(_p_0, ((_y_0 + _x_1) >>> 0), _m_0, _w_0, _hw_0, _hh_0));
    return ((_a_0 + _b_0) >>> 0);
  }
}

function $rows$() {
  return 12;
}

function $width$() {
  return 6000;
}

function $bench$(_size_0, _seed_0) {
  const _rr_0 = 6;
  const _x_0 = (2 === 0 ? 0 : (_size_0 / 2) >>> 0);
  const _hw_0 = Math.fround(_x_0);
  const _x_1 = (_rr_0 >= 32 ? 0 : (1 << _rr_0) >>> 0);
  const _x_2 = (2 === 0 ? 0 : (_x_1 / 2) >>> 0);
  const _hh_0 = Math.fround(_x_2);
  const _x_3 = (_rr_0 >= 32 ? 0 : (1 << _rr_0) >>> 0);
  const _hm_0 = ((_x_3 - 1) >>> 0);
  return $rowf$(_rr_0, 0, _hm_0, _size_0, _hw_0, _hh_0);
}

const TAB_0 = [Math.fround(0), Math.fround(0), Math.fround(2), Math.fround(Math.fround(0) - Math.fround(2)), Math.fround(1), Math.fround(Math.fround(0) - Math.fround(1)), Math.fround(0), Math.fround(Math.fround(35) / Math.fround(10)), Math.fround(Math.fround(0) - Math.fround(Math.fround(35) / Math.fround(10)))];
const TAB_1 = [Math.fround(Math.fround(0) - Math.fround(10001)), Math.fround(0), Math.fround(Math.fround(5) / Math.fround(10)), Math.fround(Math.fround(5) / Math.fround(10)), Math.fround(Math.fround(0) - Math.fround(Math.fround(6) / Math.fround(10))), Math.fround(Math.fround(0) - Math.fround(Math.fround(6) / Math.fround(10))), Math.fround(Math.fround(16) / Math.fround(10)), Math.fround(Math.fround(2) / Math.fround(10)), Math.fround(Math.fround(2) / Math.fround(10))];
const TAB_2 = [Math.fround(5), Math.fround(5), Math.fround(6), Math.fround(6), Math.fround(Math.fround(35) / Math.fround(10)), Math.fround(Math.fround(35) / Math.fround(10)), Math.fround(7), Math.fround(8), Math.fround(8)];
const TAB_3 = [Math.fround(10000), Math.fround(1), Math.fround(1), Math.fround(1), Math.fround(Math.fround(4) / Math.fround(10)), Math.fround(Math.fround(4) / Math.fround(10)), Math.fround(Math.fround(12) / Math.fround(10)), Math.fround(1), Math.fround(1)];
const TAB_4 = [Math.fround(Math.fround(3) / Math.fround(10)), Math.fround(Math.fround(7) / Math.fround(10)), Math.fround(Math.fround(4) / Math.fround(10)), Math.fround(Math.fround(4) / Math.fround(10)), Math.fround(Math.fround(9) / Math.fround(10)), Math.fround(Math.fround(9) / Math.fround(10)), Math.fround(Math.fround(1) / Math.fround(10)), Math.fround(Math.fround(6) / Math.fround(10)), Math.fround(Math.fround(6) / Math.fround(10))];export default {
  "Hit.t": run_lib((a0) => { const r = (run_loop($Hit$t$((a0)))); (a0); return r; }, 1),
  "fl": run_lib((a0, a1) => { const r = (run_loop($fl$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "sphere": run_lib((a0) => { const r = (run_loop($sphere$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "isect.t2": run_lib((a0, a1) => { const r = (run_loop($isect$t2$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "isect.t": run_lib((a0) => { const r = (run_loop($isect$t$((a0)))); (a0); return r; }, 1),
  "isect.go2": run_lib((a0, a1, a2) => { const r = (run_loop($isect$go2$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "isect.go": run_lib((a0, a1) => { const r = (run_loop($isect$go$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "isect5": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = (run_loop($isect5$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); return r; }, 10),
  "sx": run_lib((a0) => { const r = (run_loop($sx$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "sy": run_lib((a0) => { const r = (run_loop($sy$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "sz": run_lib((a0) => { const r = (run_loop($sz$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "sr": run_lib((a0) => { const r = (run_loop($sr$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "skr": run_lib((a0) => { const r = (run_loop($skr$(nat_host(a0)))); BigInt(a0); return r; }, 1),
  "nearest": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11) => { const r = (run_loop($nearest$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9), (a10), (a11)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); (a10); (a11); return r; }, 12),
  "fmax0.go": run_lib((a0, a1) => { const r = (run_loop($fmax0$go$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "fmax0": run_lib((a0) => { const r = (run_loop($fmax0$((a0)))); (a0); return r; }, 1),
  "shade": run_lib((a0, a1, a2) => { const r = (run_loop($shade$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "clamp01.hi.go": run_lib((a0, a1) => { const r = (run_loop($clamp01$hi$go$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "clamp01.hi": run_lib((a0) => { const r = (run_loop($clamp01$hi$((a0)))); (a0); return r; }, 1),
  "clamp01.go": run_lib((a0, a1) => { const r = (run_loop($clamp01$go$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "clamp01": run_lib((a0) => { const r = (run_loop($clamp01$((a0)))); (a0); return r; }, 1),
  "nearest.t": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = (run_loop($nearest$t$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); return r; }, 10),
  "trace": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = (run_loop($trace$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); return r; }, 10),
  "subray": run_lib((a0, a1) => { const r = (run_loop($subray$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "pixel": run_lib((a0, a1, a2, a3) => { const r = (run_loop($pixel$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "colf.px.go": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($colf$px$go$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "colf.px": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($colf$px$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "colf": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($colf$(nat_host(a0), (a1), (a2), (a3), (a4), (a5)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "rowf": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($rowf$(nat_host(a0), (a1), (a2), (a3), (a4), (a5)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "rows": run_lib(() => { const r = BigInt(run_loop($rows$()));  return r; }, 0),
  "width": run_lib(() => { const r = (run_loop($width$()));  return r; }, 0),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
