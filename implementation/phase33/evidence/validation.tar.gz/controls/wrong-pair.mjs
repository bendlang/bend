export default {pair:()=>-1};
