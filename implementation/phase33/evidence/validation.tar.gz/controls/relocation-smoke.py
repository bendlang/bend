#!/usr/bin/env python3
"""Relocated reference smoke: Node can read/write only the new portable root."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parents[4]
SUITE = ROOT / 'selfhost/tools/performance/programs'
sys.path.insert(0, str(SUITE))
from run import load_bundle, relative_path, verify
from support import ExecutionGuard, identity, save


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--node', required=True, type=Path)
    parser.add_argument('--seconds', type=int, default=120)
    parser.add_argument('--cpu', type=int, default=min(os.sched_getaffinity(0)))
    args = parser.parse_args()
    assert 10 <= args.seconds <= 300 and args.cpu in os.sched_getaffinity(0)
    begin = time.monotonic()
    out = args.out.resolve()
    assert not out.is_relative_to(ROOT), 'Portable root must be outside the original repository'
    out.mkdir(parents=True, exist_ok=False)
    node = args.node.resolve()
    report = dict(kind='programs-relocation-permission-smoke', complete=False, passed=False,
                  sourceRoot=str(ROOT), portableRoot=str(out), node=identity(node),
                  producer=identity(__file__), cpu=args.cpu, seconds=args.seconds,
                  scope='All30 fixed role/point combinations; three validated calls each, no timing inference.',
                  copiedInputs=[], frozenInputs=[], samples=[])
    save(out / 'report.json', report)
    shutil.copyfile(__file__, out / 'relocation-smoke.py')
    try:
        portable = out / 'selfhost/tools/performance/programs'
        for source in sorted(SUITE.rglob('*')):
            if '__pycache__' in source.parts or source.suffix == '.pyc':
                continue
            assert not source.is_symlink(), 'Unexpected suite symlink'
            if not source.is_file():
                continue
            target = portable / source.relative_to(SUITE)
            target.parent.mkdir(parents=True, exist_ok=True)
            original = identity(source)
            shutil.copyfile(source, target)
            verify(target, original)
            report['copiedInputs'].append(dict(original=original, copied=identity(target)))
        catalog_path = portable / 'catalog.json'
        catalog = json.loads(catalog_path.read_text())
        inputs = report['frozenInputs']
        inputs.append(identity(catalog_path))
        for case in catalog['cases']:
            inputs.append(verify(relative_path(portable, case['source']['path']), case['source']))
        bundle = load_bundle(portable / 'baseline/manifest.json', catalog,
                             identity(catalog_path)['sha256'], catalog['cases'],
                             ['baseline', 'typescript'], inputs, out / 'modules')
        negative = out / 'deny-repository-read.mjs'
        negative.write_text("import fs from 'node:fs';\nimport assert from 'node:assert/strict';\n"
                            "let denied=false;try{fs.readFileSync(process.argv[2]);}catch(e){"
                            "assert.equal(e.code,'ERR_ACCESS_DENIED');denied=true;}\n"
                            "assert.equal(denied,true,'original repository unexpectedly readable');\n"
                            "fs.writeFileSync(process.argv[3],JSON.stringify({pass:true,"
                            "code:'ERR_ACCESS_DENIED',denied:process.argv[2]})+'\\n',{flag:'wx'});\n")
        command_prefix = ['taskset', '-c', str(args.cpu), str(node), '--permission',
                          '--allow-fs-read=' + str(out), '--allow-fs-write=' + str(out),
                          '--max-old-space-size=1024', '--stack-size=4096']
        report['permissionBoundary'] = dict(read=str(out), write=str(out),
            deniedWitness=str(ROOT / 'README.md'), childProcessPermission=False)
        report['worker'] = identity(portable / 'execute.mjs')
        for case in catalog['cases']:
            for role in ['baseline', 'typescript']:
                report['samples'].append(dict(id=case['id'], role=role, complete=False,
                                               status='not-started'))
        with ExecutionGuard(rss_mib=1536, available_mib=2048) as guard:
            negative_dir = out / 'negative-read'
            negative_output = negative_dir / 'witness.json'
            process = guard.run(command_prefix + [str(negative), str(ROOT / 'README.md'),
                                str(negative_output)], negative_dir, begin + args.seconds)
            report['negativeControl'] = dict(process=process)
            assert process['complete'], 'Permission-denial witness failed'
            report['negativeControl']['result'] = json.loads(negative_output.read_text())
            for row in report['samples']:
                case = next(case for case in catalog['cases'] if case['id'] == row['id'])
                entry = bundle['points'][row['id']][row['role']]
                point = dict(case['point'], warmupCalls=0, warmupMs=0, calibrationMs=0,
                             targetMs=.001, maxRepetitions=1)
                point_file = out / (row['id'] + '-' + row['role'] + '-point.json')
                save(point_file, point)
                directory = out / 'samples' / (row['id'] + '-' + row['role'])
                output = directory / 'sample.json'
                command = command_prefix + [str(portable / 'execute.mjs'), entry['resolved'],
                                            str(point_file), str(output)]
                row['process'] = guard.run(command, directory, begin + args.seconds)
                row['status'] = 'executed'
                if output.exists():
                    row['result'] = json.loads(output.read_text())
                row['complete'] = row['process']['complete'] and row.get('result', {}).get('pass') is True
                save(out / 'report.json', report)
                print(json.dumps(dict(id=row['id'], role=row['role'], complete=row['complete'])), flush=True)
                assert row['complete'], 'Relocation point failed: ' + row['id'] + '/' + row['role']
        for item in inputs:
            verify(item['path'], item)
        for item in report['copiedInputs']:
            verify(item['copied']['path'], item['copied'])
        verify(node, report['node'])
        report['complete'] = report['passed'] = True
    except Exception as error:
        report['error'] = repr(error)
        raise
    finally:
        report['wallSeconds'] = time.monotonic() - begin
        save(out / 'report.json', report)
    print(json.dumps(dict(complete=True, passed=True, points=len(report['samples']),
                         wallSeconds=report['wallSeconds'], output=str(out))))


if __name__ == '__main__':
    main()
