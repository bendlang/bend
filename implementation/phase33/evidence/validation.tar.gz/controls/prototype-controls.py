#!/usr/bin/env python3
"""Exercise real bundle prototypes with unchanged computation and wrong output."""
from pathlib import Path
import json, subprocess, sys, hashlib
ROOT=Path(__file__).resolve().parents[4]
SUITE=ROOT/'selfhost/tools/performance/programs'
RAW=ROOT/'selfhost/build/programs'
NODE='/home/ai/.nvm/versions/node/v24.18.0/bin/node'
sys.path.insert(0,str(SUITE))
from support import save, identity
source=RAW/'candidate-preparation-01'
manifest=json.loads((source/'manifest.json').read_text())
case=next(x for x in manifest['cases'] if x['id']=='local-pair')
positive=RAW/'controls/unchanged-pair.mjs'
positive.write_bytes((source/case['modules']['candidate']['path']).read_bytes()+b'\n// Unchanged computation; prototype packaging control.\n')
negative=RAW/'controls/wrong-pair.mjs'
negative.write_text('export default {pair:()=>-1};\n')
report={'kind':'program-prototype-controls','pass':False,'producer':identity(__file__),'commands':[],'observations':[]}
save(RAW/'controls/prototype-controls.json',report)
def invoke(args):
    r=subprocess.run(args,cwd=ROOT,text=True,capture_output=True)
    report['commands'].append({'command':args,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
    save(RAW/'controls/prototype-controls.json',report)
    return r.returncode
for name,file,expected in [('unchanged',positive,True),('wrong',negative,False)]:
    bundle=RAW/('prototype-'+name)
    assert invoke([sys.executable,str(SUITE/'prototype.py'),'--from',str(source/'manifest.json'),'--replace','local-pair='+str(file),'--out',str(bundle)])==0
    m=json.loads((bundle/'manifest.json').read_text())
    assert m['complete'] and m['roles']['candidate']['kind']=='prototype' and m['roles']['candidate']['checked'] is False
    out=RAW/('prototype-'+name+'-run')
    status=invoke([sys.executable,str(SUITE/'run.py'),'--budget','20','--cases','local-pair','--node',NODE,'--cpu','3','--candidate',str(bundle/'manifest.json'),'--out',str(out)])
    measured=json.loads((out/'report.json').read_text())
    assert measured['pass'] is expected and status==(0 if expected else 1)
    summary=measured['cases'][0]['summary']
    assert (summary['ratios'] is not None)==expected
    if not expected:
        bad=next(x for x in measured['cases'][0]['samples'] if x['role']=='candidate')
        assert not bad['complete'] and bad['result']['stage']=='first-call'
    report['observations'].append({'name':name,'expectedPass':expected,'status':measured['status'],'report':identity(out/'report.json')})
report['pass']=True
save(RAW/'controls/prototype-controls.json',report)
print(json.dumps({'pass':True,'controls':len(report['observations'])}))
