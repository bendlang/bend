# Generated-program execution

Status: **measured**; 5/5 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| local-pair | 3/3 | 4.16738 | 4.21582 | 1.27449 | 3.308× |
| local-fold | 3/3 | 0.181865 | 0.182883 | 0.0625103 | 2.926× |
| scalar-region-0 | 3/3 | 0.00383017 | 0.00434051 | 6.85754e-05 | 63.296× |
| scalar-region-8192 | 3/3 | 0.14256 | 0.144452 | 0.0991958 | 1.456× |
| complete-generic-row32 | 3/3 | 0.415645 | 0.44849 | 0.00655926 | 68.375× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
