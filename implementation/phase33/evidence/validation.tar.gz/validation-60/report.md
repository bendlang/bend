# Generated-program execution

Status: **measured**; 8/8 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| local-pair | 3/3 | 3.88339 | 4.07314 | 1.26444 | 3.221× |
| local-fold | 3/3 | 0.24223 | 0.262944 | 0.0640584 | 4.105× |
| scalar-region-0 | 3/3 | 0.00404313 | 0.00402339 | 6.67489e-05 | 60.277× |
| scalar-region-8192 | 3/3 | 0.139919 | 0.139836 | 0.101226 | 1.381× |
| complete-generic-row32 | 3/3 | 0.394113 | 0.400325 | 0.00659468 | 60.704× |
| mandelbrot | 3/3 | 0.195807 | 0.195996 | 0.0474862 | 4.127× |
| editdist | 3/3 | 15.627 | 15.5819 | 5.14473 | 3.029× |
| test-rle-roundtrip | 3/3 | 0.0511298 | 0.0508973 | 0.000546194 | 93.185× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
