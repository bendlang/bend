# Generated-program execution

Status: **measured**; 14/14 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| local-pair | 5/5 | 3.87977 | 3.86573 | 1.25593 | 3.078× |
| local-fold | 5/5 | 0.234052 | 0.233494 | 0.041111 | 5.680× |
| scalar-region-0 | 5/5 | 0.00388531 | 0.00386112 | 6.70076e-05 | 57.622× |
| scalar-region-8192 | 5/5 | 0.141074 | 0.140536 | 0.0992663 | 1.416× |
| complete-generic-row32 | 5/5 | 0.383875 | 0.385941 | 0.00657266 | 58.719× |
| mandelbrot | 5/5 | 0.211367 | 0.212217 | 0.0453412 | 4.680× |
| editdist | 5/5 | 15.4218 | 15.4571 | 4.98223 | 3.102× |
| tree-bitonic | 5/5 | 20.6784 | 20.8601 | 0.277293 | 75.227× |
| lexer | 5/5 | 140.289 | 142.108 | 1.67478 | 84.852× |
| symreg | 5/5 | 88.8192 | 88.8321 | 1.10174 | 80.629× |
| test-morning-program | 5/5 | 0.212683 | 0.208586 | 0.00332858 | 62.665× |
| test-evening-program | 5/5 | 0.141832 | 0.142792 | 0.00260486 | 54.818× |
| test-rle-roundtrip | 5/5 | 0.0375941 | 0.0374362 | 0.000570582 | 65.611× |
| test-map-set-ops | 5/5 | 1.54355 | 1.52843 | 0.0201575 | 75.824× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
