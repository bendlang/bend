# Generated-program execution

Status: **measured**; 15/15 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| local-pair | 5/5 | 3.76894 | — | 1.23143 | 3.061× |
| local-fold | 5/5 | 0.23188 | — | 0.03906 | 5.937× |
| scalar-region-0 | 5/5 | 0.003756 | — | 6.68019e-05 | 56.226× |
| scalar-region-8192 | 5/5 | 0.139173 | — | 0.0992166 | 1.403× |
| complete-generic-row32 | 5/5 | 0.388765 | — | 0.00660974 | 58.817× |
| mandelbrot | 5/5 | 0.189116 | — | 0.0454744 | 4.159× |
| editdist | 5/5 | 15.1477 | — | 4.95993 | 3.054× |
| tree-bitonic | 5/5 | 19.564 | — | 0.274744 | 71.208× |
| lexer | 5/5 | 153.067 | — | 1.67968 | 91.128× |
| symreg | 5/5 | 98.12 | — | 1.09838 | 89.332× |
| test-morning-program | 5/5 | 0.199445 | — | 0.00323585 | 61.636× |
| test-evening-program | 5/5 | 0.129762 | — | 0.00260348 | 49.842× |
| test-rle-roundtrip | 5/5 | 0.0372973 | — | 0.00056412 | 66.116× |
| test-map-set-ops | 5/5 | 1.4925 | — | 0.0207468 | 71.939× |
| raytrace | 3/3 | 8933.94 | — | 34.2072 | 261.171× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
